#!/usr/bin/perl

# Purpose: To find a core cross-functional domain-domain interactions in yeast, worm and fly
# First Created: 6/9/2005
# Modified on:

print ">>Interactive interface for running D-STAR\n\n";

print ">Please enter the binary file (default:DSTAR.Window.exe in current directory): ";

while ($BIN = <STDIN>) 
{
	chop ($BIN);

	if (length($BIN) < 1) 
	{
		$BIN = "DSTAR.Window.exe";

		last;
	}
	elsif ((-e $BIN)) 
	{
		last;
	}
	else
	{
		print "\nCannot locate $BIN!! Please enter again or CTRL-C to exit: ";
	}
}

print "\n>Please enter sequence file in fasta format: ";

while ($SEQ = <STDIN>) 
{
	chop ($SEQ);

	if ((-e $SEQ)) 
	{
		last;
	}
	else
	{
		print "\nCannot locate $SEQ!! Please enter sequence file again or CTRL-C to exit: ";
	}
}

print "\n>Please enter interaction data file: ";

while ($INT = <STDIN>) 
{
	chop ($INT);

	if ((-e $INT)) 
	{
		last;
	}
	else
	{
		print "\nCannot locate $INT!! Please enter interaction data file again or CTRL-C to exit: ";
	}
}


print "\n>Please enter output file: ";

$OUT = <STDIN>;

chop ($OUT);

print "\n>Please enter min motif length (default:6): ";

while ($temp = <STDIN>) 
{
	chop ($temp);

	if ($temp =~ m/^(\d+)/) 
	{
		$MIN = $1;

		last;
	}
	elsif (length($temp) < 1)
	{
		$MIN = 6;

		print "Min motif length is set at 6\n";

		last;
	}
	else
	{
		print "\nUnrecognizable input!! Please enter again: ";
	}
}

print "\n>Please enter max motif length (default:8): ";

while ($temp = <STDIN>) 
{
	chop ($temp);

	if ($temp =~ m/^(\d+)/) 
	{
		$MAX = $1;

		last;
	}
	elsif (length($temp) < 1)
	{
		$MAX = 8;

		print "Max motif length is set at 8\n";

		last;
	}
	else
	{
		print "\nUnrecognizable input!! Please enter again: ";
	}
}


print "\n>Please enter hamming distance d (1 or 2).\nNote that coupling a bigger d with small motif length\nand large interaction datasets will greatly increase running time): ";

while ($temp = <STDIN>) 
{
	chop ($temp);

	if ($temp == 1) 
	{
		$HAMMING = 2;

		last;
	}
	elsif ($temp ==2)
	{
		$HAMMING = 4;

		last
	}
	else
	{
		print "\nUnrecognizable input!! Please enter again: ";
	}
}


print "\n>Please enter expected min motif occurrence kn (Default:5)\n(A larger number will reduce running time): ";

while ($temp = <STDIN>) 
{
	chop ($temp);

	if ($temp =~ m/^(\d+)$/) 
	{
		$M_SIZE = $1;

		last;
	}
	elsif (length($temp) < 1)
	{
		$M_SIZE = 5;
		
		print "Min motif occurrence is set at 5\n";

		last;
	}
	else
	{
		print "\nUnrecognizable input!! Please enter again: ";
	}
}


print "\n>Please enter expected min interaction ki (Default:5)\n(A larger number will reduce running time): ";

while ($temp = <STDIN>) 
{
	chop ($temp);

	if ($temp =~ m/^(\d+)$/) 
	{
		$I_SIZE = $1;

		last;
	}
	elsif (length($temp) < 1)
	{
		$I_SIZE = 5;
		
		print "Min motif occurrence is set at 5\n";

		last;
	}
	else
	{
		print "\nUnrecognizable input!! Please enter again:\n";
	}
}


for ($i=$MIN;$i<=$MAX;$i++) 
{
	$TEMPOUT = "L" . $i . ".out";

	print "\n\n>>>Runing D-STAR on motif length $i\n\n";
	
	push (@outputFile, $TEMPOUT);
	
	print "$BIN $SEQ $INT -o $TEMPOUT -l $i -d $HAMMING -L $M_SIZE -R $M_SIZE -I $I_SIZE -N 200\n\n";
	system "$BIN $SEQ $INT -o $TEMPOUT -l $i -d $HAMMING -L $M_SIZE -R $M_SIZE -I $I_SIZE -N 200";
}

print "\nDSTAR complete\n";

print "Clustering result....\n";

foreach $A (@outputFile) 
{
	open (INFILE, "$A");

	if ($A =~ m/L(\d+)/)
	{
		$L = $1;
	}
	else
	{
		$L = "X";
	}

	while (<INFILE>) 
	{
		if (m/^Rank\s+(\d+)/)
		{
			$ID = $L . "-" . $1;
		}
		else
		{
			$record{$ID} .= $_;
			
			if (m/^Left Proteins/)
			{
				$state = "L" 
			}
			elsif (m/^Right Proteins/)
			{
				$state = "R";
			}
			elsif (m/^Centroid\s+(\w+)\s+pos\s+(\d+)\(\w+\)/)
			{
				$star{$ID}{$state}{$1}{$2}++;
				$starProt{$ID}{$state}{$1}++;
			}
			elsif (m/^Protein\s+(\w+)\s+pos\s+/)
			{
				$currentProt = $1;
				$starProt{$ID}{$state}{$currentProt}++;

				chomp;
				s/^Protein\s+(\w+)\s+pos\s+//;
				s/\(\w+\)//g;

				@index = split (/;/,);

				#print "$ID @index\n";

				foreach $x (@index) 
				{
					$star{$ID}{$state}{$currentProt}{$x}++;
				}
				
			}
			elsif (m/Score=([\d\.]+)/)
			{
				$score{$ID} = $1;
				$mark{$ID} = 1;
			}
		}
	}

	close (INFILE);
}


@highest = sort {$score{$b} <=> $score{$a}} keys %score;

$total = @highest;

#print "Total:$total\n";

$threshold = 0.7;

for ($i=0;$i<$total;$i++) 
{
	$base = $highest[$i];

	next if ($mark{$base} == 0);

	#print "$i\n";

	for ($j=$i+1;$j<=$total;$j++) 
	{
		$probe = $highest[$j];

		next if ($mark{$probe} == 0);

		@baseLeftProt = keys %{$starProt{$base}{"L"}};
		$baseLeftProtSize = @baseLeftProt;

		@baseRightProt = keys %{$starProt{$base}{"R"}};
		$baseRightProtSize = @baseRightProt;

		@probeLeftProt = keys %{$starProt{$probe}{"L"}};
		$probeLeftProtSize = @probeLeftProt;

		@probeRightProt = keys %{$starProt{$probe}{"R"}};
		$probeRightProtSize = @probeRightProt;

		$globalhit = 0;
		
		foreach $A (@baseLeftProt) 
		{
			$hit = 0;

			if (defined $starProt{$probe}{"L"}{$A}) 
			{
				foreach $posA (keys %{$star{$probe}{"L"}{$A}}) 
				{
					last if ($hit > 0);

					foreach  $posB (keys %{$star{$base}{"L"}{$A}})
					{
														
						if ($posA >= ($posB - 3)) 
						{
							if ($posA <= ($posB + 3)) 
							{
								$hit++;
								last;
							}
						}
					}
				}
			}

			$globalHit++ if ($hit > 0);
		}

		$overlap = (2 * $globalHit)/($baseLeftProtSize + $probeLeftProtSize);

		if ($overlap >= $threshold) 
		{	
			$globalHit = 0;
			
			foreach $A (@baseRightProt) 
			{
				next if (length($A) < 1);
				$hit = 0;

				if (defined $starProt{$probe}{"R"}{$A}) 
				{
					foreach $posA (keys %{$star{$probe}{"R"}{$A}}) 
					{
						last if ($hit > 0);

						foreach  $posB (keys %{$star{$base}{"R"}{$A}})
						{
							if ($posA >= ($posB - 3)) 
							{
								if ($posA <= ($posB + 3)) 
								{
									$hit++;
									last;
								}
							}
						}
					}
				}

				$globalHit++ if ($hit > 0);
			}

			$overlap = (2 * $globalHit)/($baseRightProtSize + $probeRightProtSize);

			$mark{$probe} = 0 if ($overlap >= $threshold);

		}
		else
		{
			$globalHit = 0;
			
			foreach $A (@baseLeftProt) 
			{
				next if (length($A) < 1);
				$hit = 0;

				if (defined $starProt{$probe}{"R"}{$A}) 
				{
					foreach $posA (keys %{$star{$probe}{"R"}{$A}}) 
					{
						last if ($hit > 0);

						foreach  $posB (keys %{$star{$base}{"L"}{$A}})
						{
							if ($posA >= ($posB - 3)) 
							{
								if ($posA <= ($posB + 3)) 
								{
									$hit++;
									last;
								}
							}
						}
					}
				}

				$globalHit++ if ($hit > 0);

			}

			$overlap = (2 * $globalHit)/($baseLeftProtSize + $probeRightProtSize);

			if ($overlap >= $threshold)
			{
				$globalHit = 0;
			
				foreach $A (@baseRightProt) 
				{
					next if (length($A) < 1);
					$hit = 0;

					if (defined $starProt{$probe}{"L"}{$A}) 
					{
						foreach $posA (keys %{$star{$probe}{"L"}{$A}}) 
						{
							last if ($hit > 0);

							foreach  $posB (keys %{$star{$base}{"R"}{$A}})
							{
								if ($posA >= ($posB - 3)) 
								{
									if ($posA <= ($posB + 3)) 
									{
										$hit++;
										last;
									}
								}
							}
						}
					}

					$globalHit++ if ($hit > 0);

				}

				$overlap = (2 * $globalHit)/($baseRightProtSize + $probeLeftProtSize);

				$mark{$probe} = 0 if ($overlap >= $threshold);
			}
		}
	}
}

open (OUTFILE, ">$OUT");

$rank = 0;
$temp = 999999;
$count = 0;

foreach $A (@highest) 
{
	$count++;

	next if ($mark{$A} == 0);

	if ($score{$A} < $temp) 
	{
		$rank++;
		$temp = $score{$A};
	}
	
	print OUTFILE "Rank $rank\n";
	print OUTFILE "$record{$A}\n";

	#print "$A $mark{$A}\n";
}

close (OUTFILE);




