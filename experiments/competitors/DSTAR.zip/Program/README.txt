1. To run DSTAR type

DSTAR fasta-file interaction-file [<option> <option-value>] 

where <option> can be

	-l   <PATTERN_WIDTH>	The length of the motif searched
	-d   <DIST_THRES>	The maximum number of mismatch allowed from the centroid of the star (equal to 2d in (l,d) definition)
	-L   <MIN_SIZE_L>	Minimum size of left star
	-R   <MIN_SIZE_R>       Minimum size of right star
	-I   <MIN_NUM_OF_INTER> Minimum number of interaction between the proteins in left and right protein
	-N   <NUM_OF_RESULT>    Set the maximum number of result to compute
	-o   <output_file_name> Print the output into file, otherwise the output is sent to stdout

	-s   <left_protein_name> <right_protein_name>
				Run DSTAR only on the interaction <left_protein_name,right_protein_name>
					
for example

DSTAR C2-BIND_Seq.fasta C2-BIND.int -l 8 -d 2 -L 6 -R 6 -I 8 -N 100 -o try.out 

or for single interaction

DSTAR C2-BIND_Seq.fasta C2-BIND.int -l 8 -d 2 -L 6 -R 6 -I 8 -N 100 -o try.out   -s 0 2    

(only for interaction <0,2> )

A sample of fasta file and its interaction is given
C2-BIND_Seq.fasta
C2-BIND.int

Note that the interaction file is in the form of
<protein_name>	<protein_name>

where <protein_name> is taken from the string following '>' in the fasta file

2. Run DSTAR-Interactive.pl to run DSTAR with different motif length. The script will collate result from different run, remove duplicates and output result sorted according chi-square score.
