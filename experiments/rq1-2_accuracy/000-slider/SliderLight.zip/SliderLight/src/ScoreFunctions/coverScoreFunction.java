package ScoreFunctions;

import Data.InteractionData.IInteractionData;
import Data.MotifData.IMotifData;
import Data.MotifData.MaskArray;

/**
 * This function just returns the amount of interactions
 * 
 * @author Peter Boyen
 */
public class coverScoreFunction extends AbstractScoreFunction
{
    /**
     * Creates a new instance of coverScoreFunction, is called from the {@link ScoreFunctionFactory}.
     * 
     * @param interactionData       The interaction data, can be created using an {@link Data.InteractionData.IInteractionDataFactory}, such as {@link Data.InteractionData.InteractionArrayFactory}.
     * @param md                    The motif data, can be created using the interaciton data.
     * @param threads               The amount of threads the score function can use to preprecoess the data, and the amount of threads that coul simultaneously access the score function (assumed to be the same).
     */
    protected coverScoreFunction(IInteractionData interactionData, IMotifData md, int threads)
    {
        super(interactionData, md, threads);
    }
    
    public String getName()
    {
        return ScoreFunctionFactory.$COVER + "-l" + MaskArray.$subsequenceLength + "d" + MaskArray.$wildCards;
    }

    /**
     * 
     * @param SM1	A SORTED char[] of nodes
     * @param SM2	A SORTED char[] of nodes
     * @return		The amount of interactions the subnetwork
     */
    protected double getScore(char[] SM1, char[] SM2)
    {
        return $interactionData.getObservedInteractions(SM1, SM2);
    }

    /**
     * 
     * @return	    The worst possible score, in this case 0
     */
    public double worstScore()
    {
        return 0;
    }

    /**
     * @param score1	    A score
     * @param score2	    A score
     * @return		    Whether score1 is better than score2, in this case whether it is bigger
     */
    public boolean isBetterScore(double score1, double score2)
    {
        return score1 > score2;
    }

    @Override
    public String getScoreType()
    {
        return ScoreFunctionFactory.$COVER;
    }
}
