package ScoreFunctions;

import Data.InteractionData.IInteractionData;
import Data.MotifData.IMotifData;
import ScoreFunctions.ScoreComparators.IScoreComparator;

/**
 * This abstract class is used to ensure all the score functions have the same methods and
 * to provide some basic functionality all score functions have in common.
 * <p/>
 * Score functions are meant to give a score to motif pairs.
 * <p/>
 * Every score function must provide a few functions:
 * <br/>
 * <ul>
 * <li>double getScore(int[] SM1, int[] SM2), this function returns the score given two sets of nodes.</li>
 * <li>double worstScore(), this function returns the worst possible score for the function.</li>
 * <li>boolean isBetterScore(double score1, double score2), this function returns whether score1 is a better score than score2.</li>
 * <li>boolean scoresWorst(int motif), this score is not strictly necessary and can return false all the time. It can however give a speedup. It indicates if all pairs containing this motif will always have the worst possible score. This can possibly occur due to no (or not enough) nodes existing with that motif.</li>
 * </ul>
 * 
 * @author Peter Boyen
 */
public abstract class AbstractScoreFunction implements IScoreComparator
{
    public static int MINIMUMSIZE = 0;
    
    /**
     * The interaction data holds the information of which nodes interact.
     */
    protected IInteractionData $interactionData;
    /**
     * The motif data holds the information of which nodes hold which motifs (or which motifs occur in which nodes)
     */
    protected IMotifData $motifData;

    /**
     * Creates a new instance of ScoreFunction.
     * 
     * @param interactionData       The necessary interaction data. This can be made using a {@link Data.InteractionData.IInteractionDataFactory}, such as {@link Data.InteractionData.InteractionArrayFactory}.
     * @param md                    The motif data can be made using the interaction data.
     * @param threads               The amount of threads the score function can use to preprocess and the amount of threads it can be called from (assumed to be the same)
     */
    public AbstractScoreFunction(IInteractionData interactionData, IMotifData md, int threads)
    {
        $interactionData = interactionData;
        $motifData = md;
    }

    public double score(char[] SM1, char[] SM2)
    {
        if (SM1 == null || SM2 == null || SM1.length <= MINIMUMSIZE || SM2.length <= MINIMUMSIZE)
        {
            return worstScore();
        }

        return getScore(SM1, SM2);
    }
    
    public abstract String getName();

    /**
     * This is the most important function all score functions must implement.
     * Given two lists of nodes, what is the score.
     * 
     * @param SM1	A list of nodes (integers are those of the interaction data)
     * @param SM2	A list of nodes (integers are those of the interaction data)
     * @return		The score of the subnetwork
     */
    protected abstract double getScore(char[] SM1, char[] SM2);

    /**
     * 
     * @return	    The worst possible score for the score function
     */
    public abstract double worstScore();

    /**
     * Some scores are the bigger, the better. Some are the other way around. This function
     * returns given two scores which is better. The function should return if it is strictly better,
     * two scores are asummed to be equally good if their doubles are equal.
     * 
     * @param score1	    A score
     * @param score2	    A score
     * @return		    Whether score1 is better than score2
     */
    public abstract boolean isBetterScore(double score1, double score2);

    /**
     * will return true if the motif doesn't occur in the data. This can be overwritten
     * if other guarantees of having the worst score can be determined.
     * 
     * @param motif	A motif
     * @return		Whether any pair containing this motif will automatically get the worst score
     */
    public boolean scoresWorst(int motif)
    {
        return $motifData.getAmountOfSequencesWithMotif(motif) <= MINIMUMSIZE;
    }

    /**
     * This will call the scoresWorst(int motif) function
     *
     * @param motif	A String of the motif
     * @return		If it is sure this motif will get the worstScore()
     */
    public boolean scoresWorst(String motif)
    {
        return $motifData.getAmountOfSequencesWithMotif(motif) <= MINIMUMSIZE;
    }

    /**
     * This function will return true if the motif is guaranteed to score worse than the
     * minScore. This function must not be implemented by all subclasses and may throw
     * an UnsupportedOperationException
     *
     * @param motif
     * @param minScore
     * @return
     */
    public boolean scoresWorse(int motif, double minScore)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * This functions returns the minimum necessary size for a partner of the
     * motif, for the motif to possibly outscore minScore. This function must
     * not be implemented by all subclasses and may throw an UnsupportedOperationException
     *
     * @param motif
     * @param minScore
     * @return
     */
    public int minimumPartnerSize(int motif, double minScore)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * This functions returns the maximum allowed size for a partner of the
     * motif, for the motif to possibly outscore minScore. This function must
     * not be implemented by all subclasses and may throw an UnsupportedOperationException
     * 
     * @param motif
     * @param minScore
     * @return
     */
    public int maximumPartnerSize(int motif, double minScore)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * 
     * @return      The used {@link MotifData}
     */
    public IMotifData getMotifData()
    {
        return $motifData;
    }

    /**
     * 
     * @return      The used {@link IInteractionData}
     */
    public IInteractionData getInteractionData()
    {
        return $interactionData;
    }

    /**
     * This function will use the {@link MotifData} to get the proteins containing these motifs. It then
     * calls the abstract getScore() function.
     * 
     * @param m1	A String of a motif
     * @param m2	A String of a motif
     * @return		The score of the motif pair
     */
    public double score(String m1, String m2)
    {
        char[] SM1 = $motifData.getProteinsWithSequencesWithMotif(m1);
        char[] SM2 = $motifData.getProteinsWithSequencesWithMotif(m2);

        if (SM1 == null || SM2 == null)
        {
            return worstScore();
        }

        return getScore(SM1, SM2);
    }

    /**
     * This function will use the {@link MotifData} to get the list of proteins with these motifs. With
     * these lists the abstract getScore() function is called.
     * 
     * @param motifm1	    The number of a motif
     * @param motifm2	    The number of a motif
     * @return		    The score of the motif pair
     */
    public double score(int motifm1, int motifm2)
    {
        char[] SM1 = $motifData.getProteinsWithSequencesWithMotif(motifm1);
        char[] SM2 = $motifData.getProteinsWithSequencesWithMotif(motifm2);

        if (SM1 == null || SM2 == null)
        {
            return worstScore();
        }

        return getScore(SM1, SM2);
    }
    
    public abstract String getScoreType();
}
