package ScoreFunctions;

import Data.InteractionData.IInteractionData;
import Data.InteractionData.InteractionArrayFactory;
import Data.MotifData.IMotifData;
import Data.MotifData.PreprocessedMotifData;

/**
 * This class controls the construction of {@link ScoreFunctions.AbstractScoreFunction}s.
 * 
 * @author Peter Boyen
 */
public class ScoreFunctionFactory
{

    /**
     * When this parameter is used, a {@link pScoreFunction} will be returned.
     */
    public static final String $P = "p";
    /**
     * When this parameter is used, a {@link X2ScoreFunction} will be returned.
     */
    public static final String $X2 = "x2";
    /**
     * When this parameter is used, a {@link vScoreFunction} will be returned.
     */
    public static final String $V = "v";
    /**
     * When this parameter is used, a {@link coverScoreFunction} will be returned.
     */
    public static final String $COVER = "cover";
    public static final String $BINOMIAL = "binomial";
    public static final String $DIFFERENCE = "difference";
    public static final String $WEIGHTEDV = "weightedv";
    public static final String $X2MIN = "x2min";

    /**
     * Returns a {@link ScoreFunctions.AbstractScoreFunction} of the specified type.
     * 
     * @param scoreType		    One of the score typess (a static String member of this class)
     * @param interactionData	    The interaction data
     * @param pd		    The processed data
     * @param threads               The amount of threads to be used
     * @return			    A new {@link ScoreFunctions.AbstractScoreFunction} instance
     */
    public static AbstractScoreFunction getScoreFunction(String scoreType, IInteractionData interactionData, IMotifData pd, int threads)
    {
        if (scoreType.equals($P))
        {
            return new pScoreFunction(interactionData, pd, threads);
        } else if (scoreType.equals($X2))
        {
            return new X2ScoreFunction(interactionData, pd, threads);
        } else if (scoreType.equals($V))
        {
            return new vScoreFunction(interactionData, pd, threads);
        } else if (scoreType.equals($COVER))
        {
            return new coverScoreFunction(interactionData, pd, threads);
        } else if (scoreType.equals($BINOMIAL))
        {
            return new BinomialScoreFunction(interactionData, pd, threads);
        } else if (scoreType.equals($DIFFERENCE))
        {
            return new DifferenceScoreFunction(interactionData, pd, threads);
        } else if (scoreType.equals($WEIGHTEDV))
        {
            return new WeightedVScoreFunction(interactionData, pd, threads);
        } else if (scoreType.equals($X2MIN))
        {
            return new X2MinScoreFunction(interactionData, pd, threads);
        }

        throw new UnsupportedOperationException("unknown score function type: " + scoreType);
    }

    /**
     * Returns a {@link ScoreFunctions.AbstractScoreFunction} of the specified type. This will create a {@link MotifData} instance
     * and call the other getScoreFunction().
     * 
     * @param scoreType		    One of the score typess (a static String member of this class)
     * @param interactionData	    The interaction data
     * @param subsequenceLength	    The length of the motifs
     * @param wildCards		    The amount of wildcards in the motifs
     * @param threads               The amount of threads to be used
     * @return			    A new {@link ScoreFunctions.AbstractScoreFunction}
     */
    //public static AbstractScoreFunction getScoreFunction(String scoreType, IInteractionData interactionData, int subsequenceLength, int wildCards, int threads)
    //{
    //    IMotifData pd = new PreprocessedMotifData(interactionData, subsequenceLength, wildCards);
    //    return getScoreFunction(scoreType, interactionData, pd, threads);
    //}
    /**
     * Returns a {@link ScoreFunctions.AbstractScoreFunction} of the specified type. This will create a {@link Data.InteractionData.InteractionArray}
     * and a {@link MotifData} instance and call the other getScoreFunction().
     * 
     * @param folder                The folder containing the network data (prot.int and seq.fasta files)
     * @param scoreType		    One of the score types (a static String member of this class)
     * @param subsequenceLength	    The length of the motifs
     * @param wildCards		    The amount of wildcards in the motifs
     * @param threads               The amount of threads to be used
     * @return			    A new {@link ScoreFunctions.AbstractScoreFunction}
     */
    //public static AbstractScoreFunction getScoreFunction(String folder, String scoreType, int subsequenceLength, int wildCards, int threads)
    //{
    //    IInteractionData interactionData = new InteractionArrayFactory().read(folder);
    //    IMotifData pd = new PreprocessedMotifData(interactionData, subsequenceLength, wildCards);
    //    return getScoreFunction(scoreType, interactionData, pd, threads);
    //}
    public static AbstractScoreFunction getScoreFunction(String folder, String scoreType, int threads)
    {
        IInteractionData interactionData = new InteractionArrayFactory().read(folder);
        PreprocessedMotifData motifData = new PreprocessedMotifData(interactionData);
        return ScoreFunctionFactory.getScoreFunction(scoreType, interactionData, motifData, Runtime.getRuntime().availableProcessors());
    }
}
