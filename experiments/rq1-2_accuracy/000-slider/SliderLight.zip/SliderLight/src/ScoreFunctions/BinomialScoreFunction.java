package ScoreFunctions;

import Data.InteractionData.IInteractionData;
import Data.MotifData.IMotifData;
import Data.MotifData.MaskArray;
import ScoreFunctions.Combinations.Combinations;
import ScoreFunctions.Combinations.Combinations2;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author Peter Boyen
 */
public class BinomialScoreFunction extends AbstractScoreFunction
{

    private double $interactionDensity;
    private double $logDensity;
    private double $logOneMinusDensity;
    private double[] $logFacts;

    protected BinomialScoreFunction(IInteractionData interactionData, IMotifData md, int threads)
    {
        super(interactionData, md, threads);

        if (interactionData != null)
        {
            double I = $interactionData.getNumberOfInteractions();
            double Scomb2 = $interactionData.getNumberOfProteins();
            // combination (S 2), the amount of ways you can pick two sequences (including doubles)
            Scomb2 = (Scomb2 * (Scomb2 + 1)) / 2;

            $interactionDensity = I / Scomb2;
            $logDensity = Math.log($interactionDensity);
            $logOneMinusDensity = Math.log(1.0 - $interactionDensity);
        }

        $logFacts = new double[32];
        fillInLogFacts();
    }

    public String getName()
    {
        return ScoreFunctionFactory.$BINOMIAL + "-l" + MaskArray.$subsequenceLength + "d" + MaskArray.$wildCards;
    }

    @Override
    protected double getScore(char[] SM1, char[] SM2)
    {
        int OM1M2 = $interactionData.getObservedInteractions(SM1, SM2);

        if (OM1M2 == 0)
        {
            return worstScore();
        }

        int max = $interactionData.getMaximumInteractions(SM1, SM2);

        return getBinomial(OM1M2, max);
    }

    private double getBinomial(int interactions, int max)
    {
        double result = 0.0;

        // sum over all amounts of interactions from observed to max
        for (int i = interactions; i <= max; i++)
        {
            result += binomial(max, i);
        }

        return result;
    }

    private double binomial(int N, int k)
    {
        while (N >= $logFacts.length)
        {
            doubleArraySize();
        }

        if (k >= N / 2)
        {
            k = N - k;
            // p = 1 - p is taken care of by switching the terms in this calculation
            return Math.exp(logFact(N) - logFact(k) - logFact(N - k) + k * $logOneMinusDensity + (N - k) * $logDensity);
        }

        //return 0;
        //return Combinations.getCombination(N, k) * Math.pow(p, k) * Math.pow(1-p, N-k);
        return Math.exp(logFact(N) - logFact(k) - logFact(N - k) + k * $logDensity + (N - k) * $logOneMinusDensity);
    }

    private double getBinomialTest(int interactions, int max, double chance)
    {
        double result = 0.0;

        // sum over all amounts of interactions from observed to max
        for (int i = interactions; i <= max; i++)
        {
            result += binomialTest(max, chance, i);
        }

        return result;
    }

    private double binomialTest(int N, double p, int k)
    {
        while (N >= $logFacts.length)
        {
            doubleArraySize();
        }

        if (k >= N / 2)
        {
            k = N - k;
            p = 1 - p;
        }

        //return 0;
        //return Combinations.getCombination(N, k) * Math.pow(p, k) * Math.pow(1-p, N-k);
        return Math.exp(logFact(N) - logFact(k) - logFact(N - k) + k * Math.log(p) + (N - k) * Math.log(1 - p));
    }

    private double logFact(int n)
    {
        // The size of this array is guaranteed by the calling function

        if ($logFacts[n] > 0)
        {
            return $logFacts[n];
        }

        double ans = 0.0;
        for (int i = 1; i <= n; i++)
        {
            ans += Math.log(i);
        }

        $logFacts[n] = ans;

        return ans;
    }

    private void fillInLogFacts()
    {
        $logFacts[0] = 0;

        for (int i = 1; i < $logFacts.length; i++)
        {
            $logFacts[i] = $logFacts[i - 1] + Math.log(i);
        }
    }

    private void doubleArraySize()
    {
        double[] temp = $logFacts;
        $logFacts = new double[$logFacts.length * 2];

        System.arraycopy(temp, 0, $logFacts, 0, temp.length);
        for (int i = temp.length; i < $logFacts.length; i++)
        {
            $logFacts[i] = $logFacts[i - 1] + Math.log(i);
        }
    }

    @Override
    public double worstScore()
    {
        return 1.0;
    }

    @Override
    public boolean isBetterScore(double score1, double score2)
    {
        return score1 < score2;
    }

    public static void main(String[] args) throws Exception
    {
        BufferedReader br = new BufferedReader(new FileReader("pvalues.txt"));

        String line;
        br.readLine();

        while ((line = br.readLine()) != null)
        {
            String[] lines = line.split(",");
            int N = Integer.parseInt(lines[0]);
            double p = Double.parseDouble(lines[1]);
            int i = Integer.parseInt(lines[2]);

            double result = new BinomialScoreFunction(null, null, 1).getBinomialTest(i, N, p);

            double expectedResult = Double.parseDouble(lines[3]);

            if (Math.abs(result - expectedResult) > 0.00000000000005)
            {
                System.out.println("ERROR: " + result + " != " + expectedResult);
            }
        }

        br.close();
    }

    @Override
    public String getScoreType()
    {
        return ScoreFunctionFactory.$BINOMIAL;
    }
}
