package ScoreFunctions.Combinations;

import java.math.BigInteger;
import java.util.Arrays;

/**
 * This class holds all calculated combination numbers to avoid calculating them over and over again.
 * The combination number for i and j is (i j) = i! / (j! (i-j)!).
 * 
 * Some precision is lost by saving the results as doubles. But otherwise calculations become near impossible.
 * 
 * @author Peter Boyen
 */
public class Combinations
{

    /**
     * This array holds the calculated results
     */
    public static double[][] $combinationArray;

    /**
     * This takes care of the initialization of the array. At first it is a two-dimensional array
     * each with length 64. If a combination is requested outside of these bounds both dimensions are
     * doubled until the requested number fits.
     */
    static
    {
        $combinationArray = new double[64][64];
        for (int i = 0; i < $combinationArray.length; i++)
        {
            for (int j = 0; j < $combinationArray[0].length; j++)
            {
                $combinationArray[i][j] = -1;
            }
        }
    }

    /**
     * If the combination number isn't in the array yet, it is calculated and stored. If it
     * is already present it is just returned. If a combination is requested outside the bounds
     * of the current array both dimensions of the array are doubled until the requested number fits.
     * 
     * @param i		The first number in the combination
     * @param j		The second number in the combination
     * @return		The combination number (i j)
     */
    public static double getCombination(int i, int j)
    {
        if (i <= 0 || j <= 0 || i <= j)
        {
            return 1.0;
        }

        // Shouldn't happen in the p score function
        // If the array is too small, increase its size
        /*if (i >= $combinationArray.length)
        {
        int newSize = $combinationArray.length * 2;
        while (i >= newSize)
        {
        newSize *= 2;
        }
        increaseArraySize(newSize);
        }*/

        // If saved, return it.
        if ($combinationArray != null && $combinationArray[i][j] >= 0)
        {
            return $combinationArray[i][j];
        }

        // Otherwise calculate and save it
        return calculateAndSaveCombination(i, j);
    }

    /**
     * Increases both dimensions of the array to the newly selected size.
     * All data already present is copied.
     * If newSize is smaller than the old size of the array, nothing will happen
     * 
     * @param newSize       The new size for both dimensions of the array
     */
    public static void increaseArraySize(int newSize)
    {
        try
        {
            if (newSize <= $combinationArray.length)
            {
                return;
            }

            // Make the new array
            double[][] temp = new double[newSize][newSize];

            // Initialize it
            for (int i = 0; i < temp.length; i++)
            {
                Arrays.fill(temp[i], -1);
            }

            // Copy old data
            for (int i = 0; i < $combinationArray.length; i++)
            {
                System.arraycopy($combinationArray[i], 0, temp[i], 0, $combinationArray[i].length);
            }

            // Set array to this new array
            $combinationArray = temp;
        } catch (OutOfMemoryError e)
        {
            $combinationArray = null;
        }
    }

    /**
     * Calculates and stores all combination numbers with parameters below and equal to max.
     * This function will divide the calculations over several threads.
     * 
     * @param max	The maximum possible parameter of getCombination.
     * @param nrOfThreads       The amount of threads to divide this work over.
     */
    public static void calculateAll(int max, int nrOfThreads)
    {
        if (max >= $combinationArray.length)
        {
            increaseArraySize(max + 1);
        }

        CombinationThread[] threads = new CombinationThread[nrOfThreads];
        for (int i = 0; i < threads.length; i++)
        {
            threads[i] = new CombinationThread(i, nrOfThreads, max);
            threads[i].start();
        }

        boolean done = false;

        while (!done)
        {
            try
            {
                // Wait a while before you try again.
                // Sleep so as to not use too much time visiting this thread over and over.
                Thread.sleep(3000L);
            } catch (InterruptedException ex)
            {
                ex.printStackTrace();
                System.exit(1);
            }

            done = true;
            for (int i = 0; done && i < threads.length; i++)
            {
                done = threads[i].isFinished();
            }
        }


        for (int i = 0; i < threads.length; i++)
        {
            threads[i] = null;
        }

        threads = null;
    }

    /**
     * Calculates one combination number and saves the result in the array.
     * 
     * @param i		The first number in the combination
     * @param j		The second number in the combination
     * @return		The combination number (i j)
     */
    private static double calculateAndSaveCombination(int i, int j)
    {
        if (i <= 0 || j <= 0 || i <= j)
        {
            return 1.0;
        }

        // Use BigInteger to keep arbitrary precision as long as possible
        BigInteger combination = new BigInteger(new Integer(i).toString());

        for (BigInteger count = new BigInteger(new Integer(i - 1).toString()); count.intValue() > j; count = count.subtract(BigInteger.ONE))
        {
            combination = combination.multiply(count);
        }

        for (BigInteger count = new BigInteger(new Integer(2).toString()); count.intValue() <= i - j; count = count.add(BigInteger.ONE))
        {
            combination = combination.divide(count);
        }

        // The doubles make calculations with these numbers possible, some precision is lost.
        if ($combinationArray != null)
        {
            $combinationArray[i][j] = combination.doubleValue();
        }

        return combination.doubleValue();
    }

    /**
     * Class used to calculate several combination numbers.
     */
    private static class CombinationThread extends Thread
    {

        /**
         * The start position
         */
        private int $start;
        /**
         * The amount of first parameters to skip each time
         */
        private int $step;
        /**
         * The max parameter to calculate
         */
        private int $max;
        /**
         * Whether the Thread is already finished
         */
        private boolean $isFinished;

        /**
         * Creates a new instance of CombinationThread. This Thread will calculate several
         * combination numbers and store the results in the array.
         * 
         * @param start     The start position
         * @param step      The amount of first parameters to skip each time
         * @param max       The max parameter to calculate
         */
        public CombinationThread(int start, int step, int max)
        {
            $start = start;
            $step = step;
            $max = max;

            $isFinished = false;
        }

        /**
         * This function does the actual calculations by calling the calculateAndSaveCombination()
         * function several times.
         */
        @Override
        public void run()
        {
            for (int i = $start; i <= $max; i += $step)
            {
                for (int j = 0; j <= i; j++)
                {
                    getCombination(i, j);
                }

            // DEBUG
            //System.out.println(i);
            }

            $isFinished = true;
        }

        /**
         * 
         * @return      Whether the Thread is finished with all its calculations.
         */
        public boolean isFinished()
        {
            return $isFinished;
        }
    }

    public static void main(String[] args)
    {
        System.out.println(Combinations.getCombination(1024, 758));
    }

    public static double calculatePi(int a, int b, int c, int d, int e, int f)
    {
        return getCombination(a, b) * getCombination(c, d) / getCombination(e, f);
    }
}
