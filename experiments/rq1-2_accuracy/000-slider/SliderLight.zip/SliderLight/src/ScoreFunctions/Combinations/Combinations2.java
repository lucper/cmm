package ScoreFunctions.Combinations;

import Util.Pairs.MyPair;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Vector;

/**
 * This class serves the exact same purpose as Combinations, but more accurately for
 * higher numbers. Sadly this accuracy comes with a performance cost.
 * 
 * @author peterboyen
 */

public class Combinations2
{

    private static Vector<Integer>[][] $combinationArray;
    private static Vector<BigInteger> $primes;

    static
    {
        int startSize = 64;

        $combinationArray = new Vector[startSize][startSize];
        for (int i = 0; i < $combinationArray.length; i++)
        {
            for (int j = 0; j < $combinationArray[0].length; j++)
            {
                $combinationArray[i][j] = null;
            }
        }

        $primes = new Vector<BigInteger>();

        BigInteger prime = new BigInteger("2");
        BigInteger max = new BigInteger(new Integer(startSize).toString());

        $primes.add(prime);

        while (prime.compareTo(max) <= 0)
        {
            prime = prime.nextProbablePrime();
            $primes.add(prime);
        }
    }

    public static double getCombination(int i, int j)
    {
        if (i <= 0 || j <= 0 || i <= j)
        {
            return 1.0;
        }
        // If the array is too small, increase its size
        if (i >= $combinationArray.length)
        {
            int newSize = $combinationArray.length * 2;
            while (i >= newSize)
            {
                newSize *= 2;
            }
            increaseArraySize(newSize);
        }
        // If saved, return it.
        if ($combinationArray[i][j] != null)
        {
            return getValue($combinationArray[i][j]);
        }
        // Otherwise calculate and save it
        return calculateAndSaveCombination(i, j);
    }

    public static void increaseArraySize(int newSize)
    {
        if (newSize <= $combinationArray.length)
        {
            return;
        }

        // Make the new array
        Vector<Integer>[][] temp = new Vector[newSize][newSize];

        // Initialize it
        for (int i = 0; i < temp.length; i++)
        {
            Arrays.fill(temp[i], null);
        }

        // Copy old data
        for (int i = 0; i < $combinationArray.length; i++)
        {
            System.arraycopy($combinationArray[i], 0, temp[i], 0, $combinationArray[i].length);
        }

        // Set array to this new array
        $combinationArray = temp;

        BigInteger max = new BigInteger(new Integer(newSize).toString());
        BigInteger prime = $primes.get($primes.size() - 1);

        prime = prime.nextProbablePrime();

        while (prime.compareTo(max) <= 0)
        {
            $primes.add(prime);
            prime = prime.nextProbablePrime();

        }
    }

    private static double calculateAndSaveCombination(int i, int j)
    {
        if (i <= 0 || j <= 0 || i <= j)
        {
            return 1.0;
        }

        // Use BigInteger to keep arbitrary precision as long as possible
        BigInteger topFaculty = new BigInteger(new Integer(i).toString());
        for (BigInteger count = new BigInteger(new Integer(i - 1).toString()); count.intValue() > j; count = count.subtract(BigInteger.ONE))
        {
            topFaculty = topFaculty.multiply(count);
        }

        Vector<Integer> top = factorBigInteger(topFaculty);

        BigInteger bottomFaculty = new BigInteger("1");

        for (BigInteger count = new BigInteger(new Integer(2).toString()); count.intValue() <= i - j; count = count.add(BigInteger.ONE))
        {
            bottomFaculty = bottomFaculty.multiply(count);
        }

        Vector<Integer> bottom = factorBigInteger(bottomFaculty);

        // The doubles make calculations with these numbers possible, some precision is lost.
        $combinationArray[i][j] = simplify(top, bottom).$fst;

        return getValue($combinationArray[i][j]);
    }

    public static MyPair<Vector<Integer>, Vector<Integer>> simplify(Vector<Integer> top, Vector<Integer> bottom)
    {
        int i = 0;

        Vector<Integer> simplifiedTop = new Vector<Integer>();
        Vector<Integer> simplifiedBottom = new Vector<Integer>();

        while (i < top.size() || i < bottom.size())
        {
            if (i >= top.size())
            {
                simplifiedTop.add(0);
                simplifiedBottom.add(bottom.get(i));
            } else if (i >= bottom.size())
            {
                simplifiedTop.add(top.get(i));
                simplifiedBottom.add(0);
            } else
            {
                int topAmount = top.get(i);
                int bottomAmount = bottom.get(i);

                if (topAmount > bottomAmount)
                {
                    simplifiedTop.add(topAmount - bottomAmount);
                    simplifiedBottom.add(0);
                } else if (topAmount < bottomAmount)
                {
                    simplifiedTop.add(0);
                    simplifiedBottom.add(bottomAmount - topAmount);
                } else
                {
                    simplifiedTop.add(0);
                    simplifiedBottom.add(0);
                }
            }

            i++;
        }

        while (simplifiedTop.size() > 0 && simplifiedTop.get(simplifiedTop.size() - 1) == 0)
        {
            simplifiedTop.remove(simplifiedTop.size() - 1);
        }

        while (simplifiedBottom.size() > 0 && simplifiedBottom.get(simplifiedBottom.size() - 1) == 0)
        {
            simplifiedBottom.remove(simplifiedBottom.size() - 1);
        }

        return new MyPair<Vector<Integer>, Vector<Integer>>(simplifiedTop, simplifiedBottom);
    }

    public static double getValue(Vector<Integer> simplifiedTop)
    {
        BigInteger result = new BigInteger("1");
        for (int primeIndex = 0; primeIndex < simplifiedTop.size(); primeIndex++)
        {
            if (simplifiedTop.get(primeIndex) != 0)
            {
                int multiplier = (int) Math.pow($primes.get(primeIndex).doubleValue(), simplifiedTop.get(primeIndex));
                result = result.multiply(new BigInteger(new Integer(multiplier).toString()));
            }
        }

        return result.doubleValue();
    }

    public static double getValue(Vector<Integer> simplifiedTop, Vector<Integer> simplifiedBottom)
    {
        double result = 1;

        for (int primeIndex = 0; primeIndex < simplifiedTop.size(); primeIndex++)
        {
            if (simplifiedTop.get(primeIndex) != 0)
            {
                double multiplier = Math.pow($primes.get(primeIndex).doubleValue(), simplifiedTop.get(primeIndex));
                result *= multiplier;
            }
        }

        for (int primeIndex = 0; primeIndex < simplifiedBottom.size(); primeIndex++)
        {
            if (simplifiedBottom.get(primeIndex) != 0)
            {
                double multiplier = Math.pow($primes.get(primeIndex).doubleValue(), simplifiedBottom.get(primeIndex));
                result /= multiplier;
            }
        }

        return result;
    }

    public static Vector<Integer> factorBigInteger(BigInteger number)
    {
        Vector<Integer> top = new Vector<Integer>();

        // add the number of times dividable by 2
        top.add(number.getLowestSetBit());
        
        number = number.shiftRight(number.getLowestSetBit());
        
        int primeIndex = 1;
        
        while (number.compareTo(BigInteger.ONE) > 0)
        {
            BigInteger prime = $primes.get(primeIndex);
            
            BigInteger[] results = number.divideAndRemainder(prime);
            
            int amount = 0;

            while (results[1].equals(BigInteger.ZERO))
            {
                amount++;
                
                number = results[0];
                results = number.divideAndRemainder(prime);
            }
            
            top.add(amount);

            primeIndex++;
        }

        return top;
    }

    public static double calculatePi(int a, int b, int c, int d, int e, int f)
    {
        getCombination(a, b);
        getCombination(c, d);
        getCombination(e, f);
        // comb(a b) * comb(c d) / comb(e f)
        Vector<Integer> p1 = a <= 0 || b <= 0 || a >= $combinationArray.length || b >= $combinationArray[0].length || $combinationArray[a][b] == null ? new Vector<Integer>() : $combinationArray[a][b];
        Vector<Integer> p2 = c <= 0 || d <= 0 || c >= $combinationArray.length || d >= $combinationArray[0].length || $combinationArray[c][d] == null ? new Vector<Integer>() : $combinationArray[c][d];
        Vector<Integer> top = addLists(p1, p2);

        Vector<Integer> bottom = e <= 0 || f <= 0 || e >= $combinationArray.length || f >= $combinationArray[0].length || $combinationArray[e][f] == null ? new Vector<Integer>() : $combinationArray[e][f];

        MyPair<Vector<Integer>, Vector<Integer>> simplified = simplify(top, bottom);

        return getValue(simplified.$fst, simplified.$snd);
    }

    public static Vector<Integer> addLists(Vector<Integer> l1, Vector<Integer> l2)
    {
        Vector<Integer> result = new Vector<Integer>();

        for (int i = 0; i < l1.size(); i++)
        {
            result.add(l1.get(i));
        }

        for (int i = 0; i < l2.size(); i++)
        {
            if (i < result.size())
            {
                result.set(i, result.get(i) + l2.get(i));
            } else
            {
                result.add(l2.get(i));
            }
        }

        return result;
    }

    public Vector<Integer> addLists(Vector<Integer> l1, Vector<Integer> l2, Vector<Integer> l3)
    {
        Vector<Integer> result = new Vector<Integer>();

        for (int i = 0; i < l1.size(); i++)
        {
            result.add(l1.get(i));
        }

        for (int i = 0; i < l2.size(); i++)
        {
            if (i < result.size())
            {
                result.set(i, result.get(i) + l2.get(i));
            } else
            {
                result.add(l2.get(i));
            }
        }

        for (int i = 0; i < l3.size(); i++)
        {
            if (i < result.size())
            {
                result.set(i, result.get(i) + l3.get(i));
            } else
            {
                result.add(l3.get(i));
            }
        }

        return result;
    }

    public static void main(String[] args)
    {
        //System.out.println(Combinations2.calculatePi(5024, 40, 127, 5, 657, 453));
        
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                System.out.println("comb(" + i + ", " + j + ") = " + Combinations2.getCombination(i, j) + " " + Combinations.getCombination(i, j));
            }
        }
    }
}
