package ScoreFunctions;

import Data.InteractionData.IInteractionData;
import Data.MotifData.IMotifData;
import Data.MotifData.MaskArray;
import java.util.Arrays;

/**
 *
 * @author Peter Boyen
 */
public class WeightedVScoreFunction extends AbstractScoreFunction
{

    protected WeightedVScoreFunction(IInteractionData interactionData, IMotifData md, int threads)
    {
        super(interactionData, md, threads);
    }

    public String getName()
    {
        return ScoreFunctionFactory.$WEIGHTEDV + "-l" + MaskArray.$subsequenceLength + "d" + MaskArray.$wildCards;
    }

    @Override
    protected double getScore(char[] SM1, char[] SM2)
    {
        int OM1M2 = $interactionData.getObservedInteractions(SM1, SM2);

        if (OM1M2 == 0)
        {
            return worstScore();
        }

        double max = $interactionData.getMaximumInteractions(SM1, SM2);

        int overlap = 0;
        for (int i = 0; i < SM1.length; i++)
        {
            if (Arrays.binarySearch(SM2, SM1[i]) >= 0)
            {
                overlap++;
            }
        }

        return OM1M2 / max * weight(SM1.length + SM2.length - overlap);
    }

    private double weight(int amountOfNodes)
    {
        // return amountOfNodes
        return Math.sqrt(amountOfNodes);
    }

    @Override
    public double worstScore()
    {
        return 0;
    }

    @Override
    public boolean isBetterScore(double score1, double score2)
    {
        return score1 > score2;
    }

    @Override
    public String getScoreType()
    {
        return ScoreFunctionFactory.$WEIGHTEDV;
    }
}
