package ScoreFunctions;

import Data.InteractionData.IInteractionData;
import Data.MotifData.IMotifData;
import Data.MotifData.MaskArray;

/**
 *
 * @author Peter Boyen
 */
public class DifferenceScoreFunction extends AbstractScoreFunction
{

    protected DifferenceScoreFunction(IInteractionData interactionData, IMotifData md, int threads)
    {
        super(interactionData, md, threads);
    }

    public String getName()
    {
        return ScoreFunctionFactory.$DIFFERENCE + "-l" + MaskArray.$subsequenceLength + "d" + MaskArray.$wildCards;
    }

    @Override
    protected double getScore(char[] SM1, char[] SM2)
    {
        int present = $interactionData.getObservedInteractions(SM1, SM2);
        int max = $interactionData.getMaximumInteractions(SM1, SM2);

        //return present - (max - present);
        return (2 * present) - max;
    }

    @Override
    public double worstScore()
    {
        return Double.MIN_VALUE;
    }

    @Override
    public boolean isBetterScore(double score1, double score2)
    {
        return score1 > score2;
    }

    @Override
    public String getScoreType()
    {
        return ScoreFunctionFactory.$DIFFERENCE;
    }
}
