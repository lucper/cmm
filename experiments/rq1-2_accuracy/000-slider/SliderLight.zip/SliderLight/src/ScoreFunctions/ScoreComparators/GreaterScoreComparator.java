/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ScoreFunctions.ScoreComparators;

/**
 *
 * @author Peter
 */
public class GreaterScoreComparator implements IScoreComparator
{

    public boolean isBetterScore(double score1, double score2)
    {
        return score1 > score2;
    }
}
