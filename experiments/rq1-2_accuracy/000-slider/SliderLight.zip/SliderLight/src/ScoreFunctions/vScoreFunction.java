package ScoreFunctions;

import Data.InteractionData.IInteractionData;
import Data.MotifData.IMotifData;
import Data.MotifData.MaskArray;
import java.util.Arrays;

/**
 * This class will calculate our v-score. It is a score measuring the percentage out of
 * all possible interactions present in a subnetwork. It will also take the size of the
 * subnetwork into account.
 * 
 * @author Peter Boyen
 */
public class vScoreFunction extends AbstractScoreFunction
{

    /**
     * Creates a new instance of vScoreFunction, is called from the {@link ScoreFunctionFactory}.
     * 
     * @param interactionData       The interaction data, can be created using an {@link Data.InteractionData.IInteractionDataFactory}, such as {@link Data.InteractionData.InteractionArrayFactory}.
     * @param md                    The motif data, can be created using the interaciton data.
     * @param threads               The amount of threads the score function can use to preprecoess the data, and the amount of threads that coul simultaneously access the score function (assumed to be the same).
     */
    protected vScoreFunction(IInteractionData interactionData, IMotifData md, int threads)
    {
        super(interactionData, md, threads);

        System.out.println("preprocessing done");
    }
    
    public String getName()
    {
        return ScoreFunctionFactory.$V + "-l" + MaskArray.$subsequenceLength + "d" + MaskArray.$wildCards;
    }

    /**
     * 
     * @param SM1	A SORTED char[] of nodes
     * @param SM2	A SORTED char[] of nodes
     * @return		The v-score of the subnetwork
     */
    protected double getScore(char[] SM1, char[] SM2)
    {
        int OM1M2 = $interactionData.getObservedInteractions(SM1, SM2);
	
	if(OM1M2 == 0)
	    return worstScore();

        double max = $interactionData.getMaximumInteractions(SM1, SM2);

        int overlap = 0;
        for (int i = 0; i < SM1.length; i++)
        {
            if ( Arrays.binarySearch(SM2, SM1[i]) >= 0)
            {
                overlap++;
            }
        }

        return OM1M2 / (max + SM1.length + SM2.length - overlap);
    }

    /**
     * 
     * @return	    The worst possible score, in this case 0
     */
    public double worstScore()
    {
        return 0;
    }

    /**
     * 
     * @param score1	    A score
     * @param score2	    A score
     * @return		    Whether score1 is better than score2, in this case whether it is bigger
     */
    public boolean isBetterScore(double score1, double score2)
    {
        return score1 > score2;
    }

    @Override
    public String getScoreType()
    {
        return ScoreFunctionFactory.$V;
    }
}
