package ScoreFunctions;

import Data.MotifData.MaskArray;

/**
 * This is a simple score function, that is used for testing purposes (e.g. of the
 * {@link Util.TopMotifPairScores}).
 * 
 * @author Peter Boyen
 */
public class TestScoreFunction extends AbstractScoreFunction
{

    /**
     * Creates a new instance of TestScoreFunction
     */
    public TestScoreFunction()
    {
        super(null, null, 1);
    }

    public String getName()
    {
        return "TestScore" + "-l" + MaskArray.$subsequenceLength + "d" + MaskArray.$wildCards;
    }

    /**
     * Returns 0;
     * 
     * @param SM1       An array of nodes
     * @param SM2       An array of nodes
     * @return          0
     */
    @Override
    protected double getScore(char[] SM1, char[] SM2)
    {
        return worstScore();
    }

    /**
     * 
     * @return          0
     */
    @Override
    public double worstScore()
    {
        return 0.0;
    }

    /**
     * 
     * smaller than
     * 
     * @param score1        A score
     * @param score2        A score
     * @return              returns whether score1 is smaller than score2
     */
    @Override
    public boolean isBetterScore(double score1, double score2)
    {
        return score1 < score2;
    }

    /**
     * All scores are the worst score, so this function always returns true.
     * 
     * @param motif     The motif
     * @return          true
     */
    @Override
    public boolean scoresWorst(int motif)
    {
        return true;
    }

    @Override
    public String getScoreType()
    {
        throw new UnsupportedOperationException("This class can't be made by the factory");
    }
}
