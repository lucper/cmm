package ScoreFunctions.Triplets;

import Data.InteractionData.Triplets.IInteractionDataTriplets;
import Data.MotifData.IMotifData;
import Data.MotifData.MaskArray;
import java.util.Arrays;

/**
 * This function will calculate the Chi squared function (With the exception that we
 * return zero if the observed amount is smaller than the expected value).
 * <p/>
 * The expected value of edges between nodes is calculated using the average over the
 * entire network.
 * 
 * @author Peter Boyen
 */
public class X2ScoreFunctionTriplets extends AbstractScoreFunctionTriplets
{

    private double $edG;

    /**
     * Creates a new instance of X2ScoreFunction, is called from the {@link ScoreFunctionFactory}.
     * 
     * @param interactionData       The interaction data, can be created using an {@link Data.InteractionData.IInteractionDataFactory}, such as {@link Data.InteractionData.InteractionArrayFactory}.
     * @param md                    The motif data, can be created using the interaciton data.
     * @param threads               The amount of threads the score function can use to preprecoess the data, and the amount of threads that coul simultaneously access the score function (assumed to be the same).
     */
    protected X2ScoreFunctionTriplets(IInteractionDataTriplets interactionData, IMotifData md, int threads)
    {
        super(interactionData, md, threads);

        if ($interactionData != null)
        {
            double I = $interactionData.getNumberOfInteractions();
            double Scomb2 = $interactionData.getMaximumInteractions();

            $edG = (I / Scomb2);
        }
    }

    public String getName()
    {
        return this.getClass().getName() + "-l" + MaskArray.$subsequenceLength + "d" + MaskArray.$wildCards + (MINIMUMSIZE == 0 ? "" : "minSize" + MINIMUMSIZE);
    }

    /**
     * 
     * @param SM1	A SORTED char[] of nodes
     * @param SM2	A SORTED char[] of nodes
     * @return		The Chi squared score for the subnetwork
     */
    protected double getScore(char[] SM1, char[] SM2, char[] SM3)
    {
        int OM1M2 = $interactionData.getObservedInteractions(SM1, SM2, SM3);

        double ES1S2 = getExpectedObservations(SM1, SM2, SM3);

        if (OM1M2 <= ES1S2)
        {
            return worstScore();
        }

        return (OM1M2 - ES1S2) * (OM1M2 - ES1S2) / ES1S2;
    }

    /**
     * Given the amount of interactions and the size of the full network, we calculate
     * the expected amount of interactions of this subnetwork (assuming a uniform
     * distribution of these interactions across the network).
     * 
     * @param SM1	    A SORTED char[] of nodes
     * @param SM2	    A SORTED char[] of nodes
     * @return		    The expected amount of interactions between these nodes
     */
    protected double getExpectedObservations(char[] SM1, char[] SM2, char[] SM3)
    {
        double max = $interactionData.getMaximumInteractions(SM1, SM2, SM3);

        // The average fraction * the maximum amount of interactions
        return $edG * max;
    }

    /**
     * 
     * @return	    The worst possible score, int this case 0
     */
    public double worstScore()
    {
        return 0.0;
    }

    /**
     * 
     * @param score1	    A score
     * @param score2	    A score
     * @return		    Whether score1 is better than score2, in this case whether it is bigger
     */
    public boolean isBetterScore(double score1, double score2)
    {
        return score1 > score2;
    }

    @Override
    public String getScoreType()
    {
        return this.getClass().getName();
    }
}
