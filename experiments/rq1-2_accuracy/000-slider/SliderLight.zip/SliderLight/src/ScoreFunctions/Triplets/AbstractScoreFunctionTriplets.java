package ScoreFunctions.Triplets;

import Data.InteractionData.Triplets.IInteractionDataTriplets;
import Data.MotifData.IMotifData;
import ScoreFunctions.ScoreComparators.IScoreComparator;

/**
 * @author Peter Boyen
 */
public abstract class AbstractScoreFunctionTriplets implements IScoreComparator
{
    public static int MINIMUMSIZE = 0;
    
    /**
     * The interaction data holds the information of which nodes interact.
     */
    protected IInteractionDataTriplets $interactionData;
    /**
     * The motif data holds the information of which nodes hold which motifs (or which motifs occur in which nodes)
     */
    protected IMotifData $motifData;

    /**
     * Creates a new instance of AbstractScoreFunctionTriplets.
     * 
     * @param interactionData       The necessary interaction data. This can be made using a {@link Data.InteractionData.IInteractionDataFactory}, such as {@link Data.InteractionData.InteractionArrayFactory}.
     * @param md                    The motif data can be made using the interaction data.
     * @param threads               The amount of threads the score function can use to preprocess and the amount of threads it can be called from (assumed to be the same)
     */
    public AbstractScoreFunctionTriplets(IInteractionDataTriplets interactionData, IMotifData md, int threads)
    {
        $interactionData = interactionData;
        $motifData = md;
    }

    public double score(char[] SM1, char[] SM2, char[] SM3)
    {
        if (SM1 == null || SM2 == null || SM3 == null || SM1.length <= MINIMUMSIZE || SM2.length <= MINIMUMSIZE || SM3.length <= MINIMUMSIZE)
        {
            return worstScore();
        }

        return getScore(SM1, SM2, SM3);
    }
    
    public abstract String getName();

    /**
     * This is the most important function all score functions must implement.
     * Given three lists of nodes, what is the score.
     * 
     * @return		The score of the subnetwork
     */
    protected abstract double getScore(char[] SM1, char[] SM2, char[] SM3);

    /**
     * 
     * @return	    The worst possible score for the score function
     */
    public abstract double worstScore();

    /**
     * Some scores are the bigger, the better. Some are the other way around. This function
     * returns given two scores which is better. The function should return if it is strictly better,
     * two scores are asummed to be equally good if their doubles are equal.
     * 
     * @param score1	    A score
     * @param score2	    A score
     * @return		    Whether score1 is better than score2
     */
    public abstract boolean isBetterScore(double score1, double score2);

    /**
     * will return true if the motif doesn't occur in the data. This can be overwritten
     * if other guarantees of having the worst score can be determined.
     * 
     * @param motif	A motif
     * @return		Whether any pair containing this motif will automatically get the worst score
     */
    public boolean scoresWorst(int motif)
    {
        return $motifData.getAmountOfSequencesWithMotif(motif) <= MINIMUMSIZE;
    }

    /**
     * This will call the scoresWorst(int motif) function
     *
     * @param motif	A String of the motif
     * @return		If it is sure this motif will get the worstScore()
     */
    public boolean scoresWorst(String motif)
    {
        return $motifData.getAmountOfSequencesWithMotif(motif) <= MINIMUMSIZE;
    }

    /**
     * This function will return true if the motif is guaranteed to score worse than the
     * minScore. This function must not be implemented by all subclasses and may throw
     * an UnsupportedOperationException
     *
     * @param motif
     * @param minScore
     * @return
     */
    public boolean scoresWorse(int motif, double minScore)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * This functions returns the minimum necessary size for a partner of the
     * motif, for the motif to possibly outscore minScore. This function must
     * not be implemented by all subclasses and may throw an UnsupportedOperationException
     *
     * @param motif
     * @param minScore
     * @return
     */
    public int minimumPartnerSize(int motif, double minScore)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * This functions returns the maximum allowed size for a partner of the
     * motif, for the motif to possibly outscore minScore. This function must
     * not be implemented by all subclasses and may throw an UnsupportedOperationException
     * 
     * @param motif
     * @param minScore
     * @return
     */
    public int maximumPartnerSize(int motif, double minScore)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * 
     * @return      The used {@link MotifData}
     */
    public IMotifData getMotifData()
    {
        return $motifData;
    }

    /**
     * 
     * @return      The used {@link IInteractionDataTriplets}
     */
    public IInteractionDataTriplets getInteractionData()
    {
        return $interactionData;
    }

    /**
     * This function will use the {@link MotifData} to get the proteins containing these motifs. It then
     * calls the abstract getScore() function.
     * 
     * @param m1	A String of a motif
     * @param m2	A String of a motif
     * @return		The score of the motif pair
     */
    public double score(String m1, String m2, String m3)
    {
        char[] SM1 = $motifData.getProteinsWithSequencesWithMotif(m1);
        char[] SM2 = $motifData.getProteinsWithSequencesWithMotif(m2);
        char[] SM3 = $motifData.getProteinsWithSequencesWithMotif(m3);

        if (SM1 == null || SM2 == null || SM3 == null)
        {
            return worstScore();
        }

        return getScore(SM1, SM2, SM3);
    }

    /**
     * This function will use the {@link MotifData} to get the list of proteins with these motifs. With
     * these lists the abstract getScore() function is called.
     * 
     * @param motifm1	    The number of a motif
     * @param motifm2	    The number of a motif
     * @return		    The score of the motif pair
     */
    public double score(int motifm1, int motifm2, int motifm3)
    {
        char[] SM1 = $motifData.getProteinsWithSequencesWithMotif(motifm1);
        char[] SM2 = $motifData.getProteinsWithSequencesWithMotif(motifm2);
        char[] SM3 = $motifData.getProteinsWithSequencesWithMotif(motifm3);

        if (SM1 == null || SM2 == null || SM3 == null)
        {
            return worstScore();
        }

        return getScore(SM1, SM2, SM3);
    }
    
    public abstract String getScoreType();
}
