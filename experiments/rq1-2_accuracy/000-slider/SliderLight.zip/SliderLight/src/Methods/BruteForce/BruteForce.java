package Methods.BruteForce;

import Data.MotifData.MaskArray;
import Methods.AbstractMethod;
import Util.ScoreKeeping.TopMotifPairScores;
import ScoreFunctions.AbstractScoreFunction;
import Util.ProgressTracker;

/**
 * This class uses a brute force method to calculate the scores of motif pairs. The difference
 * between this and a normal brute force is that this only calculates part of the possible
 * pairs. A set amount of motifs is skipped each time for consideration of the first motif in
 * the pair. This allows for sampling without full calculation, or for distribution of the full
 * calculation (which is done by {@link BruteForceThreaded}).
 * 
 * @author Peter Boyen
 */
public class BruteForce extends AbstractMethod
{

    public static final String BRUTEFORCE = "BF";
    private AbstractScoreFunction $scoreFunction;
    private int $amount;
    private int $modulo;
    private int $step;

    // defaults to regular BruteForce
    public BruteForce(AbstractScoreFunction scoreFunction, int amount)
    {
        this(scoreFunction, amount, 1, 0);
    }

    public BruteForce(AbstractScoreFunction scoreFunction, int amount, int modulo, int step)
    {
        $scoreFunction = scoreFunction;
        $amount = amount;
        $modulo = modulo;
        $step = step;
    }

    public String getName()
    {
        return $scoreFunction.getName() + "-" + $amount + BRUTEFORCE + "(" + $modulo + "-" + $step + ")";
    }

    /**
     * Splits up the method in submethods for parallellization
     *
     * @param amount
     * @return
     */
    public BruteForce[] splitInSubmethods(int amount)
    {
        BruteForce[] methods = new BruteForce[amount];

        for (int i = 0; i < amount; i++)
        {
            methods[i] = new BruteForce($scoreFunction, $amount, amount, i);
        }

        return methods;
    }

    /**
     * Calculates the top motif pairs in this given set and stores the result in a file.
     * <p/>
     * Example: <br/>
     * scoreFunction can be created using the {@link ScoreFunctions.ScoreFunctionFactory}. <br/>
     * getTopScores(scoreFunction, 8, 3, 100, "/networks/bZip/results", 7, 0); <br/>
     * <p/>
     * Output: <br/>
     * A file called outputPrefix+".txt" will be created. It will contain the amount best scoring motif pairs and their scores.
     * Also a file called outputPrefix+"stat.txt" will be created.
     * This file contain in order:
     * <ul>
     * <li>The sum of all scores (with a score different from ScoreFunction.worstScore())<li/>
     * <li>The sum of all squared scores (with a score different from ScoreFunction.worstScore())<li/>
     * <li>The amount of scores (with a score different from ScoreFunction.worstScore())<li/>
     * <li>The mean of these scores<li/>
     * <li>The variance of these scores<li/>
     * <li>The standard deviation of these scores<li/>
     * </ul>
     * 
     * @param scoreFunction         The score function to use (this can be created using the {@link ScoreFunctions.ScoreFunctionFactory}).
     * @param amount                The amount of best scores to keep
     * @param outputPrefix          The String indicating the necessarty folder and file for the output, but without ".txt" (e.g. folder/name will result in an output file in folder/ called name.txt).
     * @param modulo                The amount of motifs to skip every time (e.g. 7 -> look at every seventh motif)
     * @param step                  The starting point (e.g. 2 -> look at motif 2, 2 + 7, 2 + 14,...)
     */
    public TopMotifPairScores calculateTopScores()
    {
        int amountOfMotifs = MaskArray.getInstance().getAmountOfMotifs();

        TopMotifPairScores topScores = new TopMotifPairScores($amount);

        ProgressTracker tracker = new ProgressTracker(amountOfMotifs / $modulo, 100);

        // For every motif to be considered (always skip modulo motifs)
        for (int m1 = $step; m1 < amountOfMotifs; m1 += $modulo)
        {
            // Don't consider motifs that don't occur (or not enough)
            if (!$scoreFunction.scoresWorst(m1))
            {
                // For every motif, don't skip
                for (int m2 = m1; m2 < amountOfMotifs; m2++)
                {
                    // Don't consider motifs that don't occur (or not enough)
                    if (!$scoreFunction.scoresWorst(m2))
                    {
                        double score = $scoreFunction.score(m1, m2);

                        topScores.saveScoreIfBetter(m1, m2, score, $scoreFunction);
                    }
                }
            }

            if (tracker.hasOutput(m1 / $modulo))
            {
                System.out.println("thread " + $step);
                System.out.println(tracker.getOutput(m1 / $modulo));
                if (topScores.size() > 0)
                {
                    System.out.println("Current best score: " + topScores.getMotifScorePair(0).toString());
                } else
                {
                    System.out.println("No good scores found yet");
                }
            }
        }

        return topScores;
    }
}
