package Methods.BruteForce.Triplets;

import Data.MotifData.MaskArray;
import Methods.AbstractMethod;
import Util.ScoreKeeping.TopMotifPairScores;
import ScoreFunctions.Triplets.AbstractScoreFunctionTriplets;
import Util.ProgressTracker;

/**
 * @author Peter Boyen
 */
public class BruteForceTriplets extends AbstractMethod
{

    private AbstractScoreFunctionTriplets $scoreFunction;
    private int $amount;
    private int $modulo;
    private int $step;

    // defaults to regular BruteForce
    public BruteForceTriplets(AbstractScoreFunctionTriplets scoreFunction, int amount)
    {
        this(scoreFunction, amount, 1, 0);
    }

    public BruteForceTriplets(AbstractScoreFunctionTriplets scoreFunction, int amount, int modulo, int step)
    {
        $scoreFunction = scoreFunction;
        $amount = amount;
        $modulo = modulo;
        $step = step;
    }

    public String getName()
    {
        return $scoreFunction.getName() + "-" + $amount + this.getClass().getName() + "(" + $modulo + "-" + $step + ")";
    }

    /**
     * Splits up the method in submethods for parallellization
     *
     * @param amount
     * @return
     */
    public BruteForceTriplets[] splitInSubmethods(int amount)
    {
        BruteForceTriplets[] methods = new BruteForceTriplets[amount];

        for (int i = 0; i < amount; i++) {
            methods[i] = new BruteForceTriplets($scoreFunction, $amount, amount, i);
        }

        return methods;
    }

    /**
     *
     * @return      The best scoring motif triplets
     */
    public TopMotifPairScores calculateTopScores()
    {
        MaskArray m = MaskArray.getInstance();
        int amountOfMotifs = m.getAmountOfMotifs();

        TopMotifPairScores topScores = new TopMotifPairScores($amount);

        ProgressTracker tracker = new ProgressTracker(amountOfMotifs / $modulo, 100);

        // For every motif to be considered (always skip modulo motifs)
        for (int m1 = $step; m1 < amountOfMotifs; m1 += $modulo) {
            // Don't consider motifs that don't occur (or not enough)
            if (!$scoreFunction.scoresWorst(m1)) {
                // For every motif, don't skip
                for (int m2 = m1; m2 < amountOfMotifs; m2++) {
                    // Don't consider motifs that don't occur (or not enough)
                    if (!$scoreFunction.scoresWorst(m2)) {
                        // For every motif, don't skip
                        for (int m3 = m2; m3 < amountOfMotifs; m3++) {
                            // Don't consider motifs that don't occur (or not enough)
                            if (!$scoreFunction.scoresWorst(m3)) {

                                double score = $scoreFunction.score(m1, m2, m3);

                                topScores.saveScoreIfBetter(m.getMotifString(m1), m.getMotifString(m2)+"-"+m.getMotifString(m3), score, $scoreFunction);
                            }
                        }
                    }
                }
            }

            if (tracker.hasOutput(m1 / $modulo)) {
                System.out.println("thread " + $step);
                System.out.println(tracker.getOutput(m1 / $modulo));
                if (topScores.size() > 0) {
                    System.out.println("Current best score: " + topScores.getMotifScorePair(0).toString());
                } else {
                    System.out.println("No good scores found yet");
                }
            }
        }

        return topScores;
    }
}
