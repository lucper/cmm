package Methods;

import Util.RunInformation.Statistics;
import Util.RunInformation.Time;
import Util.ScoreKeeping.ITopScores;

/**
 *
 * @author Peter Boyen
 */
public abstract class AbstractMethod
{

    protected Statistics $statistics;

    public ITopScores getTopScores()
    {
        $statistics = new Statistics();

        Time time = new Time();
        time.start();

        ITopScores topScores = calculateTopScores();

        time.stop();
        $statistics.put("time", time);

        return topScores;
    }

    public Statistics getStatistics()
    {
        return $statistics;
    }

    public abstract AbstractMethod[] splitInSubmethods(int amount);

    protected abstract ITopScores calculateTopScores();
    
    public abstract String getName();
}
