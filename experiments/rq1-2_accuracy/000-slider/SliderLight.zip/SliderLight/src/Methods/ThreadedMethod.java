package Methods;

import Data.MotifData.CachingMotifData;
import ScoreFunctions.AbstractScoreFunction;
import ScoreFunctions.ScoreFunctionFactory;
import Util.ScoreKeeping.ITopScores;
import Util.RunInformation.Statistics;

/**
 *
 * @author Peter Boyen
 */
public class ThreadedMethod extends AbstractMethod
{

    private AbstractMethod[] $methods;
    private MethodThread[] $threads;
    private AbstractScoreFunction $scoreFunction;
    private String $methodName;

    public ThreadedMethod(AbstractMethod method, int threads, AbstractScoreFunction scoreFunction)
    {
        $methodName = method.getName() + "Threaded";
        $methods = method.splitInSubmethods(threads);
        $scoreFunction = scoreFunction;
    }

    public String getName()
    {
        return $methodName;
    }

    public ITopScores calculateTopScores()
    {
        startThreads();

        waitForThreads();

        System.out.println("computation done, merging results");

        return mergeResults();
    }

    public void startThreads()
    {
        $threads = new MethodThread[$methods.length];

        AbstractScoreFunction newScoreFunction = $scoreFunction;

        for (int i = 0; i < $threads.length; i++)
        {
            if ($scoreFunction.getMotifData().wantsCaching())
            {
                int cacheSize = 1000;
                newScoreFunction = ScoreFunctionFactory.getScoreFunction($scoreFunction.getScoreType(), $scoreFunction.getInteractionData(), new CachingMotifData($scoreFunction.getMotifData(), cacheSize), $threads.length);
            }

            $threads[i] = new MethodThread($methods[i]);
            $threads[i].start();
        }
    }

    public void waitForThreads()
    {
        boolean done = false;

        while (!done)
        {
            done = true;
            for (int i = 0; done && i < $threads.length; i++)
            {
                if (!$threads[i].isFinished())
                {
                    done = false;
                    try
                    {
                        Thread.sleep(3000);
                    } catch (InterruptedException e)
                    {
                    }
                }
            }
        }
    }

    public ITopScores mergeResults()
    {
        ITopScores topScores = $threads[0].getTopScores();

        for (int i = 1; i < $threads.length; i++)
        {
            topScores.add($threads[i].getTopScores(), $scoreFunction);
        }

        return topScores;
    }

    @Override
    public Statistics getStatistics()
    {
        Statistics statistics = $threads[0].getStatistics();

        if (statistics == null)
        {
            return null;
        }

        for (int i = 1; i < $threads.length; i++)
        {
            statistics.add($threads[i].getStatistics());
        }

        return statistics;
    }

    public AbstractMethod[] splitInSubmethods(int amount)
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private class MethodThread extends Thread
    {

        private boolean $isFinished;
        private AbstractMethod $method;
        private ITopScores $topScores;
        private Statistics $statistics;

        public MethodThread(AbstractMethod m)
        {
            $isFinished = false;

            $method = m;
        }

        @Override
        public void run()
        {
            $topScores = $method.getTopScores();
            try
            {
                $statistics = $method.getStatistics();
            } catch (UnsupportedOperationException e)
            {
                $statistics = null;
            }

            $method = null;

            $isFinished = true;
        }

        public boolean isFinished()
        {
            return $isFinished;
        }

        public ITopScores getTopScores()
        {
            return $topScores;
        }

        public Statistics getStatistics()
        {
            return $statistics;
        }
    }
}
