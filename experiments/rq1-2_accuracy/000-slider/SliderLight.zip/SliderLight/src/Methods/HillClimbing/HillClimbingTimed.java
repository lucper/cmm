package Methods.HillClimbing;

import Methods.AbstractMethod;
import Methods.HillClimbing.Climbers.IClimber;
import Methods.HillClimbing.SeedIterators.ISeedIterator;
import Methods.HillClimbing.SeedIterators.RandomSeedIterator;
import ScoreFunctions.AbstractScoreFunction;
import Util.CPUTime;
import Util.Pairs.MotifPair;
import Util.Pairs.MotifPairScorePair;
import Util.RunInformation.SingleNumber;
import Util.RunInformation.Statistics;
import Util.ScoreKeeping.ITopScores;
import Util.ScoreKeeping.TopMotifPairScores;

/**
 *
 * @author Peter Boyen
 */
public class HillClimbingTimed extends AbstractMethod
{

    public static final String HILLCLIMBINGTIMED = "HCTimed";
    private AbstractScoreFunction $scoreFunction;
    private double $minutes;
    private long $time;
    private int $amountToKeep;
    private IClimber $climber;
    private boolean $statsAdded;
    private ISeedIterator $seeds;

    public HillClimbingTimed(AbstractScoreFunction scoreFunction, double minutes, int amountToKeep, IClimber climber, ISeedIterator seeds)
    {
        $climber = climber;
        $scoreFunction = scoreFunction;
        $minutes = minutes;
        $time = (long) (minutes * 1000) * 60L * 1000L * 1000L;
        $amountToKeep = amountToKeep;

        $seeds = seeds;
        if ($seeds == null)
        {
            $seeds = new RandomSeedIterator($scoreFunction.getInteractionData());
        }

        $statsAdded = false;
    }

    public String getName()
    {
        return $scoreFunction.getName() + "-" + $amountToKeep + "in" + $minutes + "min" + HILLCLIMBINGTIMED + $climber.getName() + $seeds.getName();
    }

    @Override
    public HillClimbingTimed[] splitInSubmethods(int amount)
    {
        HillClimbingTimed[] result = new HillClimbingTimed[amount];

        for (int i = 0; i < amount; i++)
        {
            result[i] = new HillClimbingTimed($scoreFunction, $minutes / (double) amount, $amountToKeep, $climber.copy(), null);
        }

        return result;
    }

    @Override
    public ITopScores calculateTopScores()
    {
        TopMotifPairScores topScores = new TopMotifPairScores($amountToKeep);

        long start = CPUTime.getCpuTime();

        int motifPairs = 0;

        while (CPUTime.getCpuTime() - start < $time)
        {
            // Take seeds
            MotifPair motifPair = $seeds.next();
            MotifPairScorePair motifPairScorePair = new MotifPairScorePair(motifPair.toString(), $scoreFunction.score(motifPair.$fst, motifPair.$snd));

            MotifPairScorePair result = $climber.climb(motifPairScorePair, topScores);

            topScores.saveScoreIfBetter(result, $scoreFunction);

            motifPairs++;
        }

        $statistics.put("motifPairs", new SingleNumber(motifPairs));

        return topScores;
    }

    @Override
    public Statistics getStatistics()
    {
        if (!$statsAdded)
        {
            $statistics.add($climber.getStatistics());
            $statsAdded = true;
        }

        return super.getStatistics();
    }
}
