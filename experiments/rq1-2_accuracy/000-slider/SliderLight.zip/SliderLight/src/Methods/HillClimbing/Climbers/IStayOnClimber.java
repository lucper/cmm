package Methods.HillClimbing.Climbers;

import Util.Pairs.Edge;
import Util.Pairs.MotifPairScorePair;
import Util.RunInformation.Statistics;
import Util.ScoreKeeping.TopMotifPairScores;

/**
 *
 * @author Peter Boyen
 */
public interface IStayOnClimber {

    public String getName();

    public void clearStatistics();

    public Statistics getStatistics();

    public MotifPairScorePair climb(Edge seed, TopMotifPairScores topScores);
    
    public IStayOnClimber copy();
}
