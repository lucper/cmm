/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Methods.HillClimbing;

import Data.InteractionData.IInteractionData;
import Data.MotifData.MaskArray;
import Methods.AbstractMethod;
import Methods.HillClimbing.Climbers.IStayOnClimber;
import ScoreFunctions.AbstractScoreFunction;
import Util.CPUTime;
import Util.Pairs.Edge;
import Util.Pairs.MotifPairScorePair;
import Util.RunInformation.SingleNumber;
import Util.ScoreKeeping.ITopScores;
import Util.ScoreKeeping.TopMotifPairScores;

/**
 *
 * @author Peter
 */
public class StayOnHillClimbingTimed extends AbstractMethod
{

    public static final String STAYONHILLCLIMBINGTIMED = "HCStayOnTimed";

    private AbstractScoreFunction $scoreFunction;
    private IInteractionData $interactionData;
    private double $minutes;
    private long $time;
    private int $amountToKeep;
    private boolean $keepPassed;
    private IStayOnClimber $climber;

    public StayOnHillClimbingTimed(AbstractScoreFunction scoreFunction, double minutes, int amountToKeep, IStayOnClimber climber)
    {
        $climber = climber;
        $scoreFunction = scoreFunction;
        $interactionData = scoreFunction.getInteractionData();
        $minutes = minutes;
        $time = (long)(minutes * 1000) * 60L * 1000L * 1000L;
        
        $amountToKeep = amountToKeep;
    }

    public String getName()
    {
        return $scoreFunction.getName() + "-" + $amountToKeep + "in" + $minutes + "min" + STAYONHILLCLIMBINGTIMED + ($keepPassed ? "KeepPassed" : "") + $climber.getName();
    }

    @Override
    public StayOnHillClimbingTimed[] splitInSubmethods(int amount)
    {
        StayOnHillClimbingTimed[] result = new StayOnHillClimbingTimed[amount];
        
        for (int i = 0; i < amount; i++)
        {
            result[i] = new StayOnHillClimbingTimed($scoreFunction, $minutes / (double) amount, $amountToKeep, $climber.copy());
        }
        
        return result;
    }

    @Override
    protected ITopScores calculateTopScores()
    {
        TopMotifPairScores topScores = new TopMotifPairScores($amountToKeep);

        long start = CPUTime.getCpuTime();

        int motifPairs = 0;

        while (CPUTime.getCpuTime() - start < $time)
        {
            // Take seeds
            Edge e = $interactionData.getRandomInteractionFromData();

            MotifPairScorePair result = $climber.climb(e, topScores);

            topScores.saveScoreIfBetter(result, $scoreFunction);

            motifPairs++;
        }

        $statistics.put("motifPairs", new SingleNumber(motifPairs));

        return topScores;
    }
}
