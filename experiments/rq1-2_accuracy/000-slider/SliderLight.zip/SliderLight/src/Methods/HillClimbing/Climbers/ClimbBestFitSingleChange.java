package Methods.HillClimbing.Climbers;

import Data.MotifData.MotifFunctions;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.ISequenceNeighbourIterator;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.SequenceIteratorFactory;
import ScoreFunctions.AbstractScoreFunction;
import Util.Pairs.MotifPairScorePair;
import Util.RunInformation.AvgVarStdDev;
import Util.RunInformation.PositiveNumberCount;
import Util.RunInformation.SingleNumber;
import Util.RunInformation.Statistics;
import Util.ScoreKeeping.TopMotifPairScores;

/**
 *
 * @author Peter Boyen
 */
public class ClimbBestFitSingleChange implements IClimber
{

    public static final String BESTFITSINGLE = "BestFitSingleChange";
    private AbstractScoreFunction $scoreFunction;
    private String $iteratorType;
    private Statistics $statistics;
    private AvgVarStdDev $steps;
    private PositiveNumberCount $stepCounter;
    private SingleNumber $neighbourCounter;
    private boolean $keepPassed;

    public ClimbBestFitSingleChange(AbstractScoreFunction scoreFunction, String iteratorType, boolean keepPassed)
    {
        $scoreFunction = scoreFunction;
        $iteratorType = iteratorType;

        $keepPassed = keepPassed;

        clearStatistics();
    }

    public ClimbBestFitSingleChange copy()
    {
        return new ClimbBestFitSingleChange($scoreFunction, $iteratorType, $keepPassed);
    }

    public String getName()
    {
        return BESTFITSINGLE + ($keepPassed ? "KeepPassed" : "") + $iteratorType;
    }

    public void clearStatistics()
    {
        $statistics = new Statistics();
        $steps = new AvgVarStdDev();
        $statistics.put("steps", $steps);

        $stepCounter = new PositiveNumberCount();
        $statistics.put("full step info", $stepCounter);

        $neighbourCounter = new SingleNumber(0);
        $statistics.put("total neighbours considered", $neighbourCounter);
    }

    public Statistics getStatistics()
    {
        return $statistics;
    }

    public MotifPairScorePair climb(MotifPairScorePair motifPairScorePair, TopMotifPairScores topScores)
    {
        String m1 = motifPairScorePair.$fst.$fst;
        String m2 = motifPairScorePair.$fst.$snd;

        if ($scoreFunction.scoresWorst(m1) || $scoreFunction.scoresWorst(m2))
        {
            return motifPairScorePair;
        }

        boolean change = true;
        double score = motifPairScorePair.$snd;

        int steps = -1;
        int consideredNeighbours = 0;

        while (change)
        {
            change = false;

            //System.out.println(m1 + " " + m2 + " " + score);

            String newm1 = m1;
            String newm2 = m2;

            // for every seed, check its neighbours
            ISequenceNeighbourIterator it1 = SequenceIteratorFactory.getSequenceIterator($iteratorType, m1);
            while (it1.hasNext())
            {
                String m1neighbour = it1.next();

                if (!$scoreFunction.scoresWorst(m1neighbour))
                {
                    String m2neighbour = m2;

                    // m2 should never score worst

                    consideredNeighbours++;

                    if ($scoreFunction.getInteractionData().getObservedInteractions($scoreFunction.getMotifData().getProteinsWithSequencesWithMotif(m1neighbour), $scoreFunction.getMotifData().getProteinsWithSequencesWithMotif(m2neighbour)) > 0)
                    {
                        //System.out.println(m1neighbour + " " + m2neighbour);
                        //System.out.println(l1 + " " + l2);
                        double neighbourScore = $scoreFunction.score(m1neighbour, m2neighbour);

                        if ($keepPassed)
                        {
                            topScores.saveScoreIfBetter(m1neighbour, m2neighbour, neighbourScore, $scoreFunction);
                        }

                        if ($scoreFunction.isBetterScore(neighbourScore, score))
                        {
                            // Take the best neighbour as the new seed
                            score = neighbourScore;
                            newm1 = m1neighbour;
                            newm2 = m2neighbour;

                            change = true;


                        }
                    }
                }
            }

            steps++;
            m1 = newm2;
            m2 = newm1;
        }

        //System.out.println("final: " + m1 + " " + m2 + " " + score);
        $steps.numberFromSequence(steps);
        $stepCounter.numberFromSequence(steps);
        $neighbourCounter.add(new SingleNumber(consideredNeighbours));

        return new MotifPairScorePair(MotifFunctions.makeMotifPair(m1, m2), score);
    }
}
