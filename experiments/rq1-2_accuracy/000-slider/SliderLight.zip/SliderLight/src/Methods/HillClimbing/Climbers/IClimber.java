package Methods.HillClimbing.Climbers;

import Util.Pairs.MotifPairScorePair;
import Util.RunInformation.Statistics;
import Util.ScoreKeeping.TopMotifPairScores;

/**
 *
 * @author Peter Boyen
 */
public interface IClimber
{

    public String getName();

    public void clearStatistics();

    public Statistics getStatistics();

    public MotifPairScorePair climb(MotifPairScorePair motifPairScorePair, TopMotifPairScores topScores);
    
    public IClimber copy();
}
