package Methods.HillClimbing.Climbers;

import Data.InteractionData.IInteractionData;
import Data.MotifData.MaskArray;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.SequenceSlideIterator;
import ScoreFunctions.AbstractScoreFunction;
import Util.Pairs.Edge;
import Util.Pairs.MotifPair;
import Util.Pairs.MotifPairScorePair;
import Util.RunInformation.AvgVarStdDev;
import Util.RunInformation.PositiveNumberCount;
import Util.RunInformation.SingleNumber;
import Util.RunInformation.Statistics;
import Util.ScoreKeeping.TopMotifPairScores;
import java.util.Random;

/**
 *
 * @author Peter Boyen
 */
public class StayOnClimbBestFitSingleChange implements IStayOnClimber
{
    public static final String STAYONCLIMBBESTFITSINGLE = "StayOnBestFitSingleChange";
    
    private AbstractScoreFunction $scoreFunction;
    private String $iteratorType;
    private Statistics $statistics;
    private AvgVarStdDev $steps;
    private PositiveNumberCount $stepCounter;
    private SingleNumber $neighbourCounter;
    private boolean $keepPassed;
    private IInteractionData $interactionData;

    public StayOnClimbBestFitSingleChange(AbstractScoreFunction scoreFunction, String iteratorType, boolean keepPassed)
    {
        $scoreFunction = scoreFunction;
        $interactionData = scoreFunction.getInteractionData();
        $iteratorType = iteratorType;

        $keepPassed = keepPassed;

        clearStatistics();
    }
    
    public StayOnClimbBestFitSingleChange copy()
    {
        return new StayOnClimbBestFitSingleChange($scoreFunction, $iteratorType, $keepPassed);
    }
    
    public String getName()
    {
        return STAYONCLIMBBESTFITSINGLE  + ($keepPassed ? "KeepPassed" : "") + $iteratorType;
    }

    public void clearStatistics()
    {
        $statistics = new Statistics();
        $steps = new AvgVarStdDev();
        $statistics.put("steps", $steps);

        $stepCounter = new PositiveNumberCount();
        $statistics.put("full step info", $stepCounter);

        $neighbourCounter = new SingleNumber(0);
        $statistics.put("total neighbours considered", $neighbourCounter);
    }

    public Statistics getStatistics()
    {
        return $statistics;
    }

    public MotifPairScorePair climb(Edge e, TopMotifPairScores topScores)
    {
        String sequence1 = $interactionData.getSequence(e.$fst);
        String sequence2 = $interactionData.getSequence(e.$snd);

        int startPos1 = new Random().nextInt(sequence1.length() - MaskArray.$subsequenceLength);
        String m1 = MaskArray.getInstance().applyMask(sequence1.substring(startPos1, startPos1 + MaskArray.$subsequenceLength), MaskArray.getInstance().getRandomMask());

        int startPos2 = new Random().nextInt(sequence2.length() - MaskArray.$subsequenceLength);
        String m2 = MaskArray.getInstance().applyMask(sequence2.substring(startPos2, startPos2 + MaskArray.$subsequenceLength), MaskArray.getInstance().getRandomMask());

        double score = $scoreFunction.score(m1, m2);
        boolean change = true;

        while (change)
        {
            change = false;

            String newm1 = m1;
            String newm2 = m2;

            SequenceSlideIterator it1 = new SequenceSlideIterator(sequence1, m1);

            while (it1.hasNext())
            {
                String m1neighbour = it1.next();

                if (!$scoreFunction.scoresWorst(m1neighbour))
                {
                    double neighbourScore = $scoreFunction.score(m1neighbour, m2);

                    if ($keepPassed)
                    {
                        topScores.saveScoreIfBetter(m1neighbour, m2, neighbourScore, $scoreFunction);
                    }

                    if ($scoreFunction.isBetterScore(neighbourScore, score))
                    {
                        // Take the best neighbour as the new seed
                        score = neighbourScore;
                        newm1 = m1neighbour;
                        newm2 = m2;

                        change = true;
                    }

                }
            }

            m1 = newm2;
            m2 = newm1;

            String temp = sequence1;
            sequence1 = sequence2;
            sequence2 = temp;
        }

        return new MotifPairScorePair(new MotifPair(m1, m2), score);
    }
}
