/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Methods.HillClimbing.SeedIterators;

import Util.Pairs.MotifPair;
import java.util.Iterator;

/**
 *
 * @author Peter
 */
public interface ISeedIterator extends Iterator<MotifPair> {
    public String getName();
}
