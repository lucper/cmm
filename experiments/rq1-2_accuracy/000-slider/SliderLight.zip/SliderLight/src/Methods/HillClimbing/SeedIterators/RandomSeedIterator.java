package Methods.HillClimbing.SeedIterators;

import Data.InteractionData.IInteractionData;
import Util.Pairs.MotifPair;
import java.util.Random;

/**
 *
 * @author Peter Boyen
 */
public class RandomSeedIterator implements ISeedIterator
{
    public static final String RANDOMSEED = "RandomSeed";

    private Random $r;
    private IInteractionData $interactionData;

    public RandomSeedIterator(IInteractionData interactionData)
    {
        $r = new Random();
        $interactionData = interactionData;
    }

    public RandomSeedIterator(IInteractionData interactionData, long seed)
    {
        $r = new Random(seed);
        $interactionData = interactionData;
    }

    public String getName()
    {
        return RANDOMSEED;
    }

    public MotifPair next()
    {
        return $interactionData.getRandomMotifPairFromData($r);
    }

    public boolean hasNext()
    {
        return true;
    }

    public void remove()
    {
        throw new UnsupportedOperationException("Not supported.");
    }
}
