package Util.RunInformation;

import java.util.HashMap;

/**
 *
 * @author Peter Boyen
 */
public class PositiveNumberCount extends HashMap<Integer, Integer> implements IStatistics
{

    private int $max;

    public PositiveNumberCount()
    {
        super();

        $max = 0;
    }

    public void numberFromSequence(int number)
    {
        if (number > $max)
        {
            $max = number;
        }

        if (containsKey(number))
        {
            put(number, get(number) + 1);
        } else
        {
            put(number, 1);
        }
    }

    public void add(IStatistics statistics)
    {
        PositiveNumberCount count = (PositiveNumberCount) statistics;

        for (int key : count.keySet())
        {
            if (containsKey(key))
            {
                put(key, get(key) + count.get(key));
            } else
            {
                put(key, count.get(key));
            }
        }
    }

    @Override
    public String toString()
    {
        String result = "";

        for (int i = 0; i <= $max; i++)
        {
            if (containsKey(i))
            {
                result += i + " : " + get(i) + "\n";
            }
        }

        return result;
    }
}
