/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Util.RunInformation;

/**
 *
 * @author Peter
 */
public class AvgVarStdDev implements IStatistics
{

    long $amount;
    double $sum;
    double $sumSquared;

    public AvgVarStdDev()
    {
        reset();
    }

    public void reset()
    {
        $amount = 0;
        $sum = 0.0;
        $sumSquared = 0.0;
    }

    public void numberFromSequence(double number)
    {
        $amount++;
        $sum += number;
        $sumSquared += (number * number);
    }

    public void add(IStatistics statistics)
    {
        AvgVarStdDev avg = (AvgVarStdDev) statistics;

        $amount += avg.$amount;
        $sum += avg.$sum;
        $sumSquared += avg.$sumSquared;
    }

    @Override
    public String toString()
    {
        String result = "";

        double mean = $sum / $amount;
        double var = $sumSquared / $amount - mean * mean;
        double dev = Math.sqrt(var * $amount / ($amount - 1));

        result += "sum " + $sum + "\n";    // Sum of all scores
        result += "sumofsquares " + $sumSquared + "\n";   // Sum of square of all scores
        result += "amount " + $amount + "\n";     // Amont of scores
        result += "avg " + mean + "\n";   // Average of scores
        result += "variance " + var + "\n";    // Variance of scores
        result += "deviation " + dev + "\n";    // Deviation of scores

        return result;
    }
}
