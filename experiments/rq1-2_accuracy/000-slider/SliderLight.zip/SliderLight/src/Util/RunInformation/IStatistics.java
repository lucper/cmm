/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Util.RunInformation;

/**
 *
 * @author Peter
 */
public interface IStatistics
{

    public void add(IStatistics statistics);

    @Override
    public String toString();
}
