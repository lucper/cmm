package Util.RunInformation;

/**
 *
 * @author Peter Boyen
 */
public class SingleNumber implements IStatistics
{

    private int $number;

    public SingleNumber(int number)
    {
        $number = number;
    }

    public void add(IStatistics statistics)
    {
        $number += ((SingleNumber) statistics).$number;
    }

    @Override
    public String toString()
    {
        return "" + $number + "\n";
    }
}
