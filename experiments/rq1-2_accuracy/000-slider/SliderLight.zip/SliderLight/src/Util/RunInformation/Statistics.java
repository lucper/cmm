package Util.RunInformation;

import java.util.HashMap;

/**
 *
 * @author Peter Boyen
 */
public class Statistics extends HashMap<String, IStatistics>
{

    public void add(Statistics statistics)
    {
        for (String key : statistics.keySet())
        {
            if (containsKey(key))
            {
                get(key).add(statistics.get(key));
            } else
            {
                put(key, statistics.get(key));
            }
        }
    }

    @Override
    public String toString()
    {
        String result = "";

        for (String key : keySet())
        {
            result += key + "\n";
            result += get(key).toString();
        }

        return result;
    }
}
