/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Util.RunInformation;

/**
 *
 * @author Peter
 */
public class Time implements IStatistics
{

    private long $maxTime;
    private long $totalTime;

    public Time()
    {
    }

    public void start()
    {
        $totalTime = System.currentTimeMillis();
    }

    public void stop()
    {
        $totalTime = System.currentTimeMillis() - $totalTime;
        $maxTime = $totalTime;
    }

    public void add(IStatistics statistics)
    {
        Time time = (Time) statistics;

        $totalTime += time.$totalTime;

        $maxTime = $maxTime > time.$maxTime ? $maxTime : time.$maxTime;
    }

    @Override
    public String toString()
    {
        String result = "";

        result += "totalTime:\n";
        result += $totalTime + "\n";

        result += "maxTime:\n";
        result += $maxTime + "\n";

        return result;
    }
}
