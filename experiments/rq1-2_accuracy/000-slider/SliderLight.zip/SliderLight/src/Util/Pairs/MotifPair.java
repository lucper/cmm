package Util.Pairs;

import Util.*;
import Data.MotifData.MotifFunctions;

/**
 *
 * @author Peter Boyen
 */
public class MotifPair extends MyPair<String, String>
{

    public MotifPair(String s)
    {
        this(s.split("-")[0], s.split("-")[1]);
    }

    public MotifPair(String fst, String snd)
    {
        super(fst, snd);
        if (fst.compareTo(snd) > 0)
        {
            $fst = snd;
            $snd = fst;
        }
    }

    @Override
    public String toString()
    {
        return MotifFunctions.makeMotifPair($fst, $snd);
    }
}
