package Util.Pairs;

/**
 *
 * @author Peter Boyen
 */
public class MotifPairScorePair extends MyPair<MotifPair, Double>
{

    public MotifPairScorePair(String s)
    {
        this(s.split(" ")[0], Double.parseDouble(s.split(" ")[1]));
    }

    public MotifPairScorePair(String fst, Double snd)
    {
        this(new MotifPair(fst), snd);
    }

    public MotifPairScorePair(MotifPair fst, Double snd)
    {
        super(fst, snd);
    }

    @Override
    public String toString()
    {
        return $fst.toString() + " " + $snd.toString();
    }
}
