package Util.Pairs;

import Util.*;

/**
 *
 * @author Peter Boyen
 */
public class Edge extends MyPair<Character, Character>
{

    public Edge(char c1, char c2)
    {
        super(c1, c2);
        if ($fst.compareTo($snd) > 0)
        {
            $fst = c2;
            $snd = c1;
        }
    }
    
    @Override
    public String toString()
            {
        return "Edge[" + (int)$fst + "," + (int)$snd + "]";
    }
}
