package Util.Pairs;

public class MyPair<A, B>
{

    public A $fst;
    public B $snd;

    public MyPair(A fst, B snd)
    {
        $fst = fst;
        $snd = snd;
    }

    @Override
    public String toString()
    {
        return "MyPair[" + $fst + "," + $snd + "]";
    }

    @Override
    public boolean equals(Object o)
    {
        MyPair p = (MyPair) o;

        return p.$fst.equals($fst) && p.$snd.equals($snd);
    }

    @Override
    public int hashCode()
    {
        int hash = 3;
        hash = 97 * hash + (this.$fst != null ? this.$fst.hashCode() : 0);
        hash = 97 * hash + (this.$snd != null ? this.$snd.hashCode() : 0);
        return hash;
    }
}
