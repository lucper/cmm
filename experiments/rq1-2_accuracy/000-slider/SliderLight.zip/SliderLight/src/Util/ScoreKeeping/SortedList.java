/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Util.ScoreKeeping;

import ScoreFunctions.ScoreComparators.IScoreComparator;
import Util.Pairs.MyPair;
import java.util.AbstractList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

/**
 *
 * @author Peter
 */
public class SortedList
{

    private AbstractList<MyPair<Object, Double>> $list;
    private int $amount;

    public SortedList(int amount)
    {
        $amount = amount;

        $list = new Vector<MyPair<Object, Double>>(amount + 1);
    }

    public void saveObjectIfBetter(Object o, double score, IScoreComparator comp)
    {
        if ($list.size() < $amount || comp.isBetterScore(score, $list.get($list.size() - 1).$snd))
        {
            MyPair<Object, Double> pair = new MyPair<Object, Double>(o, score);

            int index = Collections.binarySearch($list, pair, new ObjectScorePairComparator(comp));

            if (index < 0)
            {
                // No pair present with this score yet
                $list.add(-(index + 1), pair);
            } else
            {
                // A pair is already present with this score, so maybe the exact pair is already present
                int searchIndex = index;

                while (searchIndex < $list.size() && pair.$snd.equals($list.get(searchIndex).$snd))
                {
                    if ($list.get(searchIndex).$fst.equals(pair.$fst))
                    {
                        // already present
                        return;
                    }

                    searchIndex++;
                }

                searchIndex = index - 1;

                while (searchIndex >= 0 && pair.$snd.equals($list.get(searchIndex).$snd))
                {
                    if ($list.get(searchIndex).$fst.equals(pair.$fst))
                    {
                        // already present
                        return;
                    }

                    searchIndex--;
                }

                // Add the new one first
                // (we could add it anywhere in between, but this would maintain the same order as the earlier implementations)
                $list.add(searchIndex + 1, pair);
            }

            while ($list.size() > $amount)
            {
                $list.remove($list.size() - 1);
            }
        }
    }

    public int size()
    {
        return $list.size();
    }

    public int maxSize()
    {
        return $amount;
    }

    private class ObjectScorePairComparator implements Comparator<MyPair<Object, Double>>
    {

        private IScoreComparator $comp;

        public ObjectScorePairComparator(IScoreComparator comp)
        {
            $comp = comp;
        }

        public int compare(MyPair<Object, Double> pair1, MyPair<Object, Double> pair2)
        {
            if (pair1.$snd.equals(pair2.$snd))
            {
                return 0;
            } else if ($comp.isBetterScore(pair1.$snd, pair2.$snd))
            {
                return -1;
            } else// if ($sf.isBetterScore(p2.snd, p1.snd))
            {
                return 1;
            }
        }
    }

    public double getScore(int index)
    {
        return $list.get(index).$snd;
    }

    public Object getObject(int index)
    {
        return $list.get(index).$fst;
    }

    public MyPair<Object, Double> getPair(int index)
    {
        return $list.get(index);
    }
}
