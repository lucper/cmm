package Util.ScoreKeeping;

import Util.Pairs.MotifPairScorePair;
import ScoreFunctions.ScoreComparators.IScoreComparator;
import Util.Pairs.MotifPair;
import java.io.File;

/**
 *
 * @author Peter Boyen
 */
public interface ITopScores {
    public void saveScoreIfBetter(String m1, String m2, double score, IScoreComparator scoreFunction);
    
    public void saveScoreIfBetter(MotifPair motifPair, double score, IScoreComparator scoreFunction);
    
    public void saveScoreIfBetter(int m1, int m2, double score, IScoreComparator scoreFunction);
    
    public void saveScoreIfBetter(MotifPairScorePair pair, IScoreComparator scoreFunction);
    
    public void writeScores(File f);

    public void writeCompactScores(File f);
    
    public void add(ITopScores topScores, IScoreComparator scoreFunction);
    
    public void outputScores();
    
    public double getScore(int i);
    
    public int maxSize();
    
    public int size();
    
    public void clear();
}
