package Util.ScoreKeeping;

import Data.InteractionData.IInteractionData;
import Util.Pairs.MotifPairScorePair;
import Data.MotifData.*;
import ScoreFunctions.AbstractScoreFunction;
import ScoreFunctions.ScoreComparators.IScoreComparator;
import ScoreFunctions.TestScoreFunction;
import Util.Pairs.MotifPair;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

/**
 * This class is meant for keeping the best scores and motifs. It will at all times keep an ordered list of
 * the best motif pairs seen so far.
 * 
 * @author Peter Boyen
 */
public class TopMotifPairScores implements ITopScores
{

    /**
     * The list of best (motif pair score) pairs at every point
     */
    private AbstractList<MotifPairScorePair> $topScores;
    /**
     * The maximum amount of best scoring motif pairs to keep
     */
    private int $amount;

    /**
     * Creates a new instance of TopMotifPairScores.
     * 
     * @param amount        The maximum amount of best scoring motif pairs to keep
     */
    public TopMotifPairScores(int amount)
    {
        $amount = amount;

        emptyScores();
    }

    /**
     * Creates a new instance of TopMotifPairScores. It will be read in from a file. The file will
     * be considered to hold the maximum amount for this instance.
     * 
     * @param f                         The file from which the top scores are read they must be formatted as a regular result file)
     * @throws java.io.IOException      If the file cannot be read.
     */
    public TopMotifPairScores(File f) throws IOException
    {
        emptyScores();

        $amount = 0;
        BufferedReader br = new BufferedReader(new FileReader(f));
        String line;

        while ((line = br.readLine()) != null)
        {
            $amount++;
            $topScores.add(new MotifPairScorePair(line.split(" ")[0], Double.parseDouble(line.split(" ")[1])));
        }

        br.close();
    }

    public TopMotifPairScores(File f, boolean compact) throws IOException
    {
        emptyScores();

        $amount = 0;
        DataInputStream dis = new DataInputStream(new FileInputStream(f));

        MaskArray m = MaskArray.getInstance();

        try
        {
            while (true)
            {
                int m1 = dis.readInt();
                int m2 = dis.readInt();
                double score = dis.readDouble();

                String motifPair = MotifFunctions.makeMotifPair(m.getMotifString(m1), m.getMotifString(m2));

                $topScores.add(new MotifPairScorePair(motifPair, score));
            }
        } catch (EOFException e)
        {
        }

        dis.close();
    }

    public TopMotifPairScores(ITopScores topScores)
    {
        emptyScores();

        $amount = topScores.maxSize();

        TopMotifPairScores scores = (TopMotifPairScores) topScores;

        for (int i = 0; i < topScores.size(); i++)
        {
            $topScores.add(scores.getMotifScorePair(i));
        }
    }

    /**
     * Creates an empty list for the best motif pairs and scores to be kept in
     */
    private void emptyScores()
    {
        $topScores = new Vector<MotifPairScorePair>();
    }

    /**
     * Saves the score if it is better than the worst currently kept, or if we aren't
     * up to the maximum amount kept yet.
     * 
     * @param m1                A motif
     * @param m2                A motif
     * @param score     	The score of the pair
     * @param scoreFunction     The scorefunction to decide if a score is better than another.
     */
    public void saveScoreIfBetter(String m1, String m2, double score, IScoreComparator scoreFunction)
    {
        saveScoreIfBetter(new MotifPairScorePair(MotifFunctions.makeMotifPair(m1, m2), score), scoreFunction);
    }

    /**
     * Saves the score if it is better than the worst currently kept, or if we aren't
     * up to the maximum amount kept yet.
     * 
     * @param motifPair         The motifpair
     * @param score             The score of the motif pair
     * @param scoreFunction     The scorefunction which tells us if a score is better than another
     */
    public void saveScoreIfBetter(MotifPair motifPair, double score, IScoreComparator scoreFunction)
    {
        saveScoreIfBetter(new MotifPairScorePair(motifPair, score), scoreFunction);
    }

    /**
     * Saves the score if it is better than the worst currently kept, or if we aren't
     * up to the maximum amount kept yet.
     * 
     * @param m1                The unique number identifying a motif (for more info on this, see {@link Data.MotifData.MaskArray})
     * @param m2                The unique number identifying a motif (for more info on this, see {@link Data.MotifData.MaskArray})
     * @param score             The score of the motif pair
     * @param scoreFunction     The scorefunction to decide if a score is better than another.
     */
    public void saveScoreIfBetter(int m1, int m2, double score, IScoreComparator scoreFunction)
    {
        if ($topScores.size() < $amount || scoreFunction.isBetterScore(score, $topScores.get($topScores.size() - 1).$snd))
        {
            String motif1 = MaskArray.getInstance().getMotifString(m1);
            String motif2 = MaskArray.getInstance().getMotifString(m2);

            saveScoreIfBetter(new MotifPairScorePair(MotifFunctions.makeMotifPair(motif1, motif2), score), scoreFunction);
        }
    }

    /**
     * Saves the score if it is better than the worst currently kept, or if we aren't
     * up to the maximum amount kept yet.
     * 
     * @param pair              A pair of motif pair and score
     * @param scoreFunction     The scorefunction to decide if a score is better than another.
     */
    public void saveScoreIfBetter(MotifPairScorePair pair, IScoreComparator scoreFunction)
    {
        if ($topScores.size() < $amount || scoreFunction.isBetterScore(pair.$snd, $topScores.get($topScores.size() - 1).$snd))
        {
            int index = Collections.binarySearch($topScores, pair, new MotifPairScorePairComparator(scoreFunction));

            if (index < 0)
            {
                // No pair present with this score yet
                $topScores.add(-(index + 1), pair);
            } else
            {
                // A pair is already present with this score, so maybe the exact motif pair is already present
                int searchIndex = index;

                while (searchIndex < $topScores.size() && pair.$snd.equals($topScores.get(searchIndex).$snd))
                {
                    if ($topScores.get(searchIndex).$fst.equals(pair.$fst))
                    {
                        return;
                    }

                    searchIndex++;
                }

                searchIndex = index - 1;

                while (searchIndex >= 0 && pair.$snd.equals($topScores.get(searchIndex).$snd))
                {
                    if ($topScores.get(searchIndex).$fst.equals(pair.$fst))
                    {
                        return;
                    }

                    searchIndex--;
                }

                // Add the new one first 
                // (we could add it anywhere in between, but this would maintain the same order as the earlier implementations)
                $topScores.add(searchIndex + 1, pair);
            }

            while ($topScores.size() > $amount)
            {
                $topScores.remove($topScores.size() - 1);
            }
        }
    }

    private class MotifPairScorePairComparator implements Comparator<MotifPairScorePair>
    {

        private IScoreComparator $sf;

        public MotifPairScorePairComparator(IScoreComparator scoreFunction)
        {
            $sf = scoreFunction;
        }

        public int compare(MotifPairScorePair p1, MotifPairScorePair p2)
        {
            if (p1.$snd.equals(p2.$snd))
            {
                return 0;
            } else if ($sf.isBetterScore(p1.$snd, p2.$snd))
            {
                return -1;
            } else// if ($sf.isBetterScore(p2.snd, p1.snd))
            {
                return 1;
            }
        }
    }

    /**
     * Writes the scores and motifs to a file. If the file can't be written to
     * the results are written to the standard output so no data is lost.
     * 
     * @param f	    The file to write to
     */
    public void writeScores(File f)
    {
        try
        {
            if (f.getParentFile() != null && !f.getParentFile().exists())
            {
                f.getParentFile().mkdirs();
            }
            PrintStream ps = new PrintStream(f);

            for (int i = 0; i < $topScores.size(); i++)
            {
                ps.println($topScores.get(i).$fst + " " + $topScores.get(i).$snd);
            }

            ps.close();
        } catch (IOException e)
        {
            e.printStackTrace();

            System.out.println(f);

            for (int i = 0; i < $topScores.size(); i++)
            {
                System.out.println($topScores.get(i).$fst + " " + $topScores.get(i).$snd);
            }
        }
    }

    public void writeScoresWithSizes(File f, AbstractScoreFunction scoreFunction)
    {
        IMotifData motifData = scoreFunction.getMotifData();
        IInteractionData interactionData = scoreFunction.getInteractionData();

        try
        {
            if (f.getParentFile() != null && !f.getParentFile().exists())
            {
                f.getParentFile().mkdirs();
            }
            PrintStream ps = new PrintStream(f);

            for (int i = 0; i < $topScores.size(); i++)
            {
                char[] vX = motifData.getProteinsWithSequencesWithMotif($topScores.get(i).$fst.$fst);
                char[] vY = motifData.getProteinsWithSequencesWithMotif($topScores.get(i).$fst.$snd);

                int intersection = 0;
                double OM1M2 = 0.0;
                double max = 0.0;

                if (vX != null && vY != null)
                {
                    for (char c : vX)
                    {
                        if (Arrays.binarySearch(vY, c) >= 0)
                        {
                            intersection++;
                        }
                    }

                    OM1M2 = interactionData.getObservedInteractions(vX, vY);
                    max = interactionData.getMaximumInteractions(vX, vY);
                } else
                {
                    System.out.println($topScores.get(i).$fst + " " + $topScores.get(i).$snd);
                }
                ps.println($topScores.get(i).$fst + " " + $topScores.get(i).$snd + "\t\tvX: " + (vX == null ? 0 : vX.length) + " vY: " + (vY == null ? 0 : vY.length) + " intersection: " + intersection + " fraction: " + (max == 0 ? 0 : (OM1M2 / max)) + " = " + OM1M2 + " / " + max);
            }

            ps.close();
        } catch (IOException e)
        {
            e.printStackTrace();

            System.out.println(f);

            for (int i = 0; i <
                    $topScores.size(); i++)
            {
                System.out.println($topScores.get(i).$fst + " " + $topScores.get(i).$snd);
            }

        }
    }

    public void writeCompactScores(File f)
    {
        try
        {
            if (f.getParentFile() != null && !f.getParentFile().exists())
            {
                f.getParentFile().mkdirs();
            }

            DataOutputStream dos = new DataOutputStream(new PrintStream(f));

            MaskArray m = MaskArray.getInstance();

            for (int i = 0; i <
                    $topScores.size(); i++)
            {
                MotifPairScorePair pair = $topScores.get(i);

                int m1 = m.getMotifNumber(pair.$fst.$fst);
                int m2 = m.getMotifNumber(pair.$fst.$snd);
                Double score = pair.$snd;

                dos.writeInt(m1);
                dos.writeInt(m2);
                dos.writeDouble(score);
            }

            dos.close();
        } catch (IOException e)
        {
            e.printStackTrace();

            System.out.println(f);

            for (int i = 0; i <
                    $topScores.size(); i++)
            {
                System.out.println($topScores.get(i).$fst + " " + $topScores.get(i).$snd);
            }

        }
    }

    public void add(ITopScores topScores, IScoreComparator scoreFunction)
    {
        TopMotifPairScores scores = (TopMotifPairScores) topScores;

        for (int i = 0; i <
                topScores.size(); i++)
        {
            saveScoreIfBetter(scores.getMotifScorePair(i), scoreFunction);
        }

    }

    /**
     * Prints the currently kept motif pairs and scores to standard output.
     */
    public void outputScores()
    {
        for (int i = 0; i <
                $topScores.size(); i++)
        {
            System.out.println($topScores.get(i).$fst + " " + $topScores.get(i).$snd);
        }

        System.out.println();
    }

    /**
     * Returns the score in a certain position at that time.
     * 
     * @param i	    An index
     * @return	    The score at that index
     */
    public double getScore(int i)
    {
        return $topScores.get(i).$snd;
    }

    /**
     * Returns the motif pair in a certain position at that time.
     * 
     * @param i	    An index
     * @return	    The motif pair at that index
     */
    public MotifPair getMotifPair(
            int i)
    {
        return $topScores.get(i).$fst;
    }

    /**
     * Returns the maximum amount of best scoring motif pairs to keep
     * 
     * @return	    The maximum amount of best scores kept
     */
    public int maxSize()
    {
        return $amount;
    }

    /**
     * Returns the current amount of scores kept.
     * 
     * @return      The amount of scores being kept
     */
    public int size()
    {
        return $topScores.size();
    }

    /**
     * Returns a Pair containing the motif pair as a String and its score as a Double.
     * 
     * @param i	    An index
     * @return	    The pair of motif pair and score at that index
     */
    public MotifPairScorePair getMotifScorePair(
            int i)
    {
        return $topScores.get(i);
    }

    /**
     * Clears the list of motif pairs and scores.
     */
    public void clear()
    {
        $topScores.clear();
    }

    public static void main(String[] args) throws IOException
    {
        MaskArray.set(1, 0);

        TopMotifPairScores tmps = new TopMotifPairScores(2);

        AbstractScoreFunction sf = new TestScoreFunction();

        tmps.saveScoreIfBetter(new MotifPairScorePair("A-A", 90.0), sf);
        tmps.saveScoreIfBetter(new MotifPairScorePair("R-R", 11.0), sf);
        tmps.saveScoreIfBetter(new MotifPairScorePair("N-N", 10.0), sf);

        tmps.outputScores();

        System.out.println();

        tmps.writeCompactScores(new File("test.txt"));

        TopMotifPairScores tmps2 = new TopMotifPairScores(new File("test.txt"), true);

        tmps2.outputScores();
    }
}
