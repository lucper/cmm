package Util;

/**
 *
 * @author Peter Boyen
 */
public class ProgressTracker
{
    private int $totalSteps;
    
    private int $nextOutput;
    private int $outputIncrement;

    public ProgressTracker(int totalSteps, int amountOfOutputs)
    {
        $totalSteps = totalSteps;
        
        if (amountOfOutputs != 0)
        {
            $outputIncrement = totalSteps / amountOfOutputs;
            $nextOutput = $outputIncrement;
        } else
        {
            $outputIncrement = totalSteps + 1;
            $nextOutput = totalSteps + 1;
        }
    }

    public boolean hasOutput(int currentStep)
    {
        if (currentStep > $nextOutput)
        {
            $nextOutput += $outputIncrement;
            return true;
        }

        return false;
    }
    
    public String getOutput(int currentStep)
            {
        double percent = 100.0 * ((double) currentStep / (double)$totalSteps);
        return "Step " + currentStep + " of " + $totalSteps + "(" + percent + "%)\n";
    }
}
