package Util;

import java.lang.management.*;

/**
 *
 * @author Peter Boyen
 */
public class CPUTime
{

    public static void main(String[] args) throws Exception
    {
        long startTime = getCpuTime();

        for (int i = 0; i < 10000; i++)
        {
            for (int j = 0; j < 10000; j++)
            {
                int test = (int) Math.sqrt(i * j);
            }
        }

        System.out.println(getCpuTime() - startTime);
    }

    /** Get CPU time in nanoseconds. */
    public static long getCpuTime()
    {
        ThreadMXBean bean = ManagementFactory.getThreadMXBean();
        return bean.isCurrentThreadCpuTimeSupported() ? bean.getCurrentThreadCpuTime() : 0L;
    }

    /** Get user time in nanoseconds. */
    public static long getUserTime()
    {
        ThreadMXBean bean = ManagementFactory.getThreadMXBean();
        return bean.isCurrentThreadCpuTimeSupported() ? bean.getCurrentThreadUserTime() : 0L;
    }

    /** Get system time in nanoseconds. */
    public static long getSystemTime()
    {
        ThreadMXBean bean = ManagementFactory.getThreadMXBean();
        return bean.isCurrentThreadCpuTimeSupported() ? (bean.getCurrentThreadCpuTime() - bean.getCurrentThreadUserTime()) : 0L;
    }
}
