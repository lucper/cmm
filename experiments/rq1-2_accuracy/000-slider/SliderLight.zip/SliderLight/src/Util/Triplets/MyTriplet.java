package Util.Triplets;


public class MyTriplet<A, B, C>
{

    public A $fst;
    public B $snd;
    public C $trd;

    public MyTriplet(A fst, B snd, C trd)
    {
        $fst = fst;
        $snd = snd;
        $trd = trd;
    }

    @Override
    public String toString()
    {
        return "MyTriplet[" + $fst + "," + $snd + "," + $trd + "]";
    }

    @Override
    public boolean equals(Object o)
    {
        MyTriplet p = (MyTriplet) o;

        return p.$fst.equals($fst) && p.$snd.equals($snd) && p.$trd.equals($trd);
    }

    @Override
    public int hashCode()
    {
        int hash = 7;
        hash = 53 * hash + (this.$fst != null ? this.$fst.hashCode() : 0);
        hash = 53 * hash + (this.$snd != null ? this.$snd.hashCode() : 0);
        hash = 53 * hash + (this.$trd != null ? this.$trd.hashCode() : 0);
        return hash;
    }
}
