package Framework;

import Data.InteractionData.IInteractionData;
import Data.InteractionData.InteractionArrayFactory;
import Data.MotifData.IMotifData;
import Data.MotifData.MaskArray;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.SequenceIteratorFactory;
import Data.MotifData.PreprocessedMotifData;
import Methods.BruteForce.BruteForce;
import ScoreFunctions.AbstractScoreFunction;
import ScoreFunctions.ScoreFunctionFactory;
import Methods.HillClimbing.*;
import Methods.AbstractMethod;
import Methods.HillClimbing.Climbers.ClimbBestFitSingleChange;
import Methods.HillClimbing.Climbers.StayOnClimbBestFitSingleChange;
import Methods.HillClimbing.SeedIterators.RandomSeedIterator;
import Methods.ThreadedMethod;
import Util.ScoreKeeping.ITopScores;
import java.io.File;
import java.io.PrintStream;

/**
 *
 * @author Peter Boyen
 */
public class Framework
{

    public static void main(String[] args) throws Exception
    {
        Arguments arguments = new Arguments(args);

        if (!arguments.containsKey("l") || !arguments.containsKey("d") || !arguments.containsKey("seq") || !arguments.containsKey("int") || !arguments.containsKey("o") || !arguments.containsKey("m")) {
            System.err.println("Arguments l, d, seq, int, o and m are required");
            System.err.println("Example usage: java Framework -l 8 -d 3 -seq seq.fasta -int prot.int -o output -m HCThreaded");
            System.err.println();
            System.err.println("Required options:");
            System.err.println("-l      The length of the desired motifs");
            System.err.println("-d      The amount of wildcards in the desired motifs");
            System.err.println("-seq    The fasta file containing the sequence information");
            System.err.println("-int    The file containing the interaction information");
            System.err.println("-o      The output file");
            System.err.println("-m      The desired method (HCTimed, BruteForceThreaded,slider++)");
            System.err.println();
            System.err.println("Other options:");
            System.err.println("-t      The amount of threads to use (standard uses as many as there are processors available");
            System.err.println("-a      The amount of best scores to keep (standard 1,000)");
            System.err.println("-f      The neighbor function to use for HCTimed");
            System.err.println("-st     allows for different scoretypes (" + ScoreFunctionFactory.$BINOMIAL + ", " + ScoreFunctionFactory.$COVER + ", " + ScoreFunctionFactory.$DIFFERENCE + ", " + ScoreFunctionFactory.$P + ", " + ScoreFunctionFactory.$V + ", " + ScoreFunctionFactory.$WEIGHTEDV + ", " + ScoreFunctionFactory.$X2 + ")");
            System.err.println("-min    the amount of minutes to run (used only for timed methods)");

            System.exit(1);
        }

        long startTime = System.currentTimeMillis();

        MaskArray.$subsequenceLength = Integer.parseInt(arguments.get("l"));
        MaskArray.$wildCards = Integer.parseInt(arguments.get("d"));
        File seqFile = new File(arguments.get("seq"));
        File intFile = new File(arguments.get("int"));
        String outputPrefix = arguments.get("o");

        System.out.println(outputPrefix);

        String method = arguments.get("m");

        int threads;
        if (arguments.containsKey("t")) {
            threads = Integer.parseInt(arguments.get("t"));
        } else {
            threads = Runtime.getRuntime().availableProcessors();
        }

        int amountToKeep = 1000;
        if (arguments.containsKey("a")) {
            amountToKeep = Integer.parseInt(arguments.get("a"));
        }

        String iteratorType = SequenceIteratorFactory.$LCANDSA;
        if (arguments.containsKey("f")) {
            iteratorType = arguments.get("f");
        }

        String scoreFunctionString = ScoreFunctionFactory.$X2;

        if (arguments.containsKey("st")) {
            scoreFunctionString = arguments.get("st");
        }

        double minutes = 5.0;
        if (arguments.containsKey("min")) {
            minutes = Double.parseDouble(arguments.get("min"));
        }

        if (method.equalsIgnoreCase("HCTimed")) {
            IInteractionData interactionData = new InteractionArrayFactory().read(seqFile, intFile);
            IMotifData md = new PreprocessedMotifData(interactionData);

            AbstractScoreFunction scoreFunction = ScoreFunctionFactory.getScoreFunction(scoreFunctionString, interactionData, md, threads);


            AbstractMethod hc = new HillClimbingTimed(scoreFunction, minutes, amountToKeep, new ClimbBestFitSingleChange(scoreFunction, iteratorType, false), new RandomSeedIterator(interactionData));

            ITopScores topScores = new ThreadedMethod(hc, threads, scoreFunction).getTopScores();
            
            topScores.writeScores(new File(outputPrefix + ".txt"));
        } else if (method.equalsIgnoreCase("BruteForceThreaded")) {
            if (!new File(outputPrefix + ".txt").exists()) {
                IInteractionData interactionData = new InteractionArrayFactory().read(seqFile, intFile);

                IMotifData md = new PreprocessedMotifData(interactionData);

                AbstractScoreFunction scoreFunction = ScoreFunctionFactory.getScoreFunction(scoreFunctionString, interactionData, md, threads);

                BruteForce bf = new BruteForce(scoreFunction, amountToKeep);
                
                ITopScores topScores = new ThreadedMethod(bf, threads, scoreFunction).getTopScores();

                topScores.writeScores(new File(outputPrefix + ".txt"));
            }
        } else if (method.equalsIgnoreCase("slider++")) {
            //System.out.println("running slider++ for " + minutes + " divided over " + threads + " should take about " + (minutes / threads) + "minutes in real-time");

            IInteractionData interactionData = new InteractionArrayFactory().read(seqFile, intFile);

            IMotifData md = new PreprocessedMotifData(interactionData);

            AbstractScoreFunction scoreFunction = ScoreFunctionFactory.getScoreFunction(scoreFunctionString, interactionData, md, threads);

            AbstractMethod hc = new StayOnHillClimbingTimed(scoreFunction, minutes, amountToKeep, new StayOnClimbBestFitSingleChange(scoreFunction, "", true));

            ITopScores topScores = new ThreadedMethod(hc, threads, scoreFunction).getTopScores();
            
            topScores.writeScores(new File(outputPrefix + ".txt"));
        } else {
            throw new UnsupportedOperationException("unsupported method: " + method);
        }

        PrintStream ps = new PrintStream("time.txt");

        ps.println((System.currentTimeMillis() - startTime));

        ps.close();
    }
}
