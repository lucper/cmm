package Framework;

import java.util.HashMap;

/**
 * This class turns the command line arguments into a HashMap of properties.
 * 
 * @author Peter Boyen
 */
public class Arguments extends HashMap<String, String>
{

    /**
     * Creates a new instance of arguments.
     * Arguments must be well-formed.
     * 
     * @param args      The command line arguments
     */
    public Arguments(String[] args)
    {
        super();

        //for (String arg : args)
        //{
        //    System.out.print(arg + " ");
        //}

        try
        {
            for (int i = 0; i + 1 < args.length; i++)
            {
                if (args[i].charAt(0) == '-' && args[i + 1].charAt(0) != '-')
                {
                    put(args[i].substring(1).trim(), args[i + 1].trim());
                }
            }
        } catch (Exception e)
        {
            System.err.println("error reading arguments:");
            for (String arg : args)
            {
                System.err.println(arg);
            }
            System.exit(1);
        }
    }
}
