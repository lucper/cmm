package Data.InteractionData;

/**
 * This interface is the combination of {@link IInteractionData} and
 * {@link IConstructableNetworkData}. It allows the {@link AbstractInteractionDataFactory}
 * to construct and interaction network using the one interface and return it to the user as the
 * other.
 * 
 * @author Peter Boyen
 */
public interface IConstructableInteractionData extends IInteractionData, IConstructableNetworkData
{
}
