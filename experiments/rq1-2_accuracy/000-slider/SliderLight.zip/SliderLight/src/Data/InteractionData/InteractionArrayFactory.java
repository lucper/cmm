package Data.InteractionData;

/**
 * This class constructs {@link InteractionArray}s from data in a folder.
 * <p/>
 * The folder must contain a seq.fasta and a prot.int file.
 * <p/>
 * The fasta file must contain the sequence data as such (fasta format):<br/>
 * >proteinName1<BR/>
 * sequenceData<BR/>
 * sequenceData<BR/>
 * >proteinName2<BR/>
 * sequenceData<BR/>
 * sequenceData<BR/>
 * ...
 * <p/>
 * The int file must contain the interactions as follows:<br/>
 * proteinName1 proteinName2<BR/>
 * proteinName1 proteinName3<BR/>
 * ...
 * 
 * @author Peter Boyen
 */
public class InteractionArrayFactory extends AbstractInteractionDataFactory
{

    /**
     * Returns an instance of {@link IConstructableInteractionData}
     * 
     * @return      An instance of {@link IConstructableInteractionData}
     */
    @Override
    protected IConstructableInteractionData getNewInteractionData(boolean selfloops)
    {
        return new InteractionArray(selfloops);
    }

    
}
