package Data.InteractionData;

import java.io.File;

/**
 * Classes implementing this interface are responsible for reading data about
 * interaction networks and returning a class containing that data.
 * 
 * @author Peter Boyen
 */
public interface IInteractionDataFactory {
    /**
     * Reads the data from a given folder and returns an instance of {@link IInteractionData}.
     * 
     * @param folder        The folder containing the data
     * @return              An instance of {@link IInteractionData}
     */
    public IInteractionData read(String folder, boolean selfloops);
    
    /**
     * Reads the sequence data from the fasta file and the interaction data from
     * the interaction file and returns an instance of {@link IInteractionData}.
     * 
     * @param fastaFile             File containing the sequence data
     * @param interactionFile       File containing the interaction data
     * @return                      An instance of {@link IInteractionData}
     */
    public IInteractionData read(File fastaFile, File interactionFile, boolean selfloops);
}
