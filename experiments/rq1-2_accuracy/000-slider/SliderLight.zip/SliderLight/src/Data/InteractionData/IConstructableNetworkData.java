package Data.InteractionData;

/**
 * This interface allows for adding data about a protein-protein interaction network.
 * 
 * @author Peter Boyen
 */
public interface IConstructableNetworkData {
    
    /**
     * Add an interaction between two existing proteins.
     * 
     * @param name1         The unique name (or id) of a protein
     * @param name2         The unique name (or id) of a protein
     */
    public void addInteraction(String name1, String name2);

    /**
     * Add a protein to the network (with it amino acid sequence).
     * 
     * @param proteinName       The unique name (or id) of the protein
     * @param sequence          The protein's sequence of amino acids
     */
    public void addProtein(String proteinName, String sequence);
}
