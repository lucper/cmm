package Data.InteractionData.Triplets;

import Data.MotifData.MotifFunctions;
import Util.Triplets.MyTriplet;
import java.util.HashMap;
import java.util.Random;
import java.util.Arrays;

/**
 * This class contains the necessary info about a network:
 * <ul>
 * <li>The interactions (kept in an array)</li>
 * <li>The sequences of proteins</li>
 * <ul/>
 * Construction of an InteractionArrayTriplets for a network is done
 * by an {@link InteractionArrayTripletsFactory}.
 * 
 * @author Peter Boyen
 */
public class InteractionArrayTriplets implements IInteractionDataTriplets
{

    /**
     * When given a name, retrieve the protein's index in the array
     */
    private HashMap<String, Character> $proteinNameToNumberMap;
    /**
     * When given a number, retrieve the protein's name
     */
    private HashMap<Character, String> $numberToProteinNameMap;
    /**
     * An interaction array. True indicates an interaction between two proteins.
     */
    private boolean[][][] $interactionArray;
    /**
     * This array contains how many interactions there are for every node.
     */
    private int[] $amountOfInteractionsArray;
    /**
     * The total amount of interactions in this network.
     */
    private int $amountOfInteractions;
    /**
     * Given a protein number, retrieve its sequence.
     */
    private HashMap<Character, String> $numberToSequenceMap;

    /**
     * Creates a new instance of InteractionArrayTriplets
     */
    public InteractionArrayTriplets()
    {
        $proteinNameToNumberMap = new HashMap<String, Character>();
        $numberToProteinNameMap = new HashMap<Character, String>();
        $amountOfInteractions = 0;
        $numberToSequenceMap = new HashMap<Character, String>();

        $interactionArray = null;
        $amountOfInteractionsArray = null;
    }

    /**
     * Add a protein to the network
     *
     * @param proteinName       the name for the protein
     * @param sequence          the amino acid sequence of the protein
     */
    public void addProtein(String proteinName, String sequence)
    {
        if (!$proteinNameToNumberMap.containsKey(proteinName)) {
            int number = $proteinNameToNumberMap.size();

            if (number > Character.MAX_VALUE) {
                throw new UnsupportedOperationException("maximum protein limit exceeded");
            }

            $proteinNameToNumberMap.put(proteinName, (char) number);
            $numberToProteinNameMap.put((char) number, proteinName);
        }

        $numberToSequenceMap.put($proteinNameToNumberMap.get(proteinName), sequence);
    }

    /**
     * Add an interaction to the network. (Order of proteins doesn't matter)
     *
     * @param protein1      The first protein
     * @param protein2      The second protein
     * @param protein3      The third protein
     */
    public void addInteraction(String protein1, String protein2, String protein3)
    {
        Character num1 = $proteinNameToNumberMap.get(protein1);
        Character num2 = $proteinNameToNumberMap.get(protein2);
        Character num3 = $proteinNameToNumberMap.get(protein3);

        if (num1 == null || num2 == null || num3 == null) {
            return;
        }

        addInteraction(num1, num2, num3);
    }

    /**
     * Add an interaction to the network. (Order of proteins doesn't matter)
     *
     * @param num1      The id of the first protein
     * @param num2      The id of the second protein
     * @param num3      The id of the third protein
     */
    public void addInteraction(char num1, char num2, char num3)
    {
        if ($interactionArray == null) {
            createArray();
        }

        if (num1 == num2 || num1 == num3 || num2 == num3) {
            return;
        }

        if ($interactionArray[num1][num2][num3] == false) {
            $amountOfInteractions++;
        }

        $interactionArray[num1][num2][num3] = true;
        $interactionArray[num1][num3][num2] = true;
        $interactionArray[num2][num1][num3] = true;
        $interactionArray[num2][num3][num1] = true;
        $interactionArray[num3][num1][num2] = true;
        $interactionArray[num3][num2][num1] = true;
    }

    /**
     * check if there is an interaction between two proteins
     *
     * @param i     The id of the first protein
     * @param j     The id of the second protein
     * @param k     The id of the third protein
     * @return      whether these three proteins interact
     */
    public boolean hasInteraction(char i, char j, char k)
    {
        return $interactionArray[i][j][k];
    }

    /**
     * Returns the amino acid sequence for a given protein.
     * 
     * @param i     The number of the protein
     * @return      The sequence of amino acids of this protein
     */
    public String getSequence(char i)
    {
        return $numberToSequenceMap.get(i);
    }

    /**
     * Returns the name for a given protein id.
     * 
     * @param i     The number of the protein
     * @return      The name of this protein
     */
    public String getProteinName(char i)
    {
        return $numberToProteinNameMap.get(i);
    }

    /**
     * Returns the id for a given protein name.
     * 
     * @param name  The name of the protein
     * @return      The number of this protein
     */
    public char getProteinId(String name)
    {
        return $proteinNameToNumberMap.get(name);
    }

    /**
     * Returns the total amount of proteins in the network.
     * 
     * @return      The amount of proteins (nodes) in this network
     */
    public int getNumberOfProteins()
    {
        return $interactionArray.length;
    }

    /**
     * Returns the total amount of interactions in the network.
     * 
     * @return      The amount of interactions in this network
     */
    public int getNumberOfInteractions()
    {
        return $amountOfInteractions;
    }

    /**
     * This function gives you the amount of interactions with a given node.
     * 
     * @param node              A node
     * @return                  The amount of interactions with that node
     */
    public int getNumberOfInteractionsWith(char node)
    {
        if ($amountOfInteractionsArray[node] == -1) {
            int interactions = 0;

            for (int i = 0; i < $interactionArray[node].length; i++) {
                for (int j = i + 1; j < $interactionArray[node][i].length; j++) {
                    if ($interactionArray[node][i][j]) {
                        interactions++;
                    }
                }
            }

            $amountOfInteractionsArray[node] = interactions;
        }

        return $amountOfInteractionsArray[node];
    }

    /**
     * Gives a random (l,d) motif that occurs in the data.
     * 
     * @param l     The length of the motif
     * @param d     The amount of wildcards in the motif
     * @return      A random (l,d) motif that occurs in the data
     */
    public String getRandomMotifFromData()
    {
        Random r = new Random();

        // Random sequence
        int index = r.nextInt($numberToSequenceMap.size());

        String sequence = $numberToSequenceMap.get(index);

        return MotifFunctions.getRandomMotifFromSequence(sequence);
    }

    /**
     * Returns the amount of interactions where each interactor is present in a different
     * one of the lists.
     *
     * @param SM1           A SORTED list of proteins
     * @param SM2           A SORTED list of proteins
     * @param SM3           A SORTED list of proteins
     * @return              The amount of interactions where each interactor is present in a
     * separate list
     */
    public int getObservedInteractions(char[] SM1, char[] SM2, char[] SM3)
    {
        int OM1M2 = 0;
        for (char sequence1 : SM1) {
            for (char sequence2 : SM2) {
                for (char sequence3 : SM3) {
                    if (hasInteraction(sequence1, sequence2, sequence3)) {
                        OM1M2++;

                        // Don't count doubles if both nodes are shared
                        if (sequence2 < sequence1 && Arrays.binarySearch(SM1, sequence2) >= 0 && Arrays.binarySearch(SM2, sequence1) >= 0) {
                            OM1M2--;
                        } // Don't count doubles if both nodes are shared
                        else if (sequence3 < sequence1 && Arrays.binarySearch(SM1, sequence3) >= 0 && Arrays.binarySearch(SM3, sequence1) >= 0) {
                            OM1M2--;
                        } // Don't count doubles if both nodes are shared
                        else if (sequence3 < sequence2 && Arrays.binarySearch(SM2, sequence3) >= 0 && Arrays.binarySearch(SM3, sequence2) >= 0) {
                            OM1M2--;
                        }
                    }
                }
            }


        }

        return OM1M2;
    }

    /**
     * Returns the maximum amount of interactions possible where each interactor is present in a different
     * one of the lists.
     *
     * @param SM1           A SORTED list of proteins
     * @param SM2           A SORTED list of proteins
     * @param SM3           A SORTED list of proteins
     * @return              The maximum amount of interactions possible  where each interactor is present in a
     * separate list
     */
    public int getMaximumInteractions(char[] SM1, char[] SM2, char[] SM3)
    {
        int OM1M2 = 0;
        for (char sequence1 : SM1) {
            for (char sequence2 : SM2) {
                for (char sequence3 : SM3) {
                    OM1M2++;

                    // Don't count doubles if both nodes are shared
                    if (sequence2 < sequence1 && Arrays.binarySearch(SM1, sequence2) >= 0 && Arrays.binarySearch(SM2, sequence1) >= 0) {
                        OM1M2--;
                    } // Don't count doubles if both nodes are shared
                    else if (sequence3 < sequence1 && Arrays.binarySearch(SM1, sequence3) >= 0 && Arrays.binarySearch(SM3, sequence1) >= 0) {
                        OM1M2--;
                    } // Don't count doubles if both nodes are shared
                    else if (sequence3 < sequence2 && Arrays.binarySearch(SM2, sequence3) >= 0 && Arrays.binarySearch(SM3, sequence2) >= 0) {
                        OM1M2--;
                    }

                }
            }
        }

        return OM1M2;
    }

    /**
     *
     * @return          The maximum amount of interactions possible in the entire network
     */
    public int getMaximumInteractions()
    {
        int Scomb2 = getNumberOfProteins();
        // combination (S 3), the amount of ways you can pick three sequences
        return (Scomb2 * (Scomb2 - 1) * (Scomb2 - 2)) / 6;
    }

    /**
     * Returns a random motif pair that implies at least one interaction in the data.
     * 
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MyTriplet<String, String, String> getRandomMotifTripletFromData()
    {
        Random r = new Random();

        return getRandomMotifTripletFromData(r);
    }

    /**
     * Returns a random motif pair that implies at least one interaction in the data.
     * 
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MyTriplet<String, String, String> getRandomMotifTripletFromData(Random r)
    {
        MyTriplet<Character, Character, Character> e = getRandomInteractionFromData(r);

        // First protein
        String sequence = $numberToSequenceMap.get(e.$fst);
        String m1 = MotifFunctions.getRandomMotifFromSequence(sequence);

        // Second protein
        sequence = $numberToSequenceMap.get(e.$snd);
        String m2 = MotifFunctions.getRandomMotifFromSequence(sequence);

        // Second protein
        sequence = $numberToSequenceMap.get(e.$trd);
        String m3 = MotifFunctions.getRandomMotifFromSequence(sequence);

        return new MyTriplet<String, String, String>(m1, m2, m3);
    }

    /**
     * Returns a random interaction from the data
     *
     * @return      a random interaction from the data
     */
    public MyTriplet<Character, Character, Character> getRandomInteractionFromData()
    {
        Random r = new Random();

        return getRandomInteractionFromData(r);
    }

    /**
     * Returns a random interaction from the data
     *
     * @param r     A Random object to do the random selection
     * @return      a random interaction from the data
     */
    public MyTriplet<Character, Character, Character> getRandomInteractionFromData(Random r)
    {

        // Get a random interaction
        int interaction = r.nextInt($amountOfInteractions);

        int intNumber = 0;

        // Find the sequences of the proteins with the interaction
        for (char i = 0; i < $interactionArray.length; i++) {
            for (char j = 0; j <= i; j++) {
                for (char k = 0; k <= j; k++) {
                    if (hasInteraction(i, j, k)) {
                        if (interaction == intNumber) {
                            return new MyTriplet<Character, Character, Character>(i, j, k);
                        }

                        intNumber++;
                    }
                }
            }
        }

        return null;
    }

    /**
     * When done adding proteins, create the array that holds the interaction info.
     */
    public void createArray()
    {
        $interactionArray = new boolean[$proteinNameToNumberMap.size()][$proteinNameToNumberMap.size()][$proteinNameToNumberMap.size()];
        $amountOfInteractionsArray = new int[$interactionArray.length];
        Arrays.fill($amountOfInteractionsArray, -1);
    }
}
