package Data.InteractionData.Triplets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * A factory for the construction of {@link InteractionArrayTriplets}
 * from the data in a folder
 * 
 * @author Peter Boyen
 */
public class InteractionArrayTripletsFactory
{
    /**
     *
     * @param folder        the folder containing the data
     * @return              a new InteractionArrayTriplets
     */
    final public InteractionArrayTriplets read(String folder)
    {
        if(folder.charAt(folder.length() - 1) != '/')
            folder+="/";

        return read(new File(folder + "seq.fasta"), new File(folder + "prot.int"));
    }

    /**
     *
     * @param fastaFile         the file containing sequence info
     * @param interacitonFile   the file containing interaction data
     * @return                  a new InteractionArrayTriplets
     */
    final public InteractionArrayTriplets read(File fastaFile, File interactionFile)
    {
        try
        {
            InteractionArrayTriplets id = new InteractionArrayTriplets();

            String line;

            // Read in proteins with sequences
            String sequence;

            String proteinName;

            BufferedReader br = new BufferedReader(new FileReader(fastaFile));

            line = br.readLine();
            while (line != null)
            {
                proteinName = line.substring(1); // Get rid of the '>' character

                // construct the sequence which may be spaced over several lines
                sequence = "";
                line = br.readLine();
                while (line != null && line.charAt(0) != '>')
                {
                    sequence += line;

                    line = br.readLine();
                }
                id.addProtein(proteinName, sequence);
            }

            String[] proteinNames;

            // Read in interactions
            br = new BufferedReader(new FileReader(interactionFile));

            while ((line = br.readLine()) != null)
            {
                proteinNames = line.split(" ");

                if (!proteinNames[0].equals(proteinNames[1]) && !proteinNames[0].equals(proteinNames[2]) && !proteinNames[1].equals(proteinNames[2]))
                {
                    id.addInteraction(proteinNames[0], proteinNames[1], proteinNames[2]);
                }
            }

            return id;
        } catch (IOException ex)
        {
            ex.printStackTrace();
            return null;
        }

    }
}
