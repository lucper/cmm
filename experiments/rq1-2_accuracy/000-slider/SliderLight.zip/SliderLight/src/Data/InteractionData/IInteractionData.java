package Data.InteractionData;

import Util.Pairs.Edge;
import Util.Pairs.MotifPair;
import java.util.Random;

/**
 * Interface for keeping information about a protein-protein interaction network.
 * The information kept is the sequence and interaction data.
 * 
 * @author Peter Boyen
 */
public interface IInteractionData
{
    /**
     * returns whether two proteins have an interaction
     * 
     * @param i     the id of protein 1
     * @param j     the id of protein 2
     * @return      whether these two proteins have an interaction
     */
    public boolean hasInteraction(char i, char j);
    
    /**
     * This function gives you the total amount of interactions in the network.
     * 
     * @return      The total amount of interactions in this network
     */
    public int getNumberOfInteractions();
    
    /**
     * This function gives you the amount of interactions with a given node.
     * 
     * @param node              A node
     * @return                  The amount of interactions with that node
     */
    public int getNumberOfInteractionsWith(char node);
    
    /**
     * This function gives you the amount of nodes that have interactions with
     * one or more of the nodes in the array.
     * 
     * @param nodes         A SORTED char[] of nodes
     * @return              The amount of nodes that have interactions with one
     * or more of the nodes in the array
     */
    public int getNumberOfInteractorsOf(char[] nodes);
    
    /**
     * Returns the amino acid sequence of a certain node
     * 
     * @param i     The id of the protein
     * @return      The sequence of this protein
     */
    public String getSequence(char i);
    
    /**
     * Returns the name for a given protein id.
     * 
     * @param i     The number of the protein
     * @return      The name of this protein
     */
    public String getProteinName(char i);
    
    /**
     * Returns the id for a given protein name.
     * 
     * @param name  The name of the protein
     * @return      The id of this protein
     */
    public char getProteinId(String name);
    
    /**
     * Returns the total amount of proteins in the network.
     * 
     * @return      The amount of proteins in this network
     */ 
    public int getNumberOfProteins();
    
    /**
     * Gives a random (l,d) motif that occurs in the data.
     * 
     * @param l     The length of the motif
     * @param d     The amount of wildcards in the motif
     * @return      A random (l,d) motif that occurs in the data
     */
    public String getRandomMotifFromData();
    
    /**
     * Returns a random motif pair that implies at least one interaction in the data.
     * 
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MotifPair getRandomMotifPairFromData();

    /**
     * Returns a random motif pair that implies at least one interaction in the data.
     *
     * @param r     A Random object to do the random selection with
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MotifPair getRandomMotifPairFromData(Random r);

    /**
     *
     * @return      A random interaction from the data
     */
    public Edge getRandomInteractionFromData();

    /**
     *
     * @param r     A Random object to do the random selection with
     * @return      A random interaction from the data
     */
    public Edge getRandomInteractionFromData(Random r);
    
    /**
     * Get the amount of interactions between two lists of nodes.
     * 
     * @param SM1       A SORTED char[] of protein numbers
     * @param SM2       A SORTED char[] of protein numbers
     * @return          The amount of interactions between nodes of the first and second list
     */
    public int getObservedInteractions(char[] SM1, char[] SM2);

    /**
     * Get the maximum amount of possible interactions between two lists of nodes.
     *
     * @param SM1       A SORTED char[] of protein numbers
     * @param SM2       A SORTED char[] of protein numbers
     * @return          The amount of interactions between nodes of the first and second list
     */
    public int getMaximumInteractions(char[] SM1, char[] SM2);

    /**
     *
     * @return      The maximum amount of possible interactions in the entire network
     */
    public int getMaximumInteractions();

    /**
     *
     * @param SM1       A SORTED char[] of protein numbers
     * @return          The amount of interactions where one of the interactors is in the list
     */
    public int getObservedInteractions(char[] SM1);
}
