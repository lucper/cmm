package Data.InteractionData.Triplets;

import Util.Triplets.MyTriplet;
import java.util.Random;

/**
 * Interface for keeping information about a protein-protein interaction network
 * with interaction triplets.
 * The information kept is the sequence and interaction data.
 * 
 * @author Peter Boyen
 */
public interface IInteractionDataTriplets
{
    /**
     * returns whether three proteins have an interaction
     * 
     * @param i     the id of protein 1
     * @param j     the id of protein 2
     * @param k     the id of protein 3
     * @return      whether these three proteins have an interaction
     */
    public boolean hasInteraction(char i, char j, char k);
    
    /**
     * This function gives you the total amount of interactions in the network.
     * 
     * @return      The total amount of interactions in this network
     */
    public int getNumberOfInteractions();
    
    /**
     * This function gives you the amount of interactions with a given node.
     * 
     * @param node              A node
     * @return                  The amount of interactions with that node
     */
    public int getNumberOfInteractionsWith(char node);
    
    /**
     * Returns the amino acid sequence of a certain node
     * 
     * @param i     The id of the protein
     * @return      The sequence of this protein
     */
    public String getSequence(char i);
    
    /**
     * Returns the name for a given protein id.
     * 
     * @param i     The number of the protein
     * @return      The name of this protein
     */
    public String getProteinName(char i);
    
    /**
     * Returns the id for a given protein name.
     * 
     * @param name  The name of the protein
     * @return      The id of this protein
     */
    public char getProteinId(String name);
    
    /**
     * Returns the total amount of proteins in the network.
     * 
     * @return      The amount of proteins in this network
     */ 
    public int getNumberOfProteins();
    
    /**
     * Gives a random (l,d) motif that occurs in the data.
     * 
     * @param l     The length of the motif
     * @param d     The amount of wildcards in the motif
     * @return      A random (l,d) motif that occurs in the data
     */
    public String getRandomMotifFromData();
    
    /**
     * Returns a random motif triplet that implies at least one interaction in the data.
     * 
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MyTriplet<String, String, String> getRandomMotifTripletFromData();

    /**
     * Returns a random motif triplet that implies at least one interaction in the data.
     *
     * @param r     A Random object to do the random selection
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MyTriplet<String, String, String> getRandomMotifTripletFromData(Random r);

    /**
     * Returns a random interaction from the data
     *
     * @return      a random interaction from the data
     */
    public MyTriplet<Character, Character, Character> getRandomInteractionFromData();

    /**
     * Returns a random interaction from the data
     *
     * @param r     A Random object to do the random selection
     * @return      a random interaction from the data
     */
    public MyTriplet<Character, Character, Character> getRandomInteractionFromData(Random r);

    /**
     * Returns the amount of interactions where each interactor is present in a different
     * one of the lists.
     *
     * @param SM1           A SORTED list of proteins
     * @param SM2           A SORTED list of proteins
     * @param SM3           A SORTED list of proteins
     * @return              The amount of interactions where each interactor is present in a
     * separate list
     */
    public int getObservedInteractions(char[] SM1, char[] SM2, char[] SM3);

    /**
     * Returns the maximum amount of interactions possible where each interactor is present in a different
     * one of the lists.
     *
     * @param SM1           A SORTED list of proteins
     * @param SM2           A SORTED list of proteins
     * @param SM3           A SORTED list of proteins
     * @return              The maximum amount of interactions possible  where each interactor is present in a
     * separate list
     */
    public int getMaximumInteractions(char[] SM1, char[] SM2, char[] SM3);

    /**
     *
     * @return          The maximum amount of interactions possible in the entire network
     */
    public int getMaximumInteractions();
}
