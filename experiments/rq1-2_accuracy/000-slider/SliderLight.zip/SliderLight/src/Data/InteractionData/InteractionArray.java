package Data.InteractionData;

import Data.MotifData.MotifFunctions;
import Util.Pairs.Edge;
import Util.Pairs.MotifPair;
import java.util.HashMap;
import java.util.Random;
import java.util.Arrays;
import java.util.Vector;

/**
 * This class contains the necessary info about a network:
 * <ul>
 * <li>The interactions (kept in an array)</li>
 * <li>The sequences of proteins</li>
 * <ul/>
 * Construction of an InteractionArray for a network is done
 * by an {@link InteractionArrayFactory}.
 * 
 * @author Peter Boyen
 */
public class InteractionArray implements IConstructableInteractionData
{

    /**
     * When given a name, retrieve the protein's index in the array
     */
    private HashMap<String, Character> $proteinNameToNumberMap;
    /**
     * When given a number, retrieve the protein's name
     */
    private HashMap<Character, String> $numberToProteinNameMap;
    /**
     * An interaction array. True indicates an interaction between two proteins.
     */
    private boolean[][] $interactionArray;
    /**
     * This array contains how many interactions there are for every node.
     */
    private int[] $amountOfInteractionsArray;
    /**
     * The total amount of interactions in this network.
     */
    private int $amountOfInteractions;
    /**
     * Given a protein number, retrieve its sequence.
     */
    private HashMap<Character, String> $numberToSequenceMap;
    /**
     * rarely used now. Indicates if interactions of the x-x variety are allowed.
     */
    private boolean $selfloops;

    /**
     * Creates an empty InteractionArray. Construction of an InteractionArray for a network is done
     * by an {@link InteractionArrayFactory}.
     */
    protected InteractionArray(boolean selfloops)
    {
        $proteinNameToNumberMap = new HashMap<String, Character>();
        $numberToProteinNameMap = new HashMap<Character, String>();
        $amountOfInteractions = 0;
        $numberToSequenceMap = new HashMap<Character, String>();

        $interactionArray = null;
        $amountOfInteractionsArray = null;

        $selfloops = selfloops;
    }

    /**
     * Record a protein name and sequence. If the same protein name is used twice, only the last
     * sequence will be stored.
     * 
     * @param proteinName   the name of the protein
     * @param sequence      the sequence of amino acids in the protein
     */
    public void addProtein(String proteinName, String sequence)
    {
        if (!$proteinNameToNumberMap.containsKey(proteinName)) {
            int number = $proteinNameToNumberMap.size();

            if (number > Character.MAX_VALUE) {
                throw new UnsupportedOperationException("maximum protein limit exceeded");
            }

            $proteinNameToNumberMap.put(proteinName, (char) number);
            $numberToProteinNameMap.put((char) number, proteinName);
        }

        $numberToSequenceMap.put($proteinNameToNumberMap.get(proteinName), sequence);
    }

    /**
     * Add an interaction between two proteins. This assumes all proteins are added first, followed by interactions.
     * When this is called the array will be initialized to the size of the proteins known at that time.
     * <p/>
     * If either protein name is unknown, the function will return without error.
     * <p/>
     * If the interaction was already present nothing happens.
     * 
     * @param protein1      The name of the first protein
     * @param protein2      The name of the second protein
     */
    public void addInteraction(String protein1, String protein2)
    {
        Character num1 = $proteinNameToNumberMap.get(protein1);
        Character num2 = $proteinNameToNumberMap.get(protein2);

        if (num1 == null || num2 == null) {
            return;
        }

        addInteraction(num1, num2);
    }

    /**
     * Add an interaction between two proteins. This assumes all proteins are added first, followed by interactions.
     * When this is called the array will be initialized to the size of the proteins known at that time.
     * <p/>
     * if either number is too large or too small to be a protein number, the function will throw an
     * ArrayIndexOutOfBoundsException.
     * <p/>
     * If the interaction was already present, nothing happens.
     * 
     * @param num1      The number of the first protein
     * @param num2      The number of the second protein
     */
    public void addInteraction(char num1, char num2)
    {
        if ($interactionArray == null) {
            createArray();
        }

        if (!$selfloops && num1 == num2) {
            return;
        }

        if ($interactionArray[num1][num2] == false) {
            $amountOfInteractions++;
        }
        $interactionArray[num1][num2] = true;
        $interactionArray[num2][num1] = true;
    }

    /**
     * Remove an interaction between two proteins.
     * <p/>
     * if either number is too large or too small to be a protein number, the function will throw an
     * ArrayIndexOutOfBoundsException.
     * <p/>
     * If the interaction wasn't present in the graph, nothing happens.
     * 
     * @param num1      The number of the first protein
     * @param num2      The number of the second protein
     */
    public void removeInteraction(char num1, char num2)
    {
        if ($interactionArray[num1][num2] == true) {
            $amountOfInteractions--;
        }
        $interactionArray[num1][num2] = false;
        $interactionArray[num2][num1] = false;
    }

    /**
     * Returns whether two given proteins have an interaction in this network.
     * 
     * @param i     The number of the first protein
     * @param j     The number of the second protein
     * @return      Whether there is an interaction between these proteins
     */
    public boolean hasInteraction(char i, char j)
    {
        return $interactionArray[i][j];
    }

    /**
     * Returns the amino acid sequence for a given protein.
     * 
     * @param i     The number of the protein
     * @return      The sequence of amino acids of this protein
     */
    public String getSequence(char i)
    {
        return $numberToSequenceMap.get(i);
    }

    /**
     * Returns the name for a given protein id.
     * 
     * @param i     The number of the protein
     * @return      The name of this protein
     */
    public String getProteinName(char i)
    {
        return $numberToProteinNameMap.get(i);
    }

    /**
     * Returns the id for a given protein name.
     * 
     * @param name  The name of the protein
     * @return      The number of this protein
     */
    public char getProteinId(String name)
    {
        return $proteinNameToNumberMap.get(name);
    }

    /**
     * Returns the total amount of proteins in the network.
     * 
     * @return      The amount of proteins (nodes) in this network
     */
    public int getNumberOfProteins()
    {
        return $interactionArray.length;
    }

    /**
     * Returns the total amount of interactions in the network.
     * 
     * @return      The amount of interactions in this network
     */
    public int getNumberOfInteractions()
    {
        return $amountOfInteractions;
    }

    /**
     * This function gives you the amount of interactions with a given node.
     * 
     * @param node              A node
     * @return                  The amount of interactions with that node
     */
    public int getNumberOfInteractionsWith(char node)
    {
        if ($amountOfInteractionsArray[node] == -1) {
            int interactions = 0;

            for (int i = 0; i < $interactionArray[node].length; i++) {
                if ($interactionArray[node][i]) {
                    interactions++;
                }
            }

            $amountOfInteractionsArray[node] = interactions;
        }

        return $amountOfInteractionsArray[node];
    }

    /**
     * This function gives you the amount of nodes that have interactions with
     * one or more of the nodes in the array.
     * 
     * @param nodes         A char[] of nodes
     * @return              The amount of nodes that have interactions with one
     * or more of the nodes in the array
     */
    public int getNumberOfInteractorsOf(char[] nodes)
    {
        boolean[] interactors = new boolean[$interactionArray.length];
        System.arraycopy($interactionArray[nodes[0]], 0, interactors, 0, $interactionArray.length);

        int amountOfInteractors = getNumberOfInteractionsWith(nodes[0]);

        for (int i = 1; i < nodes.length; i++) {
            for (int j = 0; j < $interactionArray.length; j++) {
                if ($interactionArray[nodes[i]][j] && !interactors[j]) {
                    interactors[j] = true;
                    amountOfInteractors++;
                }
            }
        }
        return amountOfInteractors;
    }

    /**
     * Gives a random (l,d) motif that occurs in the data.
     * 
     * @param l     The length of the motif
     * @param d     The amount of wildcards in the motif
     * @return      A random (l,d) motif that occurs in the data
     */
    public String getRandomMotifFromData()
    {
        Random r = new Random();

        // Random sequence
        int index = r.nextInt($numberToSequenceMap.size());

        String sequence = $numberToSequenceMap.get(index);

        return MotifFunctions.getRandomMotifFromSequence(sequence);
    }

    /**
     * A different version of the getObservedInteractions function
     * 
     * @param SM1       A SORTED char[] of protein numbers
     * @param SM2       Another SORTED char[] of protein numbers
     * @return          The amount of interactions between the nodes in these lists
     */
    public int getObservedInteractions2(char[] SM1, char[] SM2)
    {
        int OM1M2 = 0;
        for (int i = 0; i < SM1.length; i++) {
            char sequence1 = SM1[i];
            for (int j = 0; j < SM2.length; j++) {
                char sequence2 = SM2[j];

                if (hasInteraction(sequence1, sequence2)) {
                    OM1M2++;

                    // Don't count doubles if both nodes are shared
                    if (sequence2 < sequence1 && Arrays.binarySearch(SM1, sequence2) >= 0 && Arrays.binarySearch(SM2, sequence1) >= 0) {
                        OM1M2--;
                    }
                }

            }
        }

        return OM1M2;
    }

    /**
     * Get the amount of interactions between two lists of nodes.
     * <p>
     * If an interaction occurs twice (both nodes appear in both lists), then it is
     * only counted once.
     * 
     * @param SM1       A SORTED char[] of protein numbers
     * @param SM2       A SORTED char[] of protein numbers
     * @return          The amount of interactions between nodes of the first and second list
     */
    public int getObservedInteractions(char[] SM1, char[] SM2)
    {
        int OM1M2 = 0;
        for (int i = 0; i < SM1.length; i++) {
            char sequence1 = SM1[i];
            for (int j = 0; j < SM2.length; j++) {
                char sequence2 = SM2[j];

                if (hasInteraction(sequence1, sequence2)) {
                    OM1M2++;
                }

            }
        }

        int index1 = 0;
        int index2 = 0;

        Vector<Character> intersection = new Vector<Character>();

        while (index1 < SM1.length && index2 < SM2.length) {
            if (SM1[index1] == SM2[index2]) {
                intersection.add(SM1[index1]);
                index1++;
                index2++;
            } else if (SM1[index1] < SM2[index2]) {
                index1++;
            } else // if (SM1[index1] > SM2[index2])
            {
                index2++;
            }
        }

        for (int i = 0; i < intersection.size(); i++) {
            for (int j = 0; j < i; j++) {
                if (hasInteraction(intersection.get(i), intersection.get(j))) {
                    OM1M2--;
                }

            }
        }

        return OM1M2;
    }

    /**
     *
     * @param SM1       A SORTED char[] of protein numbers
     * @return          The amount of interactions where one of the interactors is in the list
     */
    public int getObservedInteractions(char[] SM1)
    {
        int OM1M2 = 0;
        for (int i = 0; i < SM1.length; i++) {
            char sequence1 = SM1[i];
            for (char sequence2 = 0; sequence2 < $interactionArray.length; sequence2++) {
                if (hasInteraction(sequence1, sequence2)) {
                    OM1M2++;
                }

            }
        }

        // SM1 is the intersection here
        for (int i = 0; i < SM1.length; i++) {
            for (int j = 0; j < i; j++) {
                if (hasInteraction(SM1[i], SM1[j])) {
                    OM1M2--;
                }

            }
        }

        return OM1M2;
    }

    /**
     * Get the maximum amount of possible interactions between two lists of nodes.
     *
     * @param SM1       A SORTED char[] of protein numbers
     * @param SM2       A SORTED char[] of protein numbers
     * @return          The amount of interactions between nodes of the first and second list
     */
    public int getMaximumInteractions(char[] SM1, char[] SM2)
    {
        int shared = 0;
        for (int i = 0; i < SM1.length; i++) {
            if (Arrays.binarySearch(SM2, SM1[i]) >= 0) {
                shared++;
            }
        }

        int s1 = SM1.length - shared;
        int s2 = SM2.length - shared;

        //int max = (s1 * s2) + ((s1 + s2 + 1) * shared) + ((shared * (shared - 1)) / 2);
        int max = (s1 * s2) + ((s1 + s2) * shared) + ((shared * (shared - 1)) / 2);

        if ($selfloops) {
            max += shared;
        }

        return max;
    }

    /**
     *
     * @return      The maximum amount of possible interactions in the entire network
     */
    public int getMaximumInteractions()
    {
        int Scomb2 = getNumberOfProteins();
        // combination (S 2), the amount of ways you can pick two sequences (including doubles)
        int max = Scomb2 = (Scomb2 * (Scomb2 - 1)) / 2;

        if ($selfloops) {
            max += getNumberOfProteins();
        }

        return max;
    }

    /**
     * Returns a random motif pair that implies at least one interaction in the data.
     * 
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MotifPair getRandomMotifPairFromData()
    {
        Random r = new Random();

        return getRandomMotifPairFromData(r);
    }

    /**
     * Returns a random motif pair that implies at least one interaction in the data.
     *
     * @param r     A Random object to do the random selection with
     * @return      A random motif pair chosen by taken random motifs from interacting sequences
     */
    public MotifPair getRandomMotifPairFromData(Random r)
    {
        Edge e = getRandomInteractionFromData(r);

        // First protein
        String sequence = $numberToSequenceMap.get(e.$fst);
        String m1 = MotifFunctions.getRandomMotifFromSequence(sequence);

        // Second protein
        sequence = $numberToSequenceMap.get(e.$snd);
        String m2 = MotifFunctions.getRandomMotifFromSequence(sequence);

        return new MotifPair(m1, m2);
    }

    /**
     * @return      A random interaction from the data
     */
    public Edge getRandomInteractionFromData()
    {
        Random r = new Random();

        return getRandomInteractionFromData(r);
    }

    /**
     *
     * @param r     A Random object to do the random selection with
     * @return      A random interaction from the data
     */
    public Edge getRandomInteractionFromData(Random r)
    {
        // Get a random interaction
        int interaction = r.nextInt($amountOfInteractions);

        int intNumber = 0;
        char sequence1 = 0;
        char sequence2 = 0;
        boolean done = false;

        // Find the sequences of the proteins with the interaction
        for (char i = 0; i < $interactionArray.length && !done; i++) {
            for (char j = 0; j <= i && !done; j++) {
                if (hasInteraction(i, j)) {
                    if (interaction == intNumber) {
                        sequence1 = i;
                        sequence2 = j;

                        done = true;
                    }

                    intNumber++;
                }
            }
        }

        return new Edge(sequence1, sequence2);
    }

    /**
     * After adding all the proteins, create the array containing the interaction info.
     */
    public void createArray()
    {
        $interactionArray = new boolean[$proteinNameToNumberMap.size()][$proteinNameToNumberMap.size()];
        $amountOfInteractionsArray = new int[$interactionArray.length];
        Arrays.fill($amountOfInteractionsArray, -1);
    }
}
