package Data.InteractionData;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * A factory for IInteractionData must be able to construct an IInteractionData
 * from the data in a folder
 * 
 * @author Peter Boyen
 */
public abstract class AbstractInteractionDataFactory implements IInteractionDataFactory
{
    /**
     * see the read(String folder, boolean selfloops) function
     *
     * @param folder
     * @return
     */
    final public IInteractionData read(String folder)
    {
        return read(folder, false);
    }
    
    /**
     * This function will read sequence data and interactiondata from two files in the
     * designated folder. The sequence data should be in fasta format and in a file
     * called "seq.fasta". The interactiondata should be a file containing lines as such:
     * <br>
     * id1 id2
     * <br>
     * where id1 and id2 are names from the fasta file.
     * <br>
     * This file should be called "prot.int".
     * <p>
     * If an IOException occurs this method will return null.
     * 
     * @param folder        A String representing the folder containing the data files (the string must have an endind /)
     * @return              An instance of {@link IInteractionData} containing the interaction data from those files
     */
    final public IInteractionData read(String folder, boolean selfloops)
    {
        if(folder.charAt(folder.length() - 1) != '/')
            folder+="/";

        return read(new File(folder + "seq.fasta"), new File(folder + "prot.int"), selfloops);
    }

    /**
     * see the read(File fastaFile, File interactionFile, boolean selfloops) function
     *
     * @param fastaFile
     * @param interactionFile
     * @return
     */
    final public IInteractionData read(File fastaFile, File interactionFile)
    {
        return read(fastaFile, interactionFile, false);
    }

    /**
     * This function will read sequence data and interactiondata from the two designated files.
     * The sequence data should be in fasta format. The interactiondata should be a file containing lines as such:
     * <br>
     * id1 id2
     * <br>
     * where id1 and id2 are names from the fasta file.
     * <p>
     * If an IOException occurs this method will return null.
     * 
     * @param fastaFile         The file containing the protein names and sequence data
     * @param interactionFile   The file containing the interactions with probabilities
     * @return                  An instance of {@link IInteractionData} containing the interaction data from those files
     */
    final public IInteractionData read(File fastaFile, File interactionFile, boolean selfloops)
    {
        try
        {
            IConstructableInteractionData id = getNewInteractionData(selfloops);

            String line;

            // Read in proteins with sequences
            String sequence;

            String proteinName;

            BufferedReader br = new BufferedReader(new FileReader(fastaFile));

            line = br.readLine();
            while (line != null)
            {
                proteinName = line.substring(1); // Get rid of the '>' character

                // construct the sequence which may be spaced over several lines
                sequence = "";
                line = br.readLine();
                while (line != null && line.charAt(0) != '>')
                {
                    sequence += line;

                    line = br.readLine();
                }
                id.addProtein(proteinName, sequence);
            }

            String[] proteinNames;

            // Read in interactions
            br = new BufferedReader(new FileReader(interactionFile));

            while ((line = br.readLine()) != null)
            {
                proteinNames = line.split(" ");

                if (selfloops || !proteinNames[0].equals(proteinNames[1]))
                {
                    id.addInteraction(proteinNames[0], proteinNames[1]);
                }
            }

            return id;
        } catch (IOException ex)
        {
            ex.printStackTrace();
            return null;
        }

    }

    /**
     * Subclasses must implement this function to indicate the class they want to store
     * the sequence and interaction data in.
     * 
     * @return      An instance of {@link IConstructableInteractionData}
     */
    protected abstract IConstructableInteractionData getNewInteractionData(boolean selfloops);
}
