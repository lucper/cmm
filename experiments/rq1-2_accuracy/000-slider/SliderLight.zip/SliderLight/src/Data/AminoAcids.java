package Data;

import java.util.HashMap;

/**
 * This class contains the general information about amino acids. In this case, their letter
 * representations.
 * <p/>
 * 
 * Fixed Disjunction:<br/>
 * The String[] $aminoAcidGroups contains groupings of the different AminoAcids. This grouping
 * comes from the Wrabl paper (line 9 in table 1) and should be biologically meaningful.<br/>
 * This can be used by setting the $disjunctive boolean to true. If so, you use just these
 * groupings instead of the separate letters, where every group in a motif means that one of
 * the aminoacids in the group occurs at that specific location.
 * 
 * @author Peter Boyen
 */
public class AminoAcids
{

    /**
     * Indicates whether the fixed disjunction from the Wrabl paper is used. Standard set to false.
     */
    private static boolean $disjunctive = false;

    /**
     * Set whether or not to use the fixed disjunction from the Wrabl paper.
     * 
     * @param disjunctive           whether or not to use the fixed disjunction from the Wrabl paper.
     */
    public static void setDisjunctive(boolean disjunctive)
    {
        $disjunctive = disjunctive;
    }

    /**
     * Get the current setting for disjunction.
     * 
     * @return                      whether or not to use the fixed disjunction from the Wrabl paper.
     */
    public static boolean getDisjunctive()
    {
        return $disjunctive;
    }
    /**
     * Contains a letter representing each amino acid
     */
    private static final char[] $aminoAcids =
            {
        'A', 'R', 'N', 'D', 'C', 'E', 'Q', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', 'U'
    };
    /**
     * Maps the characters of amino acids to their index in the $aminoAcids array.
     */
    private static final HashMap<Character, Integer> $aminoLetterToIndexMap = new HashMap<Character, Integer>();
    /**
     * #aminoacids + 'x', next power of 2 is 32 = 2^5
     * This is the amount of bits necessary to represent these
     */
    private static final int $bitRepresentationSize = 5;
    /**
     * Contains Strings containing letters representing each amino acid
     * The String groups the amino acids according to the
     * James O. Wrabl paper in Proteins (line 9 in table 1)
     */
    private static final String[] $aminoAcidGroups =
            {
        "WFY", "MLIV", "C", "G", "P", "ATS", "NDE", "H", "QRK", "U"
    };
    /**
     * Maps the letters of amino acids to the index of the String containing them in the $aminoAcidGroups array
     */
    private static final HashMap<Character, Integer> $aminoLetterToGroupIndexMap = new HashMap<Character, Integer>();
    /**
     * #aminoacidgroups + 'x', next power of 2 is 16 = 2^4
     * This is the amount of bits necessary to represent these
     */
    private static final int $groupBitRepresentationSize = 4;

    /**
     * This fills in the HashMaps so using a letter the appropriate indices can be found
     * without iterating over the arrays (and possbily String characters)
     */
    static
    {
        for (int i = 0; i < $aminoAcids.length; i++)
        {
            $aminoLetterToIndexMap.put($aminoAcids[i], i);
        }

        for (int i = 0; i < $aminoAcidGroups.length; i++)
        {
            for (int j = 0; j < $aminoAcidGroups[i].length(); j++)
            {
                $aminoLetterToGroupIndexMap.put($aminoAcidGroups[i].charAt(j), i);
            }
        }
    }

    /**
     * The result of this function is dependent on the state of the boolean $disjunctive.
     * 
     * @param index	The index in the array of amino acids (or groups)
     * @return		The letter corresponding to that index
     */
    public static char getLetterForIndex(int index)
    {
        if (!$disjunctive)
        {
            return $aminoAcids[index];
        } else
        {
            return $aminoAcidGroups[index].charAt(0);
        }
    }

    /**
     * The result of this function is dependent on the state of the boolean $disjunctive.
     * 
     * @param letter	The letter representing an amino acid
     * @return		The index in the array of the amino acid (or its group)
     */
    public static int getIndexForLetter(char letter)
    {
        if (!$disjunctive)
        {
            if (!$aminoLetterToIndexMap.containsKey(letter))
            {
                System.out.println(letter);
            }

            return $aminoLetterToIndexMap.get(letter);
        } else
        {
            return $aminoLetterToGroupIndexMap.get(letter);
        }
    }

    /**
     * The result of this function is dependent on the state of the boolean $disjunctive.
     * 
     * @return	    The amount of bits necessary to have a number large enough to hold the largest possible index
     */
    public static int getBitRepresentationSize()
    {
        if (!$disjunctive)
        {
            return $bitRepresentationSize;
        } else
        {
            return $groupBitRepresentationSize;
        }
    }

    /**
     * The result of this function is dependent on the state of the boolean $disjunctive.
     * 
     * @return	    The amount of amino acids (or groups) in the array
     */
    public static int getSize()
    {
        if (!$disjunctive)
        {
            return $aminoAcids.length;
        } else
        {
            return $aminoAcidGroups.length;
        }
    }
}
