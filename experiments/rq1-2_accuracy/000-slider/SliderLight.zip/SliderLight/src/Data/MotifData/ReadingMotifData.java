/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Data.MotifData;

import Data.InteractionData.IInteractionData;
import java.util.LinkedList;

/**
 *
 * @author Peter
 */
public class ReadingMotifData implements IMotifData
{

    private IInteractionData $interactionData;

    public ReadingMotifData(IInteractionData interactionData)
    {
        $interactionData = interactionData;
    }

    /**
     * Unsupported
     *
     * @param m
     * @return
     */
    public int getAmountOfSequencesWithMotif(int m)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * This function returns the amount of sequences in the original data that contain
     * a certain motif.
     *
     * @param m         A String of a motif (l and d must be the same as used for constructing this instance)
     * @return          The amount of sequences in the data containing this motif
     */
    public int getAmountOfSequencesWithMotif(String motif)
    {
        int amount = 0;
        motif = "[A-Z]*" + motif.replace('x', ' ').trim().replace(' ', '.') + "[A-Z]*";

        for (char i = 0; i < $interactionData.getNumberOfProteins(); i++)
        {
            String sequence = $interactionData.getSequence(i);
            if (sequence.matches(motif))
            {
                amount++;
            }
        }

        return amount;
    }

    /**
     * Unsupported
     *
     * @param m
     * @return
     */
    public char[] getProteinsWithSequencesWithMotif(int m)
    {
        throw new UnsupportedOperationException();
    }

    /**
     * This function returns the sequences in the original data that contains
     * a certain motif.
     *
     * @param m         The String of a motif
     * @return          The list of protein numbers that have sequences with this motif (these will be sorted)
     */
    public char[] getProteinsWithSequencesWithMotif(String motif)
    {
        if (motif.split("&").length > 1)
        {
            return MotifFunctions.getIntersection(motif.split("&")[0], motif.split("&")[1], this);
        }

        LinkedList<Character> l = new LinkedList<Character>();
        motif = "[A-Z]*" + motif.replace('x', ' ').trim().replace(' ', '.') + "[A-Z]*";

        for (char i = 0; i < $interactionData.getNumberOfProteins(); i++)
        {
            String sequence = $interactionData.getSequence(i);
            if (sequence.matches(motif))
            {
                l.add(i);
            }
        }

        char[] result = new char[l.size()];

        int i = 0;
        while (l.size() != 0)
        {
            result[i] = l.removeFirst();
            i++;
        }

        return result;
    }

    /**
     * These results are better cached as they take a long time to gather
     *
     * @return      true
     */
    public boolean wantsCaching()
    {
        return true;
    }

    /**
     * Unsupported.
     *
     * The point of this class is to allow variable l and d, so there is no set amount of motifs
     *
     * @return  nothing, throws Exception
     */
    public int getAmountOfMotifs()
    {
        throw new UnsupportedOperationException();
    }
}
