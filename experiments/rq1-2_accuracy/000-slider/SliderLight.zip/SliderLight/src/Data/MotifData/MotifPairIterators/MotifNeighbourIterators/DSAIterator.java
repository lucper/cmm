package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * This iterator is meant as a helper for the {@link ARDandSAIterator}.
 * It should switch groups of letters with an 'x' they are next to.
 * 
 * @author Peter Boyen
 */
public class DSAIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * The groups of letters
     */
    private LinkedList<Character>[] $letterGroups;
    /**
     * The locations of the groups that can move left
     */
    private LinkedList<Integer> $moveLeft;
    /**
     * The locations of the groups that can move right
     */
    private LinkedList<Integer> $moveRight;

    /**
     * Creates a new instance of DisjunctivePlusTwoStepIterator.
     * 
     * @param ldMotif       The original motif
     * @param l             The length of the motif
     * @param d             The amount of wildcards in the motif
     */
    protected DSAIterator(String ldMotif)
    {
        $ldMotif = ldMotif;

        $current = 0;

        $letterGroups = new LinkedList[$ldMotif.length()];
        for (int i = 0; i < $letterGroups.length; i++)
        {
            $letterGroups[i] = new LinkedList<Character>();
        }

        $moveLeft = new LinkedList<Integer>();
        $moveRight = new LinkedList<Integer>();

        int group = 0;

        // Read the groups, either as a group like (ARN), or an x or a letter
        for (int i = 0; i < ldMotif.length(); i++)
        {
            if (ldMotif.charAt(i) == '(')
            {
                i++;

                while (ldMotif.charAt(i) != ')')
                {
                    $letterGroups[group].add(ldMotif.charAt(i));
                    i++;
                }
            } else if (ldMotif.charAt(i) != 'x')
            {
                $letterGroups[group].add(ldMotif.charAt(i));
            }

            group++;
        }

        for (int i = 1; i < $letterGroups.length - 1; i++)
        {
            if ($letterGroups[i].size() != 0)
            {
                if ($letterGroups[i - 1].size() == 0)
                {
                    $moveLeft.add(i);
                }
                if ($letterGroups[i + 1].size() == 0)
                {
                    $moveRight.add(i);
                }
            }
        }

        if ($letterGroups[$letterGroups.length - 1].size() != 0 && $letterGroups[$letterGroups.length - 2].size() == 0)
        {
            $moveLeft.add($letterGroups.length - 1);
        }

        $max = $moveLeft.size() + $moveRight.size();
    }

    /**
     * 
     * @return  Whether there is still a neighbour to be returned
     */
    public boolean hasNext()
    {
        return $current < $max;
    }

    /**
     * 
     * @return      The next neighbour String of the original String
     */
    public String next()
    {
        String result = getNeighbour($current);

        $current++;
        return result;
    }
    
    /**
     * The amount of neighbours this iterator can generate, also one more than
     * the maximum the getNeighbour() function should be called with.
     * 
     * @return	    The amount of neighbours
     */
    public int getMax()
    {
	return $max;
    }

    /**
     * {@link ISequenceNeighbourFunction}s have an internal order on neighbours.
     * This function returns the neighbour at index i in that order.
     * 
     * @param index		The index
     * @return                  The neighbour at that index in the order
     */
    public String getNeighbour(int index)
    {
	String result = "";

        if (index < $moveLeft.size())
        {
            int move = $moveLeft.get(index);

            for (int i = 0; i < $letterGroups.length; i++)
            {
                if (i != move - 1)
                {
                    result += makeString($letterGroups[i]);
                } else
                {
                    i++;
                    result += makeString($letterGroups[i]) + "x";
                }
            }
        } else
        {
            int workingCurrent = index - $moveLeft.size();

            int move = $moveRight.get(workingCurrent);

            for (int i = 0; i < $letterGroups.length; i++)
            {
                if (i != move)
                {
                    result += makeString($letterGroups[i]);
                } else
                {

                    result += "x" + makeString($letterGroups[i]);
                    i++;
                }
            }
        }

        return result;
    }

    /**
     * UnsupportedOperationException("Not supported.");
     */
    public void remove()
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    /**
     * Given a list of characters returns the String used for representing the disjunction
     * of those characters. E.g. thee list[A, R, N] will return "(ARN)".
     * <br/>
     * If the list is null or empty "x" is returned.
     * <br/>
     * If the list contains only one element, that element is returned.
     * 
     * @param l         The lettergroup
     * @return          The String representing that letter group
     */
    private String makeString(LinkedList<Character> l)
    {
        if (l == null || l.size() == 0)
        {
            return "x";
        }
        if (l.size() == 1)
        {
            return "" + l.get(0);
        }

        String result = "(";

        for (int i = 0; i < l.size(); i++)
        {
            result += l.get(i);
        }

        return result + ")";
    }

    public static void main(String[] args)
    {
        //AminoAcids.setDisjunctive(true);

        ISequenceNeighbourIterator neighbourIterator = new DSAIterator("AxxQxxx(AN)");

        int i = 1;

        HashMap<String, Integer> map = new HashMap<String, Integer>();

        while (neighbourIterator.hasNext())
        {
            String neighbour = neighbourIterator.next();

            System.out.println(i + " " + neighbour);
            if (!map.containsKey(neighbour))
            {
                map.put(neighbour, 1);
            } else
            {
                map.put(neighbour, map.get(neighbour) + 1);
            }

            i++;
        }

        if (!map.containsKey("AxxQxx(AN)x"))
        {
            System.out.println("AxxQxx(AN)x missing");
        }

        if (!map.containsKey("AxQxxxx(AN)"))
        {
            System.out.println("AxQxxxx(AN) missing");
        }

        if (!map.containsKey("AxxxQxx(AN)"))
        {
            System.out.println("AxxxQxx(AN) missing");
        }

        // Shouldn't return itself
        if (map.containsKey("AxxQxxx(AN)"))
        {
            System.out.println("AxxQxxx(AN) shouldn't be present");
        }

        // This iterator shouldn't change two letters
        if (map.containsKey("QxxAxxxQ"))
        {
            System.out.println("QxxAxxxQ shouldn't be present");
        }

        Iterator<String> mapKeyIterator = map.keySet().iterator();
        while (mapKeyIterator.hasNext())
        {
            String neighbour = mapKeyIterator.next();
            if (map.get(neighbour) != 1)
            {
                System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
            }
        }
    }
}
