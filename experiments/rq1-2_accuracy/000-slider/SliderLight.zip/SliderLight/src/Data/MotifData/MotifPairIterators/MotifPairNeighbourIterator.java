package Data.MotifData.MotifPairIterators;

import Data.MotifData.MaskArray;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.ISequenceNeighbourIterator;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.SequenceIteratorFactory;
import Util.Pairs.MotifPair;

/**
 * This class iterates over the neighbours of a motif pair. Every pair is returned once.
 * The motifs themselves are also returned.
 * 
 * @author Peter Boyen
 */
public class MotifPairNeighbourIterator
{

    /**
     * An iterator over the first motif
     */
    private ISequenceNeighbourIterator $it1;
    /**
     * An iterator over the second motif
     */
    private ISequenceNeighbourIterator $it2;
    /**
     * The first motif
     */
    private String $motif1;
    /**
     * The second motif
     */
    private String $motif2;
    /**
     * The kind of iteration desired
     */
    private String $iteratorType;
    /**
     * The String that is the current neighbour of the first motif.
     */
    private String $currentFirst;
    /**
     * Whether a new iterator over the second motif has just been made (this indicates that
     * the second motif itself must be returned once).
     */
    private boolean $firstNew;

    /**
     * Creates a new instance of MotifPairIterator.
     * 
     * @param motif1		The first motif
     * @param motif2		The second motif
     * @param iteratorType	The kind of iteration desired (one of the static String members of {@link SequenceIteratorFactory}.
     * @param l			The length of the moifs
     * @param d			The amount of wildcards in the motif
     */
    public MotifPairNeighbourIterator(String motif1, String motif2, String iteratorType)
    {
        $motif1 = motif1;
        $motif2 = motif2;

        $iteratorType = iteratorType;

        $it1 = SequenceIteratorFactory.getSequenceIterator(iteratorType, motif1);
        $it2 = SequenceIteratorFactory.getSequenceIterator(iteratorType, motif2);
        $currentFirst = $motif1;
        $firstNew = true;
    }

    /**
     * 
     * @return	    Whether there is still a neighbour to return.
     */
    public boolean hasNext()
    {
        return $it1.hasNext() || $it2.hasNext();
    }

    /**
     * This returns all possible neighbours of the given motif pair.
     * Each pair is returned only once, given the order. The same motif pair
     * might be returned (if you allow both orders) if the two motifs share a neighbour.
     * 
     * @return	    The next neighbour of the motif pair
     */
    public MotifPair next()
    {
        MotifPair result;

        if ($firstNew)
        {
            result = new MotifPair($currentFirst, $motif2);
            $firstNew = false;
        } else
        {
            result = new MotifPair($currentFirst, $it2.next());
        }

        if (!$it2.hasNext() && $it1.hasNext())
        {
            $currentFirst = $it1.next();
            $it2 = SequenceIteratorFactory.getSequenceIterator($iteratorType, $motif2);
            $firstNew = true;
        }

        return result;
    }

    /**
     * throw new UnsupportedOperationException();
     * 
     * @return          nothing, this throws an Exception
     */
    public int getMax()
    {
        throw new UnsupportedOperationException();
    }

    /**
     * throw new UnsupportedOperationException();
     * 
     * @return          nothing, this throws an Exception
     */
    public MotifPair getNeighbour(int index)
    {
        throw new UnsupportedOperationException();
    }

    public static void main(String[] args)
    {
        MaskArray.$subsequenceLength = 8;
        MaskArray.$wildCards = 5;
        
        MotifPairNeighbourIterator mpIt = new MotifPairNeighbourIterator("AxxRxNxx", "NQxxxxxR", SequenceIteratorFactory.$LCANDSA);

        int i = 1;

        while (mpIt.hasNext())
        {
            MotifPair pair = mpIt.next();

            System.out.println(i + " " + pair.$fst + "-" + pair.$snd);
            i++;
        }
    }
}
