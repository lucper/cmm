package Data.MotifData;

import Data.AminoAcids;
import java.util.HashMap;
import java.util.Random;

/**
 * This class holds the masks for creating motifs: a mask takes the form of a binary number
 * where a 1 represents a letter from a substring is kept, and a 0 indicates that an x is
 * placed at that location. E.g. The mask 10011011 applied to the String ABCDEFGH results
 * in the motif AxxDExGH.
 * <p/>
 * This class also assigns unique numbers to motifs. This number uniquely identifies the
 * mask (by its index in the array) and the letters on the non-x spaces (by their index
 * in the array in the {@link Data.AminoAcids} class.
 * <br/>
 * Let's call the number of non-x letters (length-wildcards) n.<br/>
 * And the number of letters or groups g.<br/>
 * The unique number then is: maskindex * g^n + leftmostletter * g^n-1 + ... + rightmostletter * g^0
 * <p/>
 * Only masks with a 1 in front are allowed because Axx and xAx are the same motif (excepting some
 * corner cases).
 * 
 * @author Peter Boyen
 */
public class MaskArray
{

    public static void main(String[] args)
    {
        int combinations = 1;

        for (int count = 8 - 1; count > 3; count--)
        {
            combinations *= count;
        }

        for (int count = 2; count <= 8 - 1 - 3; count++)
        {
            combinations /= count;
        }


        long amountOfMotifs = (long) (combinations * Math.pow(20, 8 - 3));

        System.out.println(amountOfMotifs);

        long amountOfMotifPairs = ((amountOfMotifs * amountOfMotifs) + amountOfMotifs) / 2L;

        System.out.println(amountOfMotifPairs);
    }
    /**
     * The instance of MaskArray for the Singleton pattern
     */
    private static MaskArray $instance = null;

    /**
     * @return			    The maskarray for a given length and wildcards
     */
    public static MaskArray getInstance()
    {
        if ($instance == null)
        {
            if ($subsequenceLength < 1 || $wildCards < 0 || $subsequenceLength <= $wildCards)
            {
                throw new UnsupportedOperationException("Please set length and wildcard values correctly.");
            }

            $instance = new MaskArray($subsequenceLength, $wildCards);
        }

        return $instance;
    }

    /**
     * Function added to change l and d during the run of the program
     *
     * @return      A new instance of MaskArray
     */
    public static MaskArray makeNewInstance()
    {
        $instance = new MaskArray($subsequenceLength, $wildCards);

        return $instance;
    }
    /**
     * The length of the motifs
     */
    public static int $subsequenceLength = -1;
    /**
     * The amount of wildcards in the motifs
     */
    public static int $wildCards = -1;
    /**
     * The maximum amount of motifs given $subsequenceLength and $wildCards
     */
    private int $amountOfMotifs;
    /**
     * contains masks of $subsequenceLength bits
     */
    private int[] $maskArray;
    /**
     * Binary number with as many ones as $bitRepresentationSize in AminoAcids
     */
    private long $fullOneRepresentation;
    /**
     * The current index to be filled in the $maskArray
     */
    private int $index;
    /**
     * Given a mask, what is it's index in the mask array
     */
    private HashMap<Integer, Integer> $maskToIndexMap;

    /**
     * Creates a new instance of MaskArray. Can only be called from the static getInstance method.
     * This provides the Singleton pattern.
     * 
     * @param subsequenceLength     The length of the motifs
     * @param wildCards             The amount of wildcards in the motifs
     */
    private MaskArray(int subsequenceLength, int wildCards)
    {
        $subsequenceLength = subsequenceLength;
        $wildCards = wildCards;

        $fullOneRepresentation = (long) Math.pow(2, AminoAcids.getBitRepresentationSize()) - 1;

        createMaskArray();
    }

    /**
     * should be called before calling getInstance. Sets the length and amount of wildcards of the motifs
     *
     * @param l     The length of the motifs
     * @param d     The amount of wildcards in the motifs
     */
    public static void set(int l, int d)
    {
        $subsequenceLength = l;
        $wildCards = d;
    }

    /**
     *
     * @param ldMotif       A string of length l
     * @param mask          A binary mask
     * @return              A motif: the original string with x'es on the right places
     */
    public String applyMask(String ldMotif, int mask)
    {
        StringBuffer b = new StringBuffer(ldMotif);

        for (int i = 0; i < $subsequenceLength; i++)
        {
            int maskChecker = 1 << i;

            if ((mask & maskChecker) == 0)
            {
                b.setCharAt($subsequenceLength - 1 - i, 'x');
            }
        }

        return b.toString();
    }

    /**
     *
     * @param index         an index
     * @return              the mask at that index
     */
    public int getMask(int index)
    {
        return $maskArray[index];
    }

    /**
     * This creates the arrays of the necessary sizes and fills the maskarray.
     */
    private void createMaskArray()
    {
        // Only allow mask with a 1etter at first
        int combinations = 1;

        for (int count = $subsequenceLength - 1; count > $wildCards; count--)
        {
            combinations *= count;
        }

        for (int count = 2; count <= $subsequenceLength - 1 - $wildCards; count++)
        {
            combinations /= count;
        }

        $maskArray = new int[combinations];

        $index = 0;
        
        $maskToIndexMap = new HashMap<Integer, Integer>();
        fillInCombinations($subsequenceLength - 1, $wildCards, 1);

        $amountOfMotifs = (int) (combinations * Math.pow(AminoAcids.getSize(), $subsequenceLength - $wildCards));
    }

    /**
     * The amount of possible (l, d)-motifs
     * 
     * @return      The amount of possible (l, d)-motifs
     */
    public int getAmountOfMotifs()
    {
        return $amountOfMotifs;
    }

    /**
     * The amount of possible masks (keep in mind that the first letter is never an x)
     * 
     * @return          The amount of possible masks
     */
    public int getAmountOfMasks()
    {
        return $maskArray.length;
    }

    /**
     * 
     * @return	    A randomly selected mask
     */
    public int getRandomMask()
    {
        Random r = new Random();
        return $maskArray[r.nextInt($maskArray.length)];
    }

    /**
     * Recursively constructs all possible masks and stores them in the array
     * 
     * @param l			The length of the motif
     * @param d			The wildcards in the motif
     * @param currentValue	The motif constructed so far
     */
    private void fillInCombinations(int l, int d, int currentValue)
    {
        if (l == 0)
        {
            // Store the fully constructed motif
            $maskArray[$index] = currentValue;
            $maskToIndexMap.put(currentValue, $index);
            $index++;
        } else
        {
            currentValue = currentValue << 1;

            // If not all remaining spaces have to be wildcards
            if (d < l)
            {
                // Fill in a non wildcard
                fillInCombinations(l - 1, d, currentValue + 1);
            }

            // If there are still wildcards to place
            if (d > 0)
            {
                // Fill in a wildcard
                fillInCombinations(l - 1, d - 1, currentValue);
            }
        }
    }

    /**
     * Returns the unique number identifying a motif.
     * <p/>
     * Let's call the number of non-x letters (length-wildcards) n.<br/>
     * And the number of letters or groups g.<br/>
     * The unique number then is: maskindex * g^n + leftmostletter * g^n-1 + ... + rightmostletter * g^0
     * 
     * @param sequence		The sequence (as a long), see SubsequenceAsLongIterator
     * @param maskIndex		The index of the mask
     * @return              The unique number identifying the motif
     */
    public int getMotifNumber(long sequence, int maskIndex)
    {
        int mask = $maskArray[maskIndex];

        int[] letterCodes = new int[$subsequenceLength - $wildCards];

        int codes = 0;
        int i;

        // Save the letters on positions where the mask isn't 0
        for (i = 0; i < $subsequenceLength; i++)
        {
            if ((mask & (1 << i)) > 0)
            {
                long oneLetterExtendedMask = $fullOneRepresentation << (AminoAcids.getBitRepresentationSize() * i);
                long code = (sequence & oneLetterExtendedMask) >> (AminoAcids.getBitRepresentationSize() * i);
                letterCodes[codes] = (int) code;
                codes++;
            }
        }

        int returnValue = 0;

        int multiplier = 1;

        // The return value should uniquely identify the mask (by its index in the array) and the three letters
        for (i = 0; i < letterCodes.length; i++)
        {
            returnValue += (letterCodes[i] * multiplier);
            multiplier *= AminoAcids.getSize();
        }

        returnValue += (maskIndex * multiplier);

        return returnValue;
    }

    /**
     * Constructs a (partial) sequence from the motifstring and extracts the mask.
     * With these the getMotifNumber(long sequence, int maskIndex) function is called
     * to get the unique number identifying this motif.
     * 
     * @param motif	    The String of the motif
     * @return		    The unique number identifying the motif
     */
    public int getMotifNumber(String motif)
    {
        long sequence = 0;
        int mask = 0;
        for (int i = 0; i < motif.length(); i++)
        {
            sequence = sequence << AminoAcids.getBitRepresentationSize();
            mask = mask << 1;
            if (motif.charAt(i) != 'x')
            {
                mask++;

                sequence += AminoAcids.getIndexForLetter(motif.charAt(i));

            }
        }

        if (!$maskToIndexMap.containsKey(mask))
        {
            System.out.println(motif);
            System.out.println(mask + " " + $maskToIndexMap);
        }

        return getMotifNumber(sequence, $maskToIndexMap.get(mask));
    }

    /**
     * 
     * @param motifNr		The number identifying the motif
     * @return              The String of the motif
     */
    public String getMotifString(int motifNr)
    {
        int div = (int) Math.pow(AminoAcids.getSize(), $subsequenceLength - $wildCards);

        // Get the mask
        int maskNr = motifNr / div;

        motifNr = motifNr % div;
        div /= AminoAcids.getSize();

        // Get the letters
        int[] letterCodes = new int[$subsequenceLength - $wildCards];
        for (int i = 0; i < letterCodes.length; i++)
        {
            letterCodes[i] = motifNr / div;
            motifNr = motifNr % div;
            div /= AminoAcids.getSize();
        }

        /*String result = "";
        int mask = $maskArray[maskNr];
        int max = 1 << ($subsequenceLength - 1);
        int codes = letterCodes.length - 1;
        // Construct the String
        for (int i = 1; i <= max; i = i << 1)
        {
        if ((mask & i) > 0)
        {
        result = AminoAcids.getLetterForIndex(letterCodes[codes]) + result;
        codes--;
        } else
        {
        result = "x" + result;
        }
        }
        return result;*/

        StringBuffer result = new StringBuffer();
        int mask = $maskArray[maskNr];
        int max = 1 << ($subsequenceLength - 1);
        int codes = letterCodes.length - 1;
        // Construct the String
        for (int i = 1; i <= max; i = i << 1)
        {
            if ((mask & i) > 0)
            {
                result.insert(0, AminoAcids.getLetterForIndex(letterCodes[codes]));// + result;
                codes--;
            } else
            {
                result.insert(0, 'x');// + result;
            }
        }
        return result.toString();
    }

    /**
     * Prints a sequence as number with the correct amount of leading zeros.
     * 
     * @param subsequence	    The subsequence to print
     */
    public void printSequenceNumber(long subsequence)
    {
        System.out.println(subsequence);
        for (int y = 0; y < Long.numberOfLeadingZeros(subsequence) - (Long.SIZE - ($subsequenceLength * AminoAcids.getBitRepresentationSize())); y++)
        {
            System.out.print("0");
        }
        System.out.println(Long.toBinaryString(subsequence));
    }
}
