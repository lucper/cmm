/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Data.MotifData;

/**
 *
 * @author Peter
 */
public interface IMotifData {
    /**
     *
     * @return      The total amount of motifs with the set l and d values
     */
    public int getAmountOfMotifs();

    /**
     *
     * @param m     a motif number
     * @return      the amount of sequences containing that motif
     */
    public int getAmountOfSequencesWithMotif(int m);

    /**
     *
     * @param m     a motif
     * @return      the amount of sequences containing that motif
     */
    public int getAmountOfSequencesWithMotif(String m);

    /**
     *
     * @param m     a motif number
     * @return      the sequences containing that motif
     */
    public char[] getProteinsWithSequencesWithMotif(int m);

    /**
     *
     * @param m     a motif
     * @return      the sequences containing that motif
     */
    public char[] getProteinsWithSequencesWithMotif(String m);
    
    /**
     * Indicates whether the returned values of this IMotifData should be cached
     * (because getting them might take a significant amount of time)
     * 
     * @return
     */
    public boolean wantsCaching();
}
