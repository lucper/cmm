package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.AminoAcids;
import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author Peter Boyen
 */
public class SlideIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * Used for saving the locations of all nonx characters
     */
    private int[] $nonxIndices;
    /**
     * Used for saving the locations of the x characters
     */
    private int[] $xIndices;
    /**
     * The amount of x characters after the last letter
     */
    private int $amountOfEndingXes;
    private int $neighboursFirst;
    private int $neighboursLast;

    protected SlideIterator(String ldMotif)
    {
        $ldMotif = ldMotif;

        $current = 0;

        int l = MaskArray.$subsequenceLength;
        int d = MaskArray.$wildCards;
        int letters = l - d;

        $nonxIndices = new int[MaskArray.$subsequenceLength - MaskArray.$wildCards];
        int currentNonXIndex = 0;

        $xIndices = new int[MaskArray.$wildCards];
        int currentXIndex = 0;


        for (int i = 0; i < ldMotif.length(); i++)
        {
            if (ldMotif.charAt(i) != 'x')
            {
                $nonxIndices[currentNonXIndex] = i;
                currentNonXIndex++;
            } else
            {
                $xIndices[currentXIndex] = i;
                currentXIndex++;
            }
        }

        $max = 0;

        // For everything but the first and last, the amount of removed wildcards (k) is the same
        $amountOfEndingXes = (l - 1) - $nonxIndices[$nonxIndices.length - 1];
        //                      total Xes * each letter on each x - but not the same motif
        int possibleNeighbours = (d + 1 + $amountOfEndingXes) * AminoAcids.getSize();// - 1;

        $max += possibleNeighbours * (letters - 2);

        // neighbours for the first letter
        int amountOfXes = d + 1 + (l - ($nonxIndices[$nonxIndices.length - 1] - $nonxIndices[1] + 1));
        $neighboursFirst = amountOfXes * AminoAcids.getSize();// - 1;
        $max += $neighboursFirst;

        // neighbours for the last letter
        amountOfXes = d + 1 + (l - ($nonxIndices[$nonxIndices.length - 2] - $nonxIndices[0] + 1));
        $neighboursLast = amountOfXes * AminoAcids.getSize();// - 1;
        $max += $neighboursLast;
    }

    public String next()
    {
        String result = getNeighbour($current);

        $current++;

        return result;
    }

    public boolean hasNext()
    {
        return $current < $max;
    }

    public void remove()
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int getMax()
    {
        return $max;
    }

    public String getNeighbour(int index)
    {
        if (index < $neighboursFirst)
        {
            int deletedLetterIndex = 0;
            char deletedLetter = $ldMotif.charAt(deletedLetterIndex);

            StringBuffer result = new StringBuffer($ldMotif);
            result.replace(deletedLetterIndex, deletedLetterIndex + 1, "x");
            for (int i = 0; i < $amountOfEndingXes; i++)
            {
                result = result.insert(0, "x");
            }
            for (int i = 0; i < (MaskArray.$subsequenceLength - ($nonxIndices[$nonxIndices.length - 1] - $nonxIndices[1] + 1)) - $amountOfEndingXes; i++)
            {
                result = result.append("x");
            }

            char newLetter = AminoAcids.getLetterForIndex(index % AminoAcids.getSize());
            index /= AminoAcids.getSize();
            
            int possibleXes = MaskArray.$wildCards + 1 + (MaskArray.$subsequenceLength - ($nonxIndices[$nonxIndices.length - 1] - $nonxIndices[1] + 1));
            int newPositionIndex = index % possibleXes;
            
            /*if (newPositionIndex > deletedLetterIndex || (newPositionIndex == deletedLetterIndex && AminoAcids.getIndexForLetter(newLetter) >= AminoAcids.getIndexForLetter(deletedLetter)))
            {
                if (AminoAcids.getIndexForLetter(newLetter) + 1 == AminoAcids.getSize())
                {
                    newPositionIndex++;
                }
                newLetter = AminoAcids.getLetterForIndex((AminoAcids.getIndexForLetter(newLetter) + 1) % AminoAcids.getSize());
            }*/

            int x = 0;

            for (int i = 0; i < result.length(); i++)
            {
                if (result.charAt(i) == 'x')
                {
                    if (x == newPositionIndex)
                    {
                        result.setCharAt(i, newLetter);
                    }

                    x++;
                }
            }

            return makeLD(result.toString());
        }

        index -= $neighboursFirst;

        if (index < $neighboursLast)
        {
            int deletedLetterIndex = $nonxIndices[$nonxIndices.length - 1];
            char deletedLetter = $ldMotif.charAt(deletedLetterIndex);

            StringBuffer result = new StringBuffer($ldMotif);
            result.replace(deletedLetterIndex, deletedLetterIndex + 1, "x");
            
            int frontXes = (MaskArray.$subsequenceLength - ($nonxIndices[$nonxIndices.length - 2] - $nonxIndices[0] + 1));
            
            for (int i = 0; i < frontXes; i++)
            {
                result = result.insert(0, "x");
            }
            
            char newLetter = AminoAcids.getLetterForIndex(index % AminoAcids.getSize());
            index /= AminoAcids.getSize();

            int possibleXes = MaskArray.$wildCards + 1 + (MaskArray.$subsequenceLength - ($nonxIndices[$nonxIndices.length - 2] - $nonxIndices[0] + 1));
            int newPositionIndex = index % possibleXes;

            /*if (newPositionIndex > frontXes + $xIndices.length || (newPositionIndex == frontXes + $xIndices.length && AminoAcids.getIndexForLetter(newLetter) >= AminoAcids.getIndexForLetter(deletedLetter) ))
            {
                if (AminoAcids.getIndexForLetter(newLetter) + 1 == AminoAcids.getSize())
                {
                    newPositionIndex++;
                }
                newLetter = AminoAcids.getLetterForIndex((AminoAcids.getIndexForLetter(newLetter) + 1) % AminoAcids.getSize());
            }*/

            int x = 0;

            for (int i = 0; i < result.length(); i++)
            {
                if (result.charAt(i) == 'x')
                {
                    if (x == newPositionIndex)
                    {
                        result.setCharAt(i, newLetter);
                    }

                    x++;
                }
            }
            
            return makeLD(result.toString());
        }

        index -= $neighboursLast;

        int indind = (index % ($nonxIndices.length - 2)) + 1;
        int deletedLetterIndex = $nonxIndices[indind];
        index /= ($nonxIndices.length - 2);

        char deletedLetter = $ldMotif.charAt(deletedLetterIndex);

        StringBuffer result = new StringBuffer($ldMotif);
        result.replace(deletedLetterIndex, deletedLetterIndex + 1, "x");
        for (int i = 0; i < $amountOfEndingXes; i++)
        {
            result = result.insert(0, "x");
        }

        char newLetter = AminoAcids.getLetterForIndex(index % AminoAcids.getSize());
        index /= AminoAcids.getSize();

        int possibleXes = MaskArray.$wildCards + 1 + $amountOfEndingXes;
        int newPositionIndex = index % possibleXes;

        /*if (newPositionIndex > deletedLetterIndex + $amountOfEndingXes || (newPositionIndex == deletedLetterIndex + $amountOfEndingXes && AminoAcids.getIndexForLetter(newLetter) >= AminoAcids.getIndexForLetter(deletedLetter)))
        {
            if (AminoAcids.getIndexForLetter(newLetter) + 1 == AminoAcids.getSize())
            {
                newPositionIndex++;
            }
            newLetter = AminoAcids.getLetterForIndex((AminoAcids.getIndexForLetter(newLetter) + 1) % AminoAcids.getSize());
        }*/

        int x = 0;

        for (int i = 0; i < result.length(); i++)
        {
            if (result.charAt(i) == 'x')
            {
                if (x == newPositionIndex)
                {
                    result.setCharAt(i, newLetter);
                }

                x++;
            }
        }

        return makeLD(result.toString());
    }

    public String makeLD(String s)
    {
        s = s.replace('x', ' ').trim().replace(' ', 'x');

        while (s.length() < MaskArray.$subsequenceLength)
        {
            s += "x";
        }

        return s;
    }

    public static void main(String[] args)
    {
        MaskArray.$subsequenceLength = 4;
        MaskArray.$wildCards = 1;

        SlideIterator neighbourIterator = new SlideIterator("RxRN");
        System.out.println("only the neighbours who can be generated in several ways are returned several times.");

        int i = 1;

	HashMap<String, Integer> map = new HashMap<String, Integer>();

	while (neighbourIterator.hasNext())
	{
	    String neighbour = neighbourIterator.next();

	    System.out.println(i + " " + neighbour);
	    if (!map.containsKey(neighbour))
	    {
		map.put(neighbour, 1);
	    } else
	    {
		map.put(neighbour, map.get(neighbour) + 1);
	    }

	    i++;
	}

	if (!map.containsKey("RNxA"))
	{
	    System.out.println("RNxA missing");
	}

	if (!map.containsKey("RAxN"))
	{
	    System.out.println("RAxN missing");
	}
        
        if (!map.containsKey("ARxR"))
	{
	    System.out.println("ARxR missing");
	}
        
        if (!map.containsKey("RxRU"))
	{
	    System.out.println("RxRU missing");
	}

	// Shouldn't return itself
	if (map.containsKey("RxRN"))
	{
	    System.out.println("RxRN shouldn't be present, but occurs " + map.get("RxRN") + " times.");
	}

	// This iterator shouldn't change two letters
	if (map.containsKey("AxAN"))
	{
	    System.out.println("AxAN shouldn't be present");
	}

	Iterator<String> mapKeyIterator = map.keySet().iterator();
	while (mapKeyIterator.hasNext())
	{
	    String neighbour = mapKeyIterator.next();
	    if (map.get(neighbour) != 1)
	    {
		System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
	    }
	}
    }
}
