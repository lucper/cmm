package Data.MotifData.MotifPairIterators;

import Data.MotifData.MaskArray;
import Data.MotifData.MotifFunctions;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.ISequenceNeighbourFunction;
import Data.MotifData.MotifPairIterators.MotifNeighbourIterators.SequenceIteratorFactory;
import java.util.HashMap;
import java.util.Iterator;
import Util.Pairs.MotifPair;

/**
 * This class orders the possible neighbours of a motif pair and can return any given one
 * of them without iterating over all possibilities.
 * 
 * @author Peter Boyen
 */
public class MotifPairNeighbourFunction
{

    /**
     * An iterator over the first motif
     */
    private ISequenceNeighbourFunction $it1;
    /**
     * An iterator over the second motif
     */
    private ISequenceNeighbourFunction $it2;
    /**
     * The first motif
     */
    private String $motif1;
    /**
     * The second motif
     */
    private String $motif2;

    /**
     * Creates a new instance of MotifPairNeighbourFunction.
     * 
     * @param motif1                    The first motif
     * @param motif2                    The second motif
     * @param neighbourFunctionType	The kind of iteration desired (one of the static String members of {@link SequenceIteratorFactory}.
     */
    public MotifPairNeighbourFunction(String motif1, String motif2, String neighbourFunctionType)
    {
        $motif1 = motif1;
        $motif2 = motif2;

        $it1 = SequenceIteratorFactory.getSequenceNeighbourFunction(neighbourFunctionType, motif1);
        $it2 = SequenceIteratorFactory.getSequenceNeighbourFunction(neighbourFunctionType, motif2);
    }

    /**
     * 
     * @return      The total number of neighbours possible for the pair with the given neighbour function
     */
    public int getMax()
    {
        return ($it1.getMax() + 1) * ($it2.getMax() + 1);
    }

    /**
     * This function returns a neighbour of the motif pair. Either motif
     * might be the original. Every neighbour occurs in the order exactly once
     * (but they might occur twice if you take them as unordered).
     * 
     * @param index         The index of the desired neighbour
     * @return              A neighbour of the motif pair
     */
    public MotifPair getNeighbour(int index)
    {
        int index2 = index % ($it2.getMax() + 1);
        int index1 = index / ($it2.getMax() + 1);

        String motif1;
        String motif2;

        if (index1 == $it1.getMax())
        {
            motif1 = $motif1;
        } else
        {
            motif1 = $it1.getNeighbour(index1);
        }

        if (index2 == $it2.getMax())
        {
            motif2 = $motif2;
        } else
        {
            motif2 = $it2.getNeighbour(index2);
        }

        return new MotifPair(motif1, motif2);
    }

    public static void main(String[] args)
    {
        MaskArray.$subsequenceLength = 8;
        MaskArray.$wildCards = 5;
        
        MotifPairNeighbourFunction mpNf = new MotifPairNeighbourFunction("AxxRxNxx", "AxxRxxxR", SequenceIteratorFactory.$LCANDSA);

        HashMap<String, Integer> map = new HashMap<String, Integer>();
        
        for (int i = 0; i < mpNf.getMax(); i++)
        {
            MotifPair pair = mpNf.getNeighbour(i);
            
            String motifPair = MotifFunctions.makeMotifPair(pair.$fst, pair.$snd);
            
            if (!map.containsKey(motifPair))
	    {
		map.put(motifPair, 1);
	    } else
	    {
		map.put(motifPair, map.get(motifPair) + 1);
	    }

            System.out.println(i + " " + pair.$fst + "-" + pair.$snd);
        }
        
        Iterator<String> mapKeyIterator = map.keySet().iterator();
	while (mapKeyIterator.hasNext())
	{
	    String neighbour = mapKeyIterator.next();
	    if (map.get(neighbour) != 1)
	    {
		System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
	    }
	}
    }
}
