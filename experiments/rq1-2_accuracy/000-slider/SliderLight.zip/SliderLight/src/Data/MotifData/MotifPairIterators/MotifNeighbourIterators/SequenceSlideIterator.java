/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.MotifData.MaskArray;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Peter
 */
public class SequenceSlideIterator implements ISequenceNeighbourFunction, ISequenceNeighbourIterator
{

    public static void main(String[] args) throws Exception
    {
        MaskArray.set(8, 3);

        MaskArray m = MaskArray.getInstance();
        System.out.println("amount of masks: " + m.getAmountOfMasks());

        //IInteractionData interactionData = new InteractionArrayFactory().read("networks/bZip/");

        //char protein = 0;
        //int pos = 15;
        //SequenceSlideIterator it = new SequenceSlideIterator(interactionData.getSequence(protein), m.applyMask(interactionData.getSequence(protein).substring(pos, pos + MaskArray.$subsequenceLength), m.getRandomMask()));
        SequenceSlideIterator it = new SequenceSlideIterator("UUUUUUUUUUUUUUUUUARN", "UxUxxARN");

        System.out.println(it.getMax());

        int i = 0;
        while (it.hasNext())
        {
            System.out.println(i + " " + it.next());
            i++;
        }
    }

    private String $ldMotif;
    private String $sequence;
    private int $current;
    private int $max;
    private Pattern $p;
    private final int SLIDE = 3;

    public SequenceSlideIterator(String sequence, String ldMotif)
    {
        $ldMotif = ldMotif;

        int masks = MaskArray.getInstance().getAmountOfMasks();

        $sequence = sequence;

        $current = 0;
        $max = 0;

        $p = Pattern.compile($ldMotif.replace('x', ' ').trim().replace(' ', '.'));
        Matcher m = $p.matcher($sequence);

        while (m.find())
        {
            int startPos = m.start();

            $max += (1 + (2 * SLIDE)) * masks;

            if (startPos - SLIDE < 0)
            {
                // add a negative number
                $max += (startPos - SLIDE) * masks;
            }
            if (startPos + MaskArray.$subsequenceLength + SLIDE > $sequence.length())
            {
                // add a negative number
                $max += ($sequence.length() - (startPos + MaskArray.$subsequenceLength + SLIDE)) * masks;
            }
        }
    }

    public int getMax()
    {
        return $max;
    }

    public String getNeighbour(int index)
    {
        // endingXes cannot exceed the sequence length now

        Matcher m = $p.matcher($sequence);

        while (m.find())
        {
            int startPos = m.start();

            for (int newStartPos = Math.max(startPos - SLIDE, 0); newStartPos <= Math.min(startPos + SLIDE, $sequence.length() - MaskArray.$subsequenceLength); newStartPos++)
            {
                if (index < MaskArray.getInstance().getAmountOfMasks())
                {
                    return MaskArray.getInstance().applyMask($sequence.substring(newStartPos, newStartPos + MaskArray.$subsequenceLength), MaskArray.getInstance().getMask(index));
                }

                index -= MaskArray.getInstance().getAmountOfMasks();
            }
        }

        return null;
    }

    public String next()
    {
        $current++;

        return getNeighbour($current - 1);
    }

    public boolean hasNext()
    {
        return $current < $max;
    }

    public void remove()
    {
        throw new UnsupportedOperationException("Not supported.");
    }
}
