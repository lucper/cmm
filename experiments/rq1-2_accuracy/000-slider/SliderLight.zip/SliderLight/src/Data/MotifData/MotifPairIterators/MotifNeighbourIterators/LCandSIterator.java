package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.AminoAcids;
import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;

/**
 * This iterator will change all letters for every other amino acid.
 * 
 * <p/>
 * 
 * It will also move every letter to every possible x and then also change it for
 * every other amino acid.
 * 
 * @author Peter Boyen
 */
public class LCandSIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * Some neighbours are created using a LetterChangeIterator
     */
    private LCIterator $lcIt;
    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * Used for saving the locations of the movable nonx characters
     */
    private int[] $nonxIndices;
    /**
     * Used for saving the locations of the x characters
     */
    private int[] $xIndices;

    /**
     * Creates a new instance of LongStepIterator
     * 
     * @param ldMotif       The motif whose neighbours you want
     */
    protected LCandSIterator(String ldMotif)
    {
	$lcIt = new LCIterator(ldMotif);

	$ldMotif = ldMotif;

	$current = 0;

	$nonxIndices = new int[MaskArray.$subsequenceLength - MaskArray.$wildCards - 1];
	int currentNonXIndex = 0;

	$xIndices = new int[MaskArray.$wildCards];
	int currentXIndex = 0;


	for (int i = 1; i < ldMotif.length(); i++)
	{
	    if (ldMotif.charAt(i) != 'x')
	    {
		$nonxIndices[currentNonXIndex] = i;
		currentNonXIndex++;
	    } else
	    {
		$xIndices[currentXIndex] = i;
		currentXIndex++;
	    }
	}

	// Move every non-x but the first, to any x position, and change it to any letter
	$max = (MaskArray.$subsequenceLength - MaskArray.$wildCards - 1) * MaskArray.$wildCards * AminoAcids.getSize() + $lcIt.getMax();
    }

    /**
     * 
     * @return  Whether there is still a neighbour to be returned
     */
    public boolean hasNext()
    {
	return $current < $max;
    }

    /**
     * 
     * @return      The next neighbour String of the original String
     */
    public String next()
    {
	String result = getNeighbour($current);

	$current++;

	return result;
    }

    /**
     * The amount of neighbours this iterator can generate, also one more than
     * the maximum the getNeighbour() function should be called with.
     * 
     * @return	    The amount of neighbours
     */
    public int getMax()
    {
	return $max;
    }

    /**
     * {@link ISequenceNeighbourFunction}s have an internal order on neighbours.
     * This function returns the neighbour at index i in that order.
     * 
     * @param index		The index
     * @return                  The neighbour at that index in the order
     */
    public String getNeighbour(int index)
    {
	if (index < $lcIt.getMax())
	{
	    return $lcIt.getNeighbour(index);
	}
	
	index -= $lcIt.getMax();
	
	// $current indicates the moving letter, the new location, the new letter
	int movingLetterIndex = $nonxIndices[index % $nonxIndices.length];
	index /= $nonxIndices.length;

	int newPositionIndex = $xIndices[index % $xIndices.length];
	index /= $xIndices.length;

	char newLetter = AminoAcids.getLetterForIndex(index);

	char[] temp = $ldMotif.toCharArray();

	temp[newPositionIndex] = newLetter;
	temp[movingLetterIndex] = 'x';

	return new String(temp);
    }

    /**
     * UnsupportedOperationException("Not supported.");
     */
    public void remove()
    {
	throw new UnsupportedOperationException("Not supported.");
    }

    public static void main(String[] args)
    {
	//AminoAcids.setDisjunctive(true);
        MaskArray.$subsequenceLength = 8;
        MaskArray.$wildCards = 5;

	ISequenceNeighbourIterator neighbourIterator = new LCandSIterator("AxxQxxxN");

	int i = 1;

	HashMap<String, Integer> map = new HashMap<String, Integer>();

	while (neighbourIterator.hasNext())
	{
	    String neighbour = neighbourIterator.next();

	    System.out.println(i + " " + neighbour);
	    if (!map.containsKey(neighbour))
	    {
		map.put(neighbour, 1);
	    } else
	    {
		map.put(neighbour, map.get(neighbour) + 1);
	    }

	    i++;
	}
	
	if (!map.containsKey("AWxxxxxN"))
	{
	    System.out.println("AWxxxxxN missing");
	}
	
	if (!map.containsKey("AxAxxxxN"))
	{
	    System.out.println("AxAxxxxN missing");
	}
	
	if (!map.containsKey("AxxxRxxN"))
	{
	    System.out.println("AxxxRxxN missing");
	}
	
	if (!map.containsKey("AxxxxWxN"))
	{
	    System.out.println("AxxxxWxN missing");
	}
	
	if (!map.containsKey("AxxxxxRN"))
	{
	    System.out.println("AxxxxxRN missing");
	}
	
	if (!map.containsKey("AVxQxxxx"))
	{
	    System.out.println("AVxQxxxx missing");
	}
	
	if (!map.containsKey("AxRQxxxx"))
	{
	    System.out.println("AxRQxxxx missing");
	}
	
	if (!map.containsKey("AxxQQxxx"))
	{
	    System.out.println("AxxQQxxx missing");
	}
	
	if (!map.containsKey("AxxQxVxx"))
	{
	    System.out.println("AxxQxVxx missing");
	}
	
	if (!map.containsKey("AxxQxxAx"))
	{
	    System.out.println("AxxQxxAx missing");
	}
	
	if (!map.containsKey("RxxQxxxN"))
	{
	    System.out.println("RxxQxxxN missing");
	}
	
	if (!map.containsKey("AxxRxxxN"))
	{
	    System.out.println("AxxRxxxN missing");
	}
	
	if (!map.containsKey("AxxQxxxV"))
	{
	    System.out.println("AxxQxxxV missing");
	}
	
	
	//////////

	if (!map.containsKey("QxxQxxxN"))
	{
	    System.out.println("QxxQxxxN missing");
	}

	if (!map.containsKey("AxxNxxxN"))
	{
	    System.out.println("AxxNxxxN missing");
	}

	if (!map.containsKey("AxxQxxxQ"))
	{
	    System.out.println("AxxQxxxQ missing");
	}

	if (!map.containsKey("AxQxxxxN"))
	{
	    System.out.println("AxQxxxxN missing");
	}

	if (!map.containsKey("AQxxxxxN"))
	{
	    System.out.println("AQxxxxxN missing");
	}

	if (!map.containsKey("AxxQMxxx"))
	{
	    System.out.println("AxxQMxxx missing");
	}

	// Shouldn't return itself
	if (map.containsKey("AxxQxxxN"))
	{
	    System.out.println("AxxQxxxN shouldn't be present");
	}

	// This iterator shouldn't change two letters
	if (map.containsKey("QxxAxxxQ"))
	{
	    System.out.println("QxxAxxxQ shouldn't be present");
	}

	Iterator<String> mapKeyIterator = map.keySet().iterator();
	while (mapKeyIterator.hasNext())
	{
	    String neighbour = mapKeyIterator.next();
	    if (map.get(neighbour) != 1)
	    {
		System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
	    }
	}
    }
}
