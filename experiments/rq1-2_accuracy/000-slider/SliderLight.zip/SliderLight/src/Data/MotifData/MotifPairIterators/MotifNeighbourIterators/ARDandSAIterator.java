package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.AminoAcids;
import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * This iterator is meant to use non-fixed disjunction in local search. For each
 * set of letters in the motif, each amino acid is either removed (if it was already present
 * and the set is larger than 1) or added (if it wasn't present).
 * <p/>
 * Also sets of letters can be switched with an x if it is adjacent to the set and then
 * have one letter added or removed.
 * 
 * @author Peter Boyen
 */
public class ARDandSAIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * A {@link DisjunctiveIterator} makes part of the neighbours
     */
    private ARDIterator $dIt;
    /**
     * A {@link DisjunctiveSwitchIterator} makes part of the neighbours
     */
    private DSAIterator $dsIt;
    /**
     * Keep the groups of letters
     */
    private LinkedList<Character>[] $letterGroups;
    /**
     * Keep the indices of groups (of size 1) that can move left
     */
    private LinkedList<Integer> $oneLeft;
    /**
     * Keep the indices of groups (of size 1) that can move right
     */
    private LinkedList<Integer> $oneRight;
    /**
     * Keep the indices of groups (of size &gt; 1) that can move left
     */
    private LinkedList<Integer> $multipleLeft;
    /**
     * Keep the indices of groups (of size &gt; 1) that can move right
     */
    private LinkedList<Integer> $multipleRight;

    /**
     * Creates a new instance of DisjunctivePlusTwoStepIterator.
     * 
     * @param ldMotif       The original motif
     * @param l             The length of the motif
     * @param d             The amount of wildcards in the motif
     */
    protected ARDandSAIterator(String ldMotif)
    {
	$ldMotif = ldMotif;

	$current = 0;

	$letterGroups = new LinkedList[$ldMotif.length()];

	for (int i = 0; i < $letterGroups.length; i++)
	{
	    $letterGroups[i] = new LinkedList<Character>();
	}

	int group = 0;

	// Read the groups, either as a group like (ARN), or an x or a letter
	for (int i = 0; i < ldMotif.length(); i++)
	{
	    if (ldMotif.charAt(i) == '(')
	    {
		i++;

		while (ldMotif.charAt(i) != ')')
		{
		    $letterGroups[group].add(ldMotif.charAt(i));
		    i++;
		}
	    } else if (ldMotif.charAt(i) != 'x')
	    {
		$letterGroups[group].add(ldMotif.charAt(i));
	    }

	    group++;
	}

	$max = 0;

	$oneLeft = new LinkedList<Integer>();
	$oneRight = new LinkedList<Integer>();
	$multipleLeft = new LinkedList<Integer>();
	$multipleRight = new LinkedList<Integer>();

	for (int i = 1; i < $letterGroups.length - 1; i++)
	{
	    if ($letterGroups[i].size() == 1)
	    {
		if ($letterGroups[i - 1].size() == 0)
		{
		    $oneLeft.add(i);
		    $max += (AminoAcids.getSize() - 1);
		}
		if ($letterGroups[i + 1].size() == 0)
		{
		    $oneRight.add(i);
		    $max += (AminoAcids.getSize() - 1);
		}
	    } else if ($letterGroups[i].size() > 1)
	    {
		if ($letterGroups[i - 1].size() == 0)
		{
		    $multipleLeft.add(i);
		    $max += AminoAcids.getSize();
		}
		if ($letterGroups[i + 1].size() == 0)
		{
		    $multipleRight.add(i);
		    $max += AminoAcids.getSize();
		}
	    }
	}

	if ($letterGroups[$letterGroups.length - 1].size() == 1)
	{
	    if ($letterGroups[$letterGroups.length - 2].size() == 0)
	    {
		$oneLeft.add($letterGroups.length - 1);
		$max += (AminoAcids.getSize() - 1);
	    }
	} else if ($letterGroups[$letterGroups.length - 1].size() > 1)
	{
	    if ($letterGroups[$letterGroups.length - 2].size() == 0)
	    {
		$multipleLeft.add($letterGroups.length - 1);
		$max += AminoAcids.getSize();
	    }
	}

	$dIt = new ARDIterator(ldMotif);
	$dsIt = new DSAIterator(ldMotif);

	$max = $max + $dIt.getMax() + $dsIt.getMax();
    }

    /**
     * 
     * @return  Whether there is still a neighbour to be returned
     */
    public boolean hasNext()
    {
	return $current < $max;
    }

    /**
     * 
     * @return      The next neighbour String of the original String
     */
    public String next()
    {
	String result = getNeighbour($current);

	$current++;

	return result;
    }

    /**
     * The amount of neighbours this iterator can generate, also one more than
     * the maximum the getNeighbour() function should be called with.
     * 
     * @return	    The amount of neighbours
     */
    public int getMax()
    {
	return $max;
    }

    /**
     * {@link ISequenceNeighbourFunction}s have an internal order on neighbours.
     * This function returns the neighbour at index i in that order.
     * 
     * @param index		The index
     * @return                  The neighbour at that index in the order
     */
    public String getNeighbour(int index)
    {
	if (index < $dIt.getMax())
	{
	    return $dIt.getNeighbour(index);
	}

	index -= $dIt.getMax();

	if (index < $dsIt.getMax())
	{
	    return $dsIt.getNeighbour(index);
	}

	index -= $dsIt.getMax();

	String result = "";

	if (index < (($oneLeft.size() + $oneRight.size()) * (AminoAcids.getSize() - 1)))
	{
	    int move = index % ($oneLeft.size() + $oneRight.size());
	    index = index / ($oneLeft.size() + $oneRight.size());

	    if (move < $oneLeft.size())
	    {
		int moveIndex = $oneLeft.get(move);

		char newLetter = AminoAcids.getLetterForIndex(index);
		if (AminoAcids.getIndexForLetter($letterGroups[moveIndex].get(0)) <= index)
		{
		    newLetter = AminoAcids.getLetterForIndex(index + 1);
		}
		for (int i = 0; i < $letterGroups.length; i++)
		{
		    if (i != moveIndex - 1)
		    {
			result += makeString($letterGroups[i]);
		    } else
		    {
			LinkedList<Character> temp = (LinkedList<Character>) $letterGroups[i + 1].clone();
			if (temp.contains(newLetter))
			{
			    temp.remove((Character) newLetter);
			} else
			{
			    temp.add((Character) newLetter);
			}

			result += (makeString(temp) + "x");

			i++;
		    }
		}

		return result;
	    }

	    move -= $oneLeft.size();

	    if (move < $oneRight.size())
	    {
		int moveIndex = $oneRight.get(move);

		char newLetter = AminoAcids.getLetterForIndex(index);
		if (AminoAcids.getIndexForLetter($letterGroups[moveIndex].get(0)) <= index)
		{
		    newLetter = AminoAcids.getLetterForIndex(index + 1);
		}
		for (int i = 0; i < $letterGroups.length; i++)
		{
		    if (i != moveIndex)
		    {
			result += makeString($letterGroups[i]);
		    } else
		    {
			LinkedList<Character> temp = (LinkedList<Character>) $letterGroups[i].clone();
			if (temp.contains(newLetter))
			{
			    temp.remove((Character) newLetter);
			} else
			{
			    temp.add((Character) newLetter);
			}

			result += ("x" + makeString(temp));
			
			i++;
		    }
		}

		return result;
	    }
	}

	index -= ($oneLeft.size() + $oneRight.size()) * (AminoAcids.getSize() - 1);

	int move = index % ($multipleLeft.size() + $multipleRight.size());
	index = index / ($multipleLeft.size() + $multipleRight.size());

	if (move < $multipleLeft.size())
	{
	    int moveIndex = $multipleLeft.get(move);

	    char newLetter = AminoAcids.getLetterForIndex(index);

	    for (int i = 0; i < $letterGroups.length; i++)
	    {
		if (i != moveIndex - 1)
		{
		    result += makeString($letterGroups[i]);
		} else
		{
		    LinkedList<Character> temp = (LinkedList<Character>) $letterGroups[i + 1].clone();
		    if (temp.contains(newLetter))
		    {
			temp.remove((Character) newLetter);
		    } else
		    {
			temp.add((Character) newLetter);
		    }

		    result += (makeString(temp) + "x");

		    i++;
		}
	    }

	    return result;
	}

	move -= $multipleLeft.size();

	int moveIndex = $multipleRight.get(move);

	char newLetter = AminoAcids.getLetterForIndex(index);

	for (int i = 0; i < $letterGroups.length; i++)
	{
	    if (i != moveIndex)
	    {
		result += makeString($letterGroups[i]);
	    } else
	    {
		LinkedList<Character> temp = (LinkedList<Character>) $letterGroups[i].clone();
		if (temp.contains(newLetter))
		{
		    temp.remove((Character) newLetter);
		} else
		{
		    temp.add((Character) newLetter);
		}

		result += ("x" + makeString(temp));
		
		i++;
	    }
	}

	return result;
    }

    /**
     * Given a list of characters returns the String used for representing the disjunction
     * of those characters. E.g. thee list[A, R, N] will return "(ARN)".
     * <br/>
     * If the list is null or empty "x" is returned.
     * <br/>
     * If the list contains only one element, that element is returned.
     * 
     * @param l         The lettergroup
     * @return          The String representing that letter group
     */
    private String makeString(LinkedList<Character> l)
    {
	if (l == null || l.size() == 0)
	{
	    return "x";
	}
	if (l.size() == 1)
	{
	    return "" + l.get(0);
	}

	String result = "(";

	for (int i = 0; i < l.size(); i++)
	{
	    result += l.get(i);
	}

	return result + ")";
    }

    /**
     * UnsupportedOperationException("Not supported.");
     */
    public void remove()
    {
	throw new UnsupportedOperationException("Not supported.");
    }

    public static void main(String[] args)
    {
	//AminoAcids.setDisjunctive(true);

	ISequenceNeighbourIterator neighbourIterator = new ARDandSAIterator("AxxQxxx(AN)");

	int i = 1;

	HashMap<String, Integer> map = new HashMap<String, Integer>();

	while (neighbourIterator.hasNext())
	{
	    String neighbour = neighbourIterator.next();

	    System.out.println(i + " " + neighbour);
	    if (!map.containsKey(neighbour))
	    {
		map.put(neighbour, 1);
	    } else
	    {
		map.put(neighbour, map.get(neighbour) + 1);
	    }

	    i++;
	}

	if (!map.containsKey("(AN)xxQxxx(AN)"))
	{
	    System.out.println("(AN)xxQxxx(AN) missing");
	}

	if (!map.containsKey("AxxQxx(AN)x"))
	{
	    System.out.println("AxxQxx(AN)x missing");
	}

	if (!map.containsKey("AxQxxxx(AN)"))
	{
	    System.out.println("AxQxxxx(AN) missing");
	}

	if (!map.containsKey("AxxxQxx(AN)"))
	{
	    System.out.println("AxxxQxx(AN) missing");
	}

	if (!map.containsKey("AxxQxx(ANQ)x"))
	{
	    System.out.println("AxxQxx(ANQ)x missing");
	}

	if (!map.containsKey("AxxQxxAx"))
	{
	    System.out.println("AxxQxxAx missing");
	}

	if (!map.containsKey("Axxx(AQ)xx(AN)") && !map.containsKey("Axxx(QA)xx(AN)"))
	{
	    System.out.println("Axxx(AQ)xx(AN) missing");
	}

	// Shouldn't return itself
	if (map.containsKey("AxxQxxx(AN)"))
	{
	    System.out.println("AxxQxxx(AN) shouldn't be present");
	}

	// Shouldn't move one group and then change another
	if (map.containsKey("(AQ)xQxxxx(AN)"))
	{
	    System.out.println("(AQ)xQxxxx(AN) shouldn't be present");
	}

	// This iterator shouldn't change two letters
	if (map.containsKey("QxxAxxxQ"))
	{
	    System.out.println("QxxAxxxQ shouldn't be present");
	}

	Iterator<String> mapKeyIterator = map.keySet().iterator();
	while (mapKeyIterator.hasNext())
	{
	    String neighbour = mapKeyIterator.next();
	    if (map.get(neighbour) != 1)
	    {
		System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
	    }
	}
    }
}
