package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.AminoAcids;
import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;

/**
 * This iterator changes all non-x characters into all the possible amino acids.
 * 
 * @author Peter Boyen
 */
public class LCIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * Used for saving the locations of the nonx characters
     */
    private int[] $nonxIndices;

    /**
     * Creates a new instance of LetterChangeIterator
     * 
     * @param ldMotif       The motif whose neighbours you want
     * @param l             The length of the motif
     * @param d             The amount of wildcards in the motif
     */
    protected LCIterator(String ldMotif)
    {
	$ldMotif = ldMotif;

	$nonxIndices = new int[MaskArray.$subsequenceLength - MaskArray.$wildCards];
	int currentIndex = 0;

	for (int i = 0; i < ldMotif.length(); i++)
	{
	    if (ldMotif.charAt(i) != 'x')
	    {
		$nonxIndices[currentIndex] = i;
		currentIndex++;
	    }
	}

	// the total number of possible mutations
	// Change the current (non-x) characters for all the others
	$max = (MaskArray.$subsequenceLength - MaskArray.$wildCards) * (AminoAcids.getSize() - 1);
	$current = 0;
    }

    /**
     * 
     * @return  Whether there is still a neighbour to be returned
     */
    public boolean hasNext()
    {
	return $current < $max;
    }

    /**
     * 
     * @return      The next neighbour String of the original String
     */
    public String next()
    {
	String result = getNeighbour($current);
	$current++;

	return result;
    }

    /**
     * The amount of neighbours this iterator can generate, also one more than
     * the maximum the getNeighbour() function should be called with.
     * 
     * @return	    The amount of neighbours
     */
    public int getMax()
    {
	return $max;
    }

    /**
     * {@link ISequenceNeighbourFunction}s have an internal order on neighbours.
     * This function returns the neighbour at index i in that order.
     * 
     * @param i		The index
     * @return		The neighbour at that index in the order
     */
    public String getNeighbour(int i)
    {
	// Find the letter to change
	int index = $nonxIndices[i / (AminoAcids.getSize() - 1)];

	// Change it for one of the other amino acids
	char[] temp = $ldMotif.toCharArray();
	char currentLetter = temp[index];
	temp[index] = AminoAcids.getLetterForIndex(i % (AminoAcids.getSize() - 1));

	if (AminoAcids.getIndexForLetter(currentLetter) <= AminoAcids.getIndexForLetter(temp[index]))
	{
	    temp[index] = AminoAcids.getLetterForIndex(i % (AminoAcids.getSize() - 1) + 1);
	}
	
	return new String(temp);
    }

    /**
     * UnsupportedOperationException("Not supported.");
     */
    public void remove()
    {
	throw new UnsupportedOperationException("Not supported.");
    }

    public static void main(String[] args)
    {
	//AminoAcids.setDisjunctive(true);

	ISequenceNeighbourIterator neighbourIterator = new LCIterator("AxxQxxxN");

	int i = 1;

	HashMap<String, Integer> map = new HashMap<String, Integer>();

	while (neighbourIterator.hasNext())
	{
	    String neighbour = neighbourIterator.next();

	    System.out.println(i + " " + neighbour);
	    if (!map.containsKey(neighbour))
	    {
		map.put(neighbour, 1);
	    } else
	    {
		map.put(neighbour, map.get(neighbour) + 1);
	    }

	    i++;
	}

	if (!map.containsKey("QxxQxxxN"))
	{
	    System.out.println("QxxQxxxN missing");
	}

	if (!map.containsKey("AxxNxxxN"))
	{
	    System.out.println("AxxNxxxN missing");
	}

	if (!map.containsKey("AxxQxxxQ"))
	{
	    System.out.println("AxxQxxxQ missing");
	}

	// Shouldn't return itself
	if (map.containsKey("AxxQxxxN"))
	{
	    System.out.println("AxxQxxxN shouldn't be present");
	}

	// This iterator shouldn't change two letters
	if (map.containsKey("QxxAxxxQ"))
	{
	    System.out.println("QxxAxxxQ shouldn't be present");
	}

	// This iterator shouldn't move a letter
	if (map.containsKey("AxQxxxxN"))
	{
	    System.out.println("AxQxxxxN shouldn't be present");
	}

	Iterator<String> mapKeyIterator = map.keySet().iterator();
	while (mapKeyIterator.hasNext())
	{
	    String neighbour = mapKeyIterator.next();
	    if (map.get(neighbour) != 1)
	    {
		System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
	    }
	}

    }
}
