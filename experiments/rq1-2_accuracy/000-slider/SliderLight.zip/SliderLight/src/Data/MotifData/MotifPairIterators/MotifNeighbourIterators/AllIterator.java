package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.MotifData.MaskArray;

/**
 *
 * @author Peter Boyen
 */
public class AllIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{
    private int $current;
    
    protected AllIterator(String ldMotif)
    {
        $current = 0;
    }

    public String next()
    {
        $current++;
        
        return MaskArray.getInstance().getMotifString($current - 1);
    }

    public boolean hasNext()
    {
        return $current < MaskArray.getInstance().getAmountOfMotifs();
    }

    public void remove()
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int getMax()
    {
        return MaskArray.getInstance().getAmountOfMotifs();
    }

    public String getNeighbour(int index)
    {
        return MaskArray.getInstance().getMotifString(index);
    }

    public static void main(String[] args) throws Exception
            {
        MaskArray.set(8, 3);
        
        AllIterator it = new AllIterator("ARNxRRxx");
        
        while(it.hasNext())
            {
            it.next();
        }
    }
}
