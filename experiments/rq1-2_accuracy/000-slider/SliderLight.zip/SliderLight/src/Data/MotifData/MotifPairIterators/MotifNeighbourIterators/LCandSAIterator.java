package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.AminoAcids;
import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * This iterator will allow for switching or changing letters as a MutateIterator,
 * but also for switching and then changing the letters.
 * 
 * @author Peter Boyen
 */
public class LCandSAIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * Some of the neighbours are created using a MutateIterator
     */
    private LCIterator $lcIt;
    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * The indices of letter that can be moved to the left
     */
    Vector<Integer> $moveLeft;
    /**
     * The indices of letter that can be moved to the right
     */
    Vector<Integer> $moveRight;

    /**
     * Creates a new instance of TwoStepIterator
     * 
     * @param ldMotif       The motif whose neighbours you want
     * @param l             The length of the motif
     * @param d             The amount of wildcards in the motif
     */
    protected LCandSAIterator(String ldMotif)
    {
	$lcIt = new LCIterator(ldMotif);

	$ldMotif = ldMotif;

	$current = 0;

	$moveLeft = new Vector<Integer>(MaskArray.$subsequenceLength - MaskArray.$wildCards);
	$moveRight = new Vector<Integer>(MaskArray.$subsequenceLength - MaskArray.$wildCards);

	for (int i = 1; i < MaskArray.$wildCards - 1; i++)
	{
	    if (ldMotif.charAt(i) != 'x')
	    {
		if (ldMotif.charAt(i - 1) == 'x')
		{
		    $moveLeft.add(i);
		}
		if (ldMotif.charAt(i + 1) == 'x')
		{
		    $moveRight.add(i);
		}
	    }
	}

	if (ldMotif.charAt(MaskArray.$wildCards - 1) != 'x' && ldMotif.charAt(MaskArray.$wildCards - 2) == 'x')
	{
	    $moveLeft.add(MaskArray.$wildCards - 1);
	}


	$max = ($moveLeft.size() + $moveRight.size()) * AminoAcids.getSize() + $lcIt.getMax();
    }

    /**
     * 
     * @return  Whether there is still a neighbour to be returned
     */
    public boolean hasNext()
    {
	return $current < $max;
    }

    /**
     * 
     * @return      The next neighbour String of the original String
     */
    public String next()
    {
	String result = getNeighbour($current);
	
	$current++;
	
	return result;
    }

    /**
     * The amount of neighbours this iterator can generate, also one more than
     * the maximum the getNeighbour() function should be called with.
     * 
     * @return	    The amount of neighbours
     */
    public int getMax()
    {
	return $max;
    }

    /**
     * {@link ISequenceNeighbourFunction}s have an internal order on neighbours.
     * This function returns the neighbour at index i in that order.
     * 
     * @param index		The index
     * @return                  The neighbour at that index in the order
     */
    public String getNeighbour(int index)
    {
	if (index < $lcIt.getMax())
	{
	    return $lcIt.getNeighbour(index);
	}
	index -= $lcIt.getMax();
	
	int move = index / AminoAcids.getSize();

	if (move < $moveLeft.size())
	{
	    char[] temp = $ldMotif.toCharArray();

	    temp[$moveLeft.get(move) - 1] = AminoAcids.getLetterForIndex(index % AminoAcids.getSize());
	    temp[$moveLeft.get(move)] = 'x';

	    return new String(temp);
	} else
	{
	    int rightMove = move - $moveLeft.size();

	    char[] temp = $ldMotif.toCharArray();

	    temp[$moveRight.get(rightMove) + 1] = AminoAcids.getLetterForIndex(index % AminoAcids.getSize());
	    temp[$moveRight.get(rightMove)] = 'x';

	    return new String(temp);
	}
    }

    /**
     * UnsupportedOperationException("Not supported.");
     */
    public void remove()
    {
	throw new UnsupportedOperationException("Not supported.");
    }

    public static void main(String[] args)
    {
	//AminoAcids.setDisjunctive(true);
        MaskArray.$subsequenceLength = 8;
        MaskArray.$wildCards = 5;

	ISequenceNeighbourIterator neighbourIterator = SequenceIteratorFactory.getSequenceIterator(SequenceIteratorFactory.$LCANDSA, "AxxQxxxN");

	int i = 1;

	HashMap<String, Integer> map = new HashMap<String, Integer>();

	while (neighbourIterator.hasNext())
	{
	    String neighbour = neighbourIterator.next();

	    System.out.println(i + " " + neighbour);
	    if (!map.containsKey(neighbour))
	    {
		map.put(neighbour, 1);
	    } else
	    {
		map.put(neighbour, map.get(neighbour) + 1);
	    }

	    i++;
	}

	if (!map.containsKey("QxxQxxxN"))
	{
	    System.out.println("QxxQxxxN missing");
	}

	if (!map.containsKey("AxxNxxxN"))
	{
	    System.out.println("AxxNxxxN missing");
	}

	if (!map.containsKey("AxxQxxxQ"))
	{
	    System.out.println("AxxQxxxQ missing");
	}

	if (!map.containsKey("AxQxxxxN"))
	{
	    System.out.println("AxQxxxxN missing");
	}

	// Shouldn't return itself
	if (map.containsKey("AxxQxxxN"))
	{
	    System.out.println("AxxQxxxN shouldn't be present");
	}

	// This iterator shouldn't change two letters
	if (map.containsKey("QxxAxxxQ"))
	{
	    System.out.println("QxxAxxxQ shouldn't be present");
	}

	Iterator<String> mapKeyIterator = map.keySet().iterator();
	while (mapKeyIterator.hasNext())
	{
	    String neighbour = mapKeyIterator.next();
	    if (map.get(neighbour) != 1)
	    {
		System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
	    }
	}
    }
}
