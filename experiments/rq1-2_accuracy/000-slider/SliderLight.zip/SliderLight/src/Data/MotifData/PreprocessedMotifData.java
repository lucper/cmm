package Data.MotifData;

import Data.InteractionData.IInteractionData;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

/**
 * This class contains data obtained from processing IInteractionData.
 * For every possible motif, given a length and amount of wildcards, it keeps
 * track of all the protein sequences containing that motif.
 * 
 * @author Peter Boyen
 */
public class PreprocessedMotifData implements IMotifData
{
    /**
     * The array in which the information is kept. The index of the first dimension is the motif number (which
     * can be found using the {@link MaskArray}). The array then found is an array of all proteins containing
     * that motif. The array is filled in precisely (its length is the amount of elements).
     */
    private char[][] $motifArray;

    /**
     * Creates a new instance of MotifData. This will create and fill the array with the relevant data.
     * 
     * @param interactionData       The sequence data and interaction data of the network to be processed. This can be created using a {@link Data.InteractionData.IInteractionDataFactory} such as {@link Data.InteractionData.InteractionArrayFactory}.
     */
    public PreprocessedMotifData(IInteractionData interactionData)
    {
        // Create the array with the necessary size for all possible motifs
        createMotifArray();

        // DEBUG
        //System.out.println("created, using: " + ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024)) + "MB");

        // Fill the array with the given data
        process(interactionData);

    // DEBUG
    //System.out.println("Processed, using: " + ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024)) + "MB");

    }

    /**
     * This function returns the amount of sequences in the original data that contains
     * a certain motif.
     * 
     * @param m         The number of a motif (can be found using the {@link MaskArray}
     * @return          The amount of sequences in the data containing this motif
     */
    public int getAmountOfSequencesWithMotif(int m)
    {
        return $motifArray[m] == null ? 0 : $motifArray[m].length;
    }

    /**
     * This function returns the amount of sequences in the original data that contain
     * a certain motif.
     * 
     * @param m         A String of a motif (l and d must be the same as used for constructing this instance)
     * @return          The amount of sequences in the data containing this motif
     */
    public int getAmountOfSequencesWithMotif(String m)
    {
        int motifm = MaskArray.getInstance().getMotifNumber(m);

        return getAmountOfSequencesWithMotif(motifm);
    }

    /**
     * This function returns the sequences in the original data that contains
     * a certain motif.
     * 
     * @param m         The number of a motif (can be found using the {@link MaskArray}
     * @return          The protein numbers that have sequences with this motif (these will be sorted)
     */
    public char[] getProteinsWithSequencesWithMotif(int m)
    {
        return $motifArray[m];
    }

    /**
     * This function returns the sequences in the original data that contains
     * a certain motif.
     * 
     * @param m         The String of a motif
     * @return          The list of protein numbers that have sequences with this motif (these will be sorted)
     */
    public char[] getProteinsWithSequencesWithMotif(String m)
    {
        AbstractList<String> motifs = MotifFunctions.getListForDisjunctiveMotif(m);

        if (motifs.size() == 1)
        {
            String motif = motifs.get(0);
            if (motif.split("&").length > 1)
            {
                return MotifFunctions.getIntersection(motif.split("&")[0], motif.split("&")[1], this);
            }

            return getProteinsWithSequencesWithMotif(MaskArray.getInstance().getMotifNumber(motif));
        }

        // If we come here the motif used disjunction, the correct response is the union
        // of all possible motifs formed from that disjunction

        HashSet<Character> result = new HashSet<Character>();

        // Get the result for each separate non-disjunctive motif
        for (int i = 0; i < motifs.size(); i++)
        {
            int motifm = MaskArray.getInstance().getMotifNumber(motifs.get(i));

            char[] tempResult = getProteinsWithSequencesWithMotif(motifm);

            if (tempResult != null)
            {
                // Add these results to the set
                for (int j = 0; j < tempResult.length; j++)
                {
                    result.add(tempResult[j]);
                }
            }
        }

        // Put the results in an int[]
        char[] temp = new char[result.size()];

        Iterator<Character> it = result.iterator();
        int i = 0;
        while (it.hasNext())
        {
            temp[i] = it.next();
            i++;
        }

        // sort
        Arrays.sort(temp);

        return temp;
    }

    /**
     * This function creates the motif array and sets all of its arrays to null.
     * 
     * @param subsequenceLength         The length of motifs
     * @param wildCards                 The amount of wildcards in motifs
     */
    private void createMotifArray()
    {
        $motifArray = new char[MaskArray.getInstance().getAmountOfMotifs()][];

        for (int i = 0; i < $motifArray.length; i++)
        {
            $motifArray[i] = null;
        }
    }

    /**
     * This function goes through all sequences of proteins in the data and saves the occurrences
     * of all motifs.
     * 
     * @param interactionData         The {@link IInteractionData} to be processed. This can be made using an {@link IInteractionDataFactory}, such as {@link InteractionArrayFactory}
     */
    private void process(IInteractionData interactionData)
    {
        // For every sequence
        for (char i = 0; i < interactionData.getNumberOfProteins(); i++)
        {
            // DEBUG
            System.out.println((i + 1) + " / " + interactionData.getNumberOfProteins() + "     " + ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024)) + "MB");

            String sequence = interactionData.getSequence(i);
            SubsequenceAsLongIterator it = new SubsequenceAsLongIterator(sequence, MaskArray.$subsequenceLength);

            // For every subsequence of length subsequenceLength
            while (it.hasNext())
            {
                long subsequence = it.next();

                // Process the subsequence
                processFoundSequence(i, subsequence);
            }

            // There is an end piece to every sequence that is smaller than subsequenceLength
            // But motifs can still be found there due to the wildcards
            // So also save these motifs
            String end = sequence.substring(sequence.length() - MaskArray.$subsequenceLength);
            processEndString(end, MaskArray.$wildCards, i);
        }
    }

    /**
     * This function sees to it that motifs ending in x can be satisfied by the end of a sequence
     * even if there is no letter to fill in for that x.
     * 
     * e.g. The motif Ax occurs in the sequence BBBA at the very end
     * 
     * @param end           The endString of length l (where l is the length of the motifs for this instance of MotifData)
     * @param wildCards     The amount of wildcards
     * @param sequenceNr    The number of the sequence this is the end of.
     */
    private void processEndString(String end, int wildCards, int sequenceNr)
    {
        // For every possible amount of wildcards
        for (int i = 1; i <= wildCards; i++)
        {
            // Iterate through the end string, adding an x at the end each time
            // e.g. ABCD becomes BCDx, then CDxx,...
            end = end.substring(1) + "x";

            // Get the motifs that can be made with this String
            AbstractList<String> motifs = getEndMotifs(end, wildCards - i);

            for (int j = 0; j < motifs.size(); j++)
            {
                // Save the found motif
                motifFound(MaskArray.getInstance().getMotifNumber(motifs.get(j)), sequenceNr);
            }
        }
    }

    /**
     * given a String with any number of x's at the back and an amount of x's yet to place,
     * all possible motifs are returned.
     * 
     * @param end           A string with a number of x's at the end
     * @param wildCards     The remaining amount of wildcards to be added
     * @return              A list of all possible motifs meeting these criteria
     */
    private AbstractList<String> getEndMotifs(String end, int wildCards)
    {
        AbstractList<String> motifs = new Vector<String>();

        getMotifsRecursive(end, wildCards, motifs, 1);

        return motifs;
    }

    /**
     * The recursive function that is the back end of the getEndMotifs function.
     * 
     * @param end           A string with a number of x's at the end
     * @param wildCards     The remaining amount of wildcards to be added
     * @param motifs        The motifs already found
     * @param lastX         The location of the x last placed (initially use 1)
     */
    private void getMotifsRecursive(String end, int wildCards, AbstractList<String> motifs, int lastX)
    {
        if (wildCards == 0)
        {
            // If all wanted wildcards are placed this is a desired motif
            motifs.add(end);
        } else
        {
            char[] endArray = end.toCharArray();

            // Starting from the last placed x move along
            for (int i = lastX; i < endArray.length; i++)
            {
                // If it isn't already an x consider it for placing an x
                if (endArray[i] != 'x')
                {
                    // Place an x but remeber the letter that was previously there
                    char c = endArray[i];
                    endArray[i] = 'x';

                    // Get the motifs possible for this adapted String (an x more inthe String and one less wildcard to place)
                    getMotifsRecursive(new String(endArray), wildCards - 1, motifs, i);

                    // Replace the old letter
                    endArray[i] = c;
                }
            }
        }
    }

    /**
     * For a given subsequence, all masks are applied and the resulting motifs are saved.
     * 
     * @param sequenceNr        The number of the protein in whose sequence this subsequence was found
     * @param subsequence       The subsequence represented as a long (see {@link SubsequenceAsLongIterator} for more information)
     */
    private void processFoundSequence(char sequenceNr, long subsequence)
    {
        // Every mask makes the subsequence into a motif
        for (int maskIndex = 0; maskIndex < MaskArray.getInstance().getAmountOfMasks(); maskIndex++)
        {
            // Save this found motif
            motifFound(MaskArray.getInstance().getMotifNumber(subsequence, maskIndex), sequenceNr);
        }
    }

    /**
     * Saves the information that a certain motif occurred in a certain sequence
     * 
     * @param motif             The number of the motif (for more info on motif numbers, see {@link MaskArray})
     * @param sequenceNr        The number of the protein whose subsequence adhered to this motif
     */
    private void motifFound(int motif, int sequenceNr)
    {
        if (sequenceNr > Character.MAX_VALUE)
        {
            throw new UnsupportedOperationException("maximum amount of proteins exceeded");
        }

        char charSequenceNr = (char) sequenceNr;

        if ($motifArray[motif] == null)
        {
            // If it is the first time this motif is found, initialize the array and add the motif
            $motifArray[motif] = new char[1];
            $motifArray[motif][0] = charSequenceNr;
        } // If the sequence hasn't already produced this motif
        else if ($motifArray[motif][$motifArray[motif].length - 1] != sequenceNr)
        {
            // Increases the size of the array by one so we can place the new sequenceNr
            increaseArraySize(motif);

            $motifArray[motif][$motifArray[motif].length - 1] = charSequenceNr;
        }
    }

    /**
     * Increases the size of the array for a given motif by 1. Performs no initialization of the new field.
     * 
     * @param motif             The number of the motif (for more info on motif numbers, see {@link MaskArray})
     */
    private void increaseArraySize(int motif)
    {
        // Make a new array with size one greater than the previous
        char[] temp = new char[$motifArray[motif].length + 1];

        // Copy the data from the previous to the new one
        System.arraycopy($motifArray[motif], 0, temp, 0, $motifArray[motif].length);

        // Set the array to the new one
        $motifArray[motif] = temp;
    }

    /**
     * Returns a representation of the subnetwork defined by two motif Strings.
     * 
     * @param m1        A motif String
     * @param m2        A motif String
     * @return          A String representation of a subnetwork
     */
    public String getSubnetworkRepresentation(String m1, String m2)
    {
        String l1String = Arrays.toString(getProteinsWithSequencesWithMotif(m1));
        String l2String = Arrays.toString(getProteinsWithSequencesWithMotif(m2));
        return l1String.compareTo(l2String) < 0 ? (l1String + "-" + l2String) : (l2String + "-" + l1String);
    }

    /**
     * These results don't need caching as they are direct lookups in a table
     *
     * @return      false
     */
    public boolean wantsCaching()
    {
        return false;
    }

    /**
     *
     * @return      The amount of motifs
     */
    public int getAmountOfMotifs()
    {
        return $motifArray.length;
    }
}
