package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;

/**
 * This iterator combines the LetterChangeIterator and the LetterSwitchIterator;
 * 
 * @author Peter Boyen
 */
public class LCorSAIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * Some neighbours are created using a LetterChangeIterator
     */
    private LCIterator $lcIt;
    /**
     * Some neighbours are created using a LetterSwitchIterator
     */
    private SAIterator $lsIt;

    /**
     * Creates a new instance of MutateIterator
     * 
     * @param ldMotif       The motif whose neighbours you want
     * @param l             The length of the motif
     * @param d             The amount of wildcards in the motif
     */
    protected LCorSAIterator(String ldMotif)
    {
	$lcIt = new LCIterator(ldMotif);
	$lsIt = new SAIterator(ldMotif);
    }

    /**
     * 
     * @return  Whether there is still a neighbour to be returned
     */
    public boolean hasNext()
    {
	return $lcIt.hasNext() || $lsIt.hasNext();
    }

    /**
     * 
     * @return      The next neighbour String of the original String
     */
    public String next()
    {
	if ($lcIt.hasNext())
	{
	    return $lcIt.next();
	}
	return $lsIt.next();
    }

    /**
     * The amount of neighbours this iterator can generate, also one more than
     * the maximum the getNeighbour() function should be called with.
     * 
     * @return	    The amount of neighbours
     */
    public int getMax()
    {
	return $lcIt.getMax() + $lsIt.getMax();
    }

    /**
     * {@link ISequenceNeighbourFunction}s have an internal order on neighbours.
     * This function returns the neighbour at index i in that order.
     * 
     * @param index		The index
     * @return                  The neighbour at that index in the order
     */
    public String getNeighbour(int index)
    {
	if(index < $lsIt.getMax())
	    return $lsIt.getNeighbour(index);
	else
	    return $lcIt.getNeighbour(index - $lsIt.getMax());
    }

    /**
     * UnsupportedOperationException("Not supported.");
     */
    public void remove()
    {
	throw new UnsupportedOperationException("Not supported.");
    }

    public static void main(String[] args)
    {
	//AminoAcids.setDisjunctive(true);
        MaskArray.$subsequenceLength = 8;
        MaskArray.$wildCards = 5;

	ISequenceNeighbourIterator neighbourIterator = new LCorSAIterator("AxxQxxxN");

	int i = 1;

	HashMap<String, Integer> map = new HashMap<String, Integer>();

	while (neighbourIterator.hasNext())
	{
	    String neighbour = neighbourIterator.next();

	    System.out.println(i + " " + neighbour);
	    if (!map.containsKey(neighbour))
	    {
		map.put(neighbour, 1);
	    } else
	    {
		map.put(neighbour, map.get(neighbour) + 1);
	    }

	    i++;
	}

	if (!map.containsKey("QxxQxxxN"))
	{
	    System.out.println("QxxQxxxN missing");
	}

	if (!map.containsKey("AxxNxxxN"))
	{
	    System.out.println("AxxNxxxN missing");
	}

	if (!map.containsKey("AxxQxxxQ"))
	{
	    System.out.println("AxxQxxxQ missing");
	}

	if (!map.containsKey("AxQxxxxN"))
	{
	    System.out.println("AxQxxxxN missing");
	}

	// Shouldn't return itself
	if (map.containsKey("AxxQxxxN"))
	{
	    System.out.println("AxxQxxxN shouldn't be present");
	}

	// This iterator shouldn't change two letters
	if (map.containsKey("QxxAxxxQ"))
	{
	    System.out.println("QxxAxxxQ shouldn't be present");
	}

	Iterator<String> mapKeyIterator = map.keySet().iterator();
	while (mapKeyIterator.hasNext())
	{
	    String neighbour = mapKeyIterator.next();
	    if (map.get(neighbour) != 1)
	    {
		System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
	    }
	}
    }
}
