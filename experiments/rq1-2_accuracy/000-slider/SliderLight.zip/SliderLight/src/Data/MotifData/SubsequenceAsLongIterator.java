package Data.MotifData;

import Data.AminoAcids;

/**
 * This class iterates over a sequence of amino acids, representing the occuring substrings
 * as longs. Every section of AminoAcids.getBitRepresentationSize() bits represents one letter. The number
 * those bits represent is the index of the letter (or letter group) in the {@link AminoAcids} array.
 * 
 * It iterates all subsrings of length $subsequenceLength.
 * 
 * If the motifs possible for shorter strings at the end of the String are desired they must be
 * found separately.
 * 
 * @author Peter Boyen
 */
public class SubsequenceAsLongIterator
{
    /**
     * The full String
     */
    protected String $sequence;
    /**
     * the current position
     */
    protected int $position;
    /**
     * The previous long representing the subsequence
     */
    protected long $subsequence;
    /**
     * The length of the desired subsequences
     */
    protected int $subsequenceLength;
    /**
     * The total amount of bits needed of the long to represent the substring
     */
    protected int $totalBitSize;

    public SubsequenceAsLongIterator(String sequence, int subsequenceLength)
    {
        $sequence = sequence;
        $position = 0;
        $subsequence = 0;

        $subsequenceLength = subsequenceLength;
        
        $totalBitSize = $subsequenceLength * AminoAcids.getBitRepresentationSize();
    }

    /**
     * See if the current position is too near the end.
     * 
     * @return	    Whether the String still goes on.
     */
    public boolean hasNext()
    {
        return $position + $subsequenceLength <= $sequence.length();
    }

    /**
     * 
     * @return	    The next substring as represented by a long
     */
    public long next()
    {
	// Get the first subsequence of this length
        if ($position == 0)
        {
            $subsequence = 0;
            for (int z = 0; z < $subsequenceLength; z++)
            {
                $subsequence = $subsequence << AminoAcids.getBitRepresentationSize(); 
                $subsequence += AminoAcids.getIndexForLetter($sequence.charAt(z));
            }
        } else
        {
	    // The following sequences can be made by shifting the previous one
            $subsequence = $subsequence << AminoAcids.getBitRepresentationSize();
	    // Then adding the new character
            $subsequence += AminoAcids.getIndexForLetter($sequence.charAt($position + $subsequenceLength - 1));
	    // And removing the bits that are no longer necessary
            $subsequence = $subsequence & (((1L) << $totalBitSize) - 1);
	    
	    // This is the same as removing the first character of the substring and then adding
	    // the new character at the back.
        }

        $position++;

        return $subsequence;
    }
}
