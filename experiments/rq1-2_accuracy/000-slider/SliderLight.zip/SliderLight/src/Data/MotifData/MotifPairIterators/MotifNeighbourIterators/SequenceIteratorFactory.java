package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.MotifData.MaskArray;

/**
 * This class generates ISequenceNeighbourIterators. This allows for passing an
 * iterator type to a function, so that different iterators could be used in that
 * function at different times.
 * 
 * @author Peter Boyen
 */
public class SequenceIteratorFactory
{

    /**
     * When using this argument, a {@link ARDIterator} is created.
     */
    public static final String $ARD = "ARD";
    /**
     * When using this argument, a {@link ARDandSAIterator} is created.
     */
    public static final String $ARDANDSA = "ARDandSA";
    /**
     * When using this argument, a {@link LCIterator} is created.
     */
    public static final String $LC = "LC";
    /**
     * When using this argument, a {@link SAIterator} is created.
     */
    public static final String $SA = "SA";
    /**
     * When using this argument, a {@link LCandSIterator} is created.
     */
    public static final String $LCANDS = "LCandS";
    /**
     * When using this argument, a {@link LCorSAIterator} is created.
     */
    public static final String $LCORSA = "LCorSA";
    /**
     * When using this argument, a {@link LCandSAIterator} is created.
     */
    public static final String $LCANDSA = "LCandSA";
    /**
     * When using this argument, a {@link SlideIterator} is created.
     */
    public static final String $SLIDE = "Slide";
    /**
     * When using this argument, a {@link SimpleSlideIterator} is created.
     */
    public static final String $SIMPLESLIDE = "SimpleSlide";
    public static final String $ALL = "All";
    public static final String $SEQUENCESLIDE = "SequenceSlide";

    /**
     * Returns an iterator of the speficied type. If a nonexistent type is specified an 
     * UnsupportedOperationException will be thrown.
     * 
     * @param iteratorType      One of the iterator types, one of the static String members of this class.
     * @param motif             A motif
     * @param l                 The length of the motif
     * @param d                 The amount of wildcards in the motif
     * @return                  An iterator for the neighbours of the motif of the given iterator type
     */
    public static ISequenceNeighbourIterator getSequenceIterator(String iteratorType, String motif)
    {
        return new SequenceNeighbourIterator(iteratorType, motif);
    }

    /**
     * Returns a neighbour function of the speficied type. If a nonexistent type is specified an 
     * UnsupportedOperationException will be thrown.
     * 
     * @param neighbourFunctionType     One of the neighbour function types, one of the static String members of this class.
     * @param motif                     A motif
     * @param l                         The length of the motif
     * @param d                         The amount of wildcards in the motif
     * @return                          An iterator for the neighbours of the motif of the given iterator type
     */
    public static ISequenceNeighbourFunction getSequenceNeighbourFunction(String neighbourFunctionType, String motif)
    {
        if ($ARD.equals(neighbourFunctionType))
        {
            return new ARDIterator(motif);
        }
        if ($ARDANDSA.equals(neighbourFunctionType))
        {
            return new ARDandSAIterator(motif);
        }
        if ($LC.equals(neighbourFunctionType))
        {
            return new LCIterator(motif);
        }
        if ($SA.equals(neighbourFunctionType))
        {
            return new SAIterator(motif);
        }
        if ($LCANDS.equals(neighbourFunctionType))
        {
            return new LCandSIterator(motif);
        }
        if ($LCORSA.equals(neighbourFunctionType))
        {
            return new LCorSAIterator(motif);
        }
        if ($LCANDSA.equals(neighbourFunctionType))
        {
            return new LCandSAIterator(motif);
        }
        if ($SLIDE.equals(neighbourFunctionType))
        {
            return new SlideIterator(motif);
        }
        if ($SIMPLESLIDE.equals(neighbourFunctionType))
        {
            return new SimpleSlideIterator(motif);
        }
        if ($ALL.equals(neighbourFunctionType))
        {
            return new AllIterator(motif);
        }
        if (neighbourFunctionType.startsWith($SEQUENCESLIDE))
        {
            throw new UnsupportedOperationException("Access through SequenceIteratorFactory not supported yet.");
            //return new SequenceSlideIterator(neighbourFunctionType.substring($SEQUENCESLIDE.length() + 1), motif);
        }

        throw new UnsupportedOperationException("Unknown neighbour function.");
    }

    public static void main(String[] args)
    {
        try
        {
            MaskArray.$subsequenceLength = 6;
            MaskArray.$wildCards = 3;
            ISequenceNeighbourIterator it = getSequenceIterator("nonexistent", "AAAxxx");
            System.out.println(false);
        } catch (UnsupportedOperationException ex)
        {
            System.out.println(true);
        }
    }

    private static class SequenceNeighbourIterator implements ISequenceNeighbourIterator
    {

        private ISequenceNeighbourFunction $neighbourFunction;
        private int $current;

        public SequenceNeighbourIterator(String iteratorType, String motif)
        {
            $neighbourFunction = getSequenceNeighbourFunction(iteratorType, motif);
            $current = 0;
        }

        public boolean hasNext()
        {
            return $current < $neighbourFunction.getMax();
        }

        public String next()
        {
            String result = $neighbourFunction.getNeighbour($current);

            $current++;

            return result;
        }

        /**
         * UnsupportedOperationException("Not supported.");
         */
        public void remove()
        {
            throw new UnsupportedOperationException("Not supported.");
        }
    }
}
