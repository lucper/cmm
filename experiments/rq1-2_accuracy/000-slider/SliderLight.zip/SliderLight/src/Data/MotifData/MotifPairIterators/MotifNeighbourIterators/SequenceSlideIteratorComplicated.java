package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.InteractionData.IInteractionData;
import Data.InteractionData.InteractionArrayFactory;
import Data.MotifData.MaskArray;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Peter Boyen
 */
public class SequenceSlideIteratorComplicated implements ISequenceNeighbourFunction, ISequenceNeighbourIterator
{

    public static void main(String[] args) throws Exception
    {
        int l = 4;
        MaskArray.set(l, 1);

        MaskArray m = MaskArray.getInstance();

        IInteractionData interactionData = new InteractionArrayFactory().read("networks/bZip/");

        SequenceSlideIteratorComplicated it = new SequenceSlideIteratorComplicated(interactionData, (char) 0, m.applyMask(interactionData.getSequence((char) 0).substring(0, 0 + l), m.getRandomMask()));

        System.out.println(it.getMax());
    }
    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * Used for saving the locations of all nonx characters
     */
    private int[] $nonxIndices;
    /**
     * Used for saving the locations of the x characters
     */
    private int[] $xIndices;
    private int $amountOfEndingXes;
    private Pattern $p;
    private String $sequence;
    private int $l;
    private int $d;
    private int $letters;

    protected SequenceSlideIteratorComplicated(IInteractionData interactionData, char protein, String ldMotif)
    {
        $ldMotif = ldMotif;
        System.out.println($ldMotif);

        $l = MaskArray.$subsequenceLength;
        $d = MaskArray.$wildCards;
        $letters = $l - $d;

        $nonxIndices = new int[MaskArray.$subsequenceLength - MaskArray.$wildCards];
        int currentNonXIndex = 0;

        $xIndices = new int[MaskArray.$wildCards];
        int currentXIndex = 0;


        for (int i = 0; i < $ldMotif.length(); i++)
        {
            if ($ldMotif.charAt(i) != 'x')
            {
                $nonxIndices[currentNonXIndex] = i;
                currentNonXIndex++;
            } else
            {
                $xIndices[currentXIndex] = i;
                currentXIndex++;
            }
        }

        $current = 0;

        $sequence = interactionData.getSequence(protein);

        $max = 0;

        $p = Pattern.compile($ldMotif.replace('x', ' ').trim().replace(' ', '.'));
        Matcher m = $p.matcher($sequence);

        while (m.find())
        {
            int startPos = m.start();

            // I remove the first
            if (startPos + $l + $nonxIndices[1] <= $sequence.length())
            {
                int freeXes = $nonxIndices[1] + $d;
                $max += freeXes;
            } else
            {
                //int freeXes = ($nonxIndices[1] + d) - ((startPos + l + $nonxIndices[1]) - sequence.length());
                int freeXes = $d + $sequence.length() - startPos - $l;
                $max += freeXes;
            }
            System.out.println($max);

            // I remove a middle one
            if (startPos - $amountOfEndingXes >= 0)
            {
                //FIXTHIS: klopt niet als eindXen over het einde van sequence gaan

                int freeXes = $d + $amountOfEndingXes;
                $max += (freeXes * ($letters - 2));
            } else
            {
                int freeXes = $d + startPos;
                $max += (freeXes * ($letters - 2));
            }
            System.out.println($max);

            // I remove the last one
            if (startPos - ($l - $nonxIndices[$nonxIndices.length - 2] - 1) >= 0)
            {
                int freeXes = $d + ($l - $nonxIndices[$nonxIndices.length - 2] - 1);
                $max += freeXes;
            } else
            {
                int freeXes = $d + startPos;
                $max += freeXes;
            }
            System.out.println($max);
        }
    }

    public int getMax()
    {
        return $max;
    }

    public String getNeighbour(int index)
    {
        Matcher m = $p.matcher($sequence);

        while (m.find())
        {
            int startPos = m.start();

            int freeXes = 0;
            // I remove the first
            if (startPos + $l + $nonxIndices[1] <= $sequence.length())
            {
                if (index < $xIndices.length)
                {
                    return newMotif(0, $xIndices[index]);
                }

                index -= $xIndices.length;

                if (index < $d)
                {
                    return newMotif(0, $l + index);
                }

                index -= $d;

            } else
            {
                //int freeXes = ($nonxIndices[1] + d) - ((startPos + l + $nonxIndices[1]) - sequence.length());
                freeXes = $d + $sequence.length() - startPos - $l;

                if (index < freeXes)
                {
                    if(true)
                        throw new UnsupportedOperationException();

                    index -= freeXes;
                }
            }



        }

        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String next()
    {
        $current++;
        return getNeighbour($current - 1);
    }

    public boolean hasNext()
    {
        return $current < $max;
    }

    public void remove()
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private String newMotif(int removedLetterPos, int newLetterPos)
    {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
