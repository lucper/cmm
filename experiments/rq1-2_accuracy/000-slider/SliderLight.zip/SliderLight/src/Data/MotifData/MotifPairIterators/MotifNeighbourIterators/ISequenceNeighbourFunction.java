package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

/**
 * ISequenceNeighbourFunction are classes that given a String return Strings that are similar
 * to that String. These String are used a neighbours of that String in a local search
 * algorithm.
 * 
 * @author Peter Boyen
 */
public interface ISequenceNeighbourFunction
{
    /**
     * 
     * @return	    The maximum index for calling the getNeighbour() function
     */
    public int getMax();

    /**
     * One of the similar Strings. the neighbours have an order, determined internally.
     * This function returns the neighbour at place index in that order.
     * 
     * @param index	    The index in the order.
     * @return		    The neighbour
     */
    public String getNeighbour(int index);
}
