/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Data.MotifData;

import java.util.HashMap;
import java.util.LinkedList;

/**
 * A cache for motif data. Depending on how the motif data is stored, this may speed things up enormously.
 *
 * A simple caching scheme, if the cache is full, the oldest entry is removed.
 *
 * @author Peter
 */
public class CachingMotifData implements IMotifData
{

    private IMotifData $motifData;
    private HashMap<Integer, Object> $intHash;
    private LinkedList<Integer> $intKeys;
    private HashMap<String, Object> $stringHash;
    private LinkedList<String> $stringKeys;
    private int $cacheSize;

    /**
     *
     * @param motifData         Another implementation of IMotifData
     * @param cacheSize         The amount of requests to cache
     */
    public CachingMotifData(IMotifData motifData, int cacheSize)
    {
        $motifData = motifData;
        $cacheSize = cacheSize;

        $intHash = new HashMap<Integer, Object>(cacheSize);
        $intKeys = new LinkedList<Integer>();

        $stringHash = new HashMap<String, Object>(cacheSize);
        $stringKeys = new LinkedList<String>();
    }

    public int getAmountOfSequencesWithMotif(int m)
    {
        return getProteinsWithSequencesWithMotif(m).length;
    }

    public int getAmountOfSequencesWithMotif(String m)
    {
        return getProteinsWithSequencesWithMotif(m).length;
    }

    public char[] getProteinsWithSequencesWithMotif(int m)
    {
        if ($intHash.containsKey(m))
        {
            return (char[]) $intHash.get(m);
        }

        char[] result = $motifData.getProteinsWithSequencesWithMotif(m);

        if ($intHash.size() == $cacheSize)
        {
            int key = $intKeys.removeFirst();
            $intHash.remove(key);
        }

        $intHash.put(m, result);
        $intKeys.addLast(m);

        return result;
    }

    public char[] getProteinsWithSequencesWithMotif(String m)
    {
        if ($stringHash.containsKey(m))
        {
            return ((char[]) $stringHash.get(m));
        }

        char[] result = $motifData.getProteinsWithSequencesWithMotif(m);

        if ($stringHash.size() == $cacheSize)
        {
            //System.out.println($stringKeys);
            //System.out.println($stringKeys.size());
            
            String key = $stringKeys.removeFirst();
            $stringHash.remove(key);
        }

        $stringHash.put(m, result);
        $stringKeys.addLast(m);

        return result;
    }

    public boolean wantsCaching()
    {
        return false;
    }

    public int getAmountOfMotifs()
    {
        return $motifData.getAmountOfMotifs();
    }
    
    /*public static void main(String[] args)
    {
    char[] test =
    {
    'a', 'b', 'c', 'd'
    };

    HashMap<Integer, Object> hash = new HashMap<Integer, Object>();
    hash.put(5, test);

    char[] retrieved = (char[]) hash.get(5);

    System.out.println(retrieved[2]);
    }*/
}
