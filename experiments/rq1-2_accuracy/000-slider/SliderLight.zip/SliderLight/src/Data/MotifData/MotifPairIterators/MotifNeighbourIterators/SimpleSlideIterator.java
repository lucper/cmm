package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.AminoAcids;
import Data.MotifData.MaskArray;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author Peter Boyen
 */
public class SimpleSlideIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;
    /**
     * Used for saving the locations of all nonx characters
     */
    private int[] $nonxIndices;
    /**
     * Used for saving the locations of the x characters
     */
    private int[] $xIndices;
    /**
     * The amount of x characters after the last letter
     */
    private int $firstOptions;
    private int $lastOptions;

    private String $firstString;
    private String $lastString;

    private int $endingXes;

    protected SimpleSlideIterator(String ldMotif)
    {
        $ldMotif = ldMotif;

        $current = 0;

        int l = MaskArray.$subsequenceLength;
        int d = MaskArray.$wildCards;
        //int letters = l - d;

        $nonxIndices = new int[MaskArray.$subsequenceLength - MaskArray.$wildCards];
        int currentNonXIndex = 0;

        $xIndices = new int[MaskArray.$wildCards];
        int currentXIndex = 0;


        for (int i = 0; i < ldMotif.length(); i++)
        {
            if (ldMotif.charAt(i) != 'x')
            {
                $nonxIndices[currentNonXIndex] = i;
                currentNonXIndex++;
            } else
            {
                $xIndices[currentXIndex] = i;
                currentXIndex++;
            }
        }

        $max = 0;

        if ($nonxIndices.length >= 2)
        {
            $endingXes = l - $nonxIndices[$nonxIndices.length - 1] - 1;

            $firstOptions = ($nonxIndices[1] + $endingXes) * AminoAcids.getSize();

            $lastOptions = (l - $nonxIndices[$nonxIndices.length - 2] - 1) * AminoAcids.getSize();

            $max = $firstOptions + $lastOptions;

            $firstString = makeLD($ldMotif.substring($nonxIndices[1]));

            $lastString = $ldMotif.substring(0, $nonxIndices[$nonxIndices.length - 2] + 1);
            while ($lastString.length() < MaskArray.$subsequenceLength)
            {
                $lastString = "x" + $lastString;
            }
        }
    }

    public String next()
    {
        String result = getNeighbour($current);

        $current++;

        return result;
    }

    public boolean hasNext()
    {
        return $current < $max;
    }

    public void remove()
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int getMax()
    {
        return $max;
    }

    public String getNeighbour(int index)
    {
        if (index < $firstOptions)
        {
            String result = $firstString;

            int newLetterIndex = MaskArray.$subsequenceLength - (index % ($nonxIndices[1] + $endingXes)) - 1;
            index /= ($nonxIndices[1] + $endingXes);

            char newLetter = AminoAcids.getLetterForIndex(index);

            char[] temp = result.toCharArray();
            temp[newLetterIndex] = newLetter;
            result = new String(temp);

            return result;
        } else
        {
            index -= $firstOptions;

            String result = $lastString;

            int newLetterIndex = (index % (MaskArray.$subsequenceLength - $nonxIndices[$nonxIndices.length - 2] - 1));
            index /= (MaskArray.$subsequenceLength - $nonxIndices[$nonxIndices.length - 2] - 1);

            char newLetter = AminoAcids.getLetterForIndex(index);

            char[] temp = result.toCharArray();
            temp[newLetterIndex] = newLetter;
            result = new String(temp);

            return makeLD(result);
        }

    //throw new UnsupportedOperationException();
    }

    public String makeLD(String s)
    {
        s = s.replace('x', ' ').trim().replace(' ', 'x');

        while (s.length() < MaskArray.$subsequenceLength)
        {
            s += "x";
        }

        return s;
    }

    public static void main(String[] args)
    {
        MaskArray.$subsequenceLength = 4;
        MaskArray.$wildCards = 1;

        SimpleSlideIterator neighbourIterator = new SimpleSlideIterator("RRNx");
        System.out.println("only the neighbours who can be generated in several ways are returned several times.");

        int i = 0;

        HashMap<String, Integer> map = new HashMap<String, Integer>();

        while (neighbourIterator.hasNext())
        {
            String neighbour = neighbourIterator.next();

            System.out.println(i + " " + neighbour);
            if (!map.containsKey(neighbour))
            {
                map.put(neighbour, 1);
            } else
            {
                map.put(neighbour, map.get(neighbour) + 1);
            }

            i++;
        }
/*
        if (!map.containsKey("RNxA"))
        {
            System.out.println("RNxA missing");
        }

        if (!map.containsKey("RAxN"))
        {
            System.out.println("RAxN missing");
        }

        if (!map.containsKey("ARxR"))
        {
            System.out.println("ARxR missing");
        }

        if (!map.containsKey("RxRU"))
        {
            System.out.println("RxRU missing");
        }

        // Shouldn't return itself
        if (map.containsKey("RxRN"))
        {
            System.out.println("RxRN shouldn't be present, but occurs " + map.get("RxRN") + " times.");
        }

        // This iterator shouldn't change two letters
        if (map.containsKey("AxAN"))
        {
            System.out.println("AxAN shouldn't be present");
        }
*/
        Iterator<String> mapKeyIterator = map.keySet().iterator();
        while (mapKeyIterator.hasNext())
        {
            String neighbour = mapKeyIterator.next();
            if (map.get(neighbour) != 1)
            {
                System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
            }
        }
    }
}
