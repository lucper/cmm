package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import Data.AminoAcids;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * This iterator is meant to use non-fixed disjunction in local search. For each
 * set of letters in the motif, each amino acid is either removed (if it was already present
 * and the set is larger than 1) or added (if it wasn't present).
 * 
 * @author Peter Boyen
 */
public class ARDIterator implements ISequenceNeighbourIterator, ISequenceNeighbourFunction
{

    /**
     * The original motif
     */
    private String $ldMotif;
    /**
     * The groups of letters in the original motif
     */
    private LinkedList<Character>[] $letterGroups;
    /**
     * The locations of the groups containing multiple letters
     */
    private LinkedList<Integer> $multipleLetterGroupLocations;
    /**
     * The locations of the groups containing only one letters
     */
    private LinkedList<Integer> $singleLetterGroupLocations;
    /**
     * How many neighbours were already returned
     */
    private int $current;
    /**
     * How many neighbours there are
     */
    private int $max;

    /**
     * Creates a new instance of DisjunctiveIterator
     * 
     * @param ldMotif       The motif whose neighbours you want
     * @param l             The length of the motif
     * @param d             The amount of wildcards in the motif
     */
    public ARDIterator(String ldMotif)
    {
        $ldMotif = ldMotif;

        $multipleLetterGroupLocations = new LinkedList<Integer>();
        $singleLetterGroupLocations = new LinkedList<Integer>();

        $letterGroups = new LinkedList[$ldMotif.length()];

        for (int i = 0; i < $letterGroups.length; i++)
        {
            $letterGroups[i] = new LinkedList<Character>();
        }

        int group = 0;

        // Read the groups, either as a group like (ARN), or an x or a letter
        for (int i = 0; i < ldMotif.length(); i++)
        {
            if (ldMotif.charAt(i) == '(')
            {
                i++;

                while (ldMotif.charAt(i) != ')')
                {
                    $letterGroups[group].add(ldMotif.charAt(i));
                    i++;
                }
		
		if($letterGroups[group].size() > 1)
		    $multipleLetterGroupLocations.add(group);
		else
		    $singleLetterGroupLocations.add(group);
		    
            } else if (ldMotif.charAt(i) != 'x')
            {
                $letterGroups[group].add(ldMotif.charAt(i));

                $singleLetterGroupLocations.add(group);
            }

            group++;
        }

        $current = 0;
        $max = $multipleLetterGroupLocations.size() * AminoAcids.getSize() + $singleLetterGroupLocations.size() * (AminoAcids.getSize() - 1);
    }

    /**
     * 
     * @return  Whether there is still a neighbour to be returned
     */
    public boolean hasNext()
    {
        return $current < $max;
    }

    /**
     * 
     * @return      The next neighbour String of the original String
     */
    public String next()
    {
        String result = getNeighbour($current);

        $current++;
        return result;
    }

    /**
     * Given a list of characters returns the String used for representing the disjunction
     * of those characters. E.g. thee list[A, R, N] will return "(ARN)".
     * <br/>
     * If the list is null or empty "x" is returned.
     * <br/>
     * If the list contains only one element, that element is returned.
     * 
     * @param l         The lettergroup
     * @return          The String representing that letter group
     */
    private String makeString(LinkedList<Character> l)
    {
        if (l == null || l.size() == 0)
        {
            return "x";
        }
        if (l.size() == 1)
        {
            return "" + l.get(0);
        }

        String result = "(";

        for (int i = 0; i < l.size(); i++)
        {
            result += l.get(i);
        }

        return result + ")";
    }
    
    /**
     * The amount of neighbours this iterator can generate, also one more than
     * the maximum the getNeighbour() function should be called with.
     * 
     * @return	    The amount of neighbours
     */
    public int getMax()
    {
	return $max;
    }

    /**
     * {@link ISequenceNeighbourFunction}s have an internal order on neighbours.
     * This function returns the neighbour at index i in that order.
     * 
     * @param index		The index
     * @return                  The neighbour at that index in the order
     */
    public String getNeighbour(int index)
    {
	String result = "";
	
	int workingCurrent = index;

        if (workingCurrent < $multipleLetterGroupLocations.size() * AminoAcids.getSize())
        {
            int letterLocation = $multipleLetterGroupLocations.get(workingCurrent % $multipleLetterGroupLocations.size());
            workingCurrent /= $multipleLetterGroupLocations.size();

            char newLetter = AminoAcids.getLetterForIndex(workingCurrent);

            for (int i = 0; i < $letterGroups.length; i++)
            {
                if (i != letterLocation)
                {
                    result += makeString($letterGroups[i]);
                } else
                {
                    LinkedList<Character> temp = (LinkedList<Character>) $letterGroups[i].clone();
                    if (temp.contains(newLetter))
                    {
                        temp.remove((Character)newLetter);
                    } else
                    {
                        temp.add((Character)newLetter);
                    }

                    result += makeString(temp);
                }
            }
        } else
        {
            workingCurrent -= $multipleLetterGroupLocations.size() * AminoAcids.getSize();

            int letterLocation = $singleLetterGroupLocations.get(workingCurrent % $singleLetterGroupLocations.size());
            workingCurrent /= $singleLetterGroupLocations.size();


            char oldLetter = $letterGroups[letterLocation].get(0);
            if (AminoAcids.getIndexForLetter(oldLetter) <= workingCurrent)
            {
                workingCurrent++;
            }

            char newLetter = AminoAcids.getLetterForIndex(workingCurrent);

            for (int i = 0; i < $letterGroups.length; i++)
            {
                if (i != letterLocation)
                {
                    result += makeString($letterGroups[i]);
                } else
                {
                    LinkedList<Character> temp = (LinkedList<Character>) $letterGroups[i].clone();

                    temp.add((Character)newLetter);
                    
                    result += makeString(temp);
                }
            }
        }
	
	return result;
    }

    /**
     * UnsupportedOperationException("Not supported.");
     */
    public void remove()
    {
        throw new UnsupportedOperationException("Not supported.");
    }

    public static void main(String[] args)
    {
        //AminoAcids.setDisjunctive(true);

        ISequenceNeighbourIterator neighbourIterator = new ARDIterator("AxxQxxx(AN)");

        int i = 1;

        HashMap<String, Integer> map = new HashMap<String, Integer>();

        while (neighbourIterator.hasNext())
        {
            String neighbour = neighbourIterator.next();

            System.out.println(i + " " + neighbour);
            if (!map.containsKey(neighbour))
            {
                map.put(neighbour, 1);
            } else
            {
                map.put(neighbour, map.get(neighbour) + 1);
            }

            i++;
        }

        if (!map.containsKey("(AN)xxQxxx(AN)"))
        {
            System.out.println("(AN)xxQxxx(AN) missing");
        }

        if (!map.containsKey("Axx(QN)xxx(AN)"))
        {
            System.out.println("Axx(QN)xxx(AN) missing");
        }

        if (!map.containsKey("AxxQxxxN"))
        {
            System.out.println("AxxQxxxN missing");
        }

        // Shouldn't return itself
        if (map.containsKey("AxxQxxx(AN)"))
        {
            System.out.println("AxxQxxx(AN) shouldn't be present");
        }

        // This iterator shouldn't change two letters
        if (map.containsKey("QxxAxxxQ"))
        {
            System.out.println("QxxAxxxQ shouldn't be present");
        }

        Iterator<String> mapKeyIterator = map.keySet().iterator();
        while (mapKeyIterator.hasNext())
        {
            String neighbour = mapKeyIterator.next();
            if (map.get(neighbour) != 1)
            {
                System.out.println("multiple: " + neighbour + " occurs " + map.get(neighbour) + " times");
            }
        }
    }
}
