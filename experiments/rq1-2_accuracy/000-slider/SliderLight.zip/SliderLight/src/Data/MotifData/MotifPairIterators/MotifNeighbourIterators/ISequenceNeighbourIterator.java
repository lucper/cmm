package Data.MotifData.MotifPairIterators.MotifNeighbourIterators;

import java.util.Iterator;

/**
 * ISequenceNeighbourIterators are Iterators that given a String return Strings that are similar
 * to that String. These String are used a neighbours of that String in a local search
 * algorithm.
 * 
 * @author Peter Boyen
 */
public interface ISequenceNeighbourIterator extends Iterator
{
    public String next();
}
