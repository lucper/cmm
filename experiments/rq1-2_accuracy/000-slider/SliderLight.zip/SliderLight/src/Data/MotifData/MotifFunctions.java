package Data.MotifData;

import Data.AminoAcids;
import java.util.AbstractList;
import java.util.LinkedList;
import java.util.Random;

/**
 * This class provides some general functions relating to motifs
 * 
 * @author Peter Boyen
 */
public class MotifFunctions
{

    /**
     * Makes two motifs into a unique motif pair (instead of two options)
     * The return String will be the two motifs (in alphabetical order) with a - in
     * between them.
     * 
     * @param m1	A motif
     * @param m2	A motif
     * @return		The String for the motif pair
     */
    public static String makeMotifPair(String m1, String m2)
    {
        return m1.compareTo(m2) < 0 ? (m1 + "-" + m2) : (m2 + "-" + m1);
    }

    /**
     * This function returns the list of non-disjunctive motifs possibly formed by a motif
     * allowing disjunction.
     * <p/>
     * E.g. The motif (A|B)C(D|E)xxx will return a list containing ACDxxx, ACExxx, BCDxxx, BCExxx (not
     * necessarily in that order).
     * 
     * @param motif	    The (not necessarily) disjunctive motif
     * @return		    A list of all possible non disjunctive motifs that can be made from the motif
     */
    public static AbstractList<String> getListForDisjunctiveMotif(String motif)
    {
        AbstractList<String> result = new LinkedList<String>();

        makeRecursive(motif, "", result);

        return result;
    }

    /**
     * The initial call of this function should be with a motif, an empty String and an empty list.
     * After execution the list will contain all possible motifs formed with the disjunctive motif.
     * 
     * @param motif		    The motif
     * @param currentString	    The already constructed String
     * @param list		    The current List
     */
    private static void makeRecursive(String motif, String currentString, AbstractList<String> list)
    {
        boolean split = false;

        for (int i = 0; i < motif.length() & !split; i++)
        {
            if (motif.charAt(i) != '(')
            {
                // Just add this to the current String
                currentString += motif.charAt(i);
            } else
            {
                i++;
                LinkedList<Character> letters = new LinkedList<Character>();

                // Find all the characters in the disjunction
                while (motif.charAt(i) != ')')
                {
                    letters.add(motif.charAt(i));
                    i++;
                }

                if (letters.size() == 1)
                {
                    // If there's only one, just add it again
                    currentString += motif.charAt(i - 1);
                } else
                {
                    // There are multiple possibilities for continuing this String, so try them all
                    split = true;

                    for (int j = 0; j < letters.size(); j++)
                    {
                        makeRecursive(motif.substring(i + 1), currentString + letters.get(j), list);
                    }
                }
            }
        }

        // If we come here without having split the String, we have succesfully made the entire String
        if (!split)
        {
            // So add it to the list
            list.add(currentString);
        }
    }

    /**
     *
     * @param sequence      A sequence of amino acids
     * @return              a random motif occurring in the sequence
     */
    public static String getRandomMotifFromSequence(String sequence)
    {
        int subsequenceLength = MaskArray.$subsequenceLength;
        
        Random r = new Random();

        // Random subsequence
        int subsequenceStart = r.nextInt(sequence.length() - subsequenceLength);

        char[] subsequence = sequence.substring(subsequenceStart, subsequenceStart + subsequenceLength).toCharArray();

        // Apply random (l, d) mask
        int mask = MaskArray.getInstance().getRandomMask();

        for (int i = 0; i < subsequenceLength; i++)
        {
            if ((mask & 1 << i) == 0)
            {
                subsequence[subsequenceLength - 1 - i] = 'x';
            } else if (AminoAcids.getDisjunctive())
            {
                subsequence[subsequenceLength - 1 - i] = AminoAcids.getLetterForIndex(AminoAcids.getIndexForLetter(subsequence[subsequenceLength - 1 - i]));
            }

        }

        // This is a random motif from the sequence
        return new String(subsequence);
    }

    /**
     *
     * @param m1            a motif number
     * @param m2            a motif number
     * @param motifData     a motif data object
     * @return              the proteins containing both motifs
     */
    public static char[] getIntersection(int m1, int m2, IMotifData motifData)
    {
        char[] array1 = motifData.getProteinsWithSequencesWithMotif(m1);
        char[] array2 = motifData.getProteinsWithSequencesWithMotif(m2);

        if (array1 == null || array2 == null)
        {
            return null;
        }

        LinkedList<Character> intersection = new LinkedList<Character>();

        int current1Index = 0;
        int current2Index = 0;

        while (current1Index < array1.length && current2Index < array2.length)
        {
            if (array1[current1Index] < array2[current2Index])
            {
                current1Index++;
            } else if (array1[current1Index] > array2[current2Index])
            {
                current2Index++;
            } else if (array1[current1Index] == array2[current2Index])
            {
                intersection.addLast(array1[current1Index]);

                current1Index++;
                current2Index++;
            }
        }

        if (intersection.size() == 0)
        {
            return null;
        }

        char[] result = new char[intersection.size()];

        for (int i = 0; i < intersection.size(); i++)
        {
            result[i] = intersection.get(i);
        }

        return result;
    }

    /**
     *
     * @param m1            a motif
     * @param m2            a motif
     * @param motifData     a motif data object
     * @return              the proteins containing both motifs
     */
    public static char[] getIntersection(String m1, String m2, IMotifData motifData)
    {
        char[] array1 = motifData.getProteinsWithSequencesWithMotif(m1);
        char[] array2 = motifData.getProteinsWithSequencesWithMotif(m2);

        if (array1 == null || array2 == null)
        {
            return null;
        }

        LinkedList<Character> intersection = new LinkedList<Character>();

        int current1Index = 0;
        int current2Index = 0;

        while (current1Index < array1.length && current2Index < array2.length)
        {
            if (array1[current1Index] < array2[current2Index])
            {
                current1Index++;
            } else if (array1[current1Index] > array2[current2Index])
            {
                current2Index++;
            } else if (array1[current1Index] == array2[current2Index])
            {
                intersection.addLast(array1[current1Index]);

                current1Index++;
                current2Index++;
            }
        }

        if (intersection.size() == 0)
        {
            return null;
        }

        char[] result = new char[intersection.size()];

        for (int i = 0; i < intersection.size(); i++)
        {
            result[i] = intersection.get(i);
        }

        return result;
    }
}
